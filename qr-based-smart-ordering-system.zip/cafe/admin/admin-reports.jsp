<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*, java.time.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
    int totalOrders=0, todayOrders=0, completedOrders=0;
    double totalRevenue=0, todayRevenue=0;
    java.util.List<String[]> topItems = new java.util.ArrayList<>();

    Connection conn=null;
    try{
      conn=DBConnection.getConnection();
      ResultSet r;
      r=conn.prepareStatement("SELECT COUNT(*) FROM orders").executeQuery();
      if(r.next()) totalOrders=r.getInt(1);

      r=conn.prepareStatement("SELECT COUNT(*) FROM orders WHERE DATE(order_time)=CURDATE()").executeQuery();
      if(r.next()) todayOrders=r.getInt(1);

      r=conn.prepareStatement("SELECT COUNT(*) FROM orders WHERE order_status='Completed'").executeQuery();
      if(r.next()) completedOrders=r.getInt(1);

      r=conn.prepareStatement("SELECT COALESCE(SUM(o.total_amount),0) FROM orders o JOIN payments p ON o.order_id=p.order_id WHERE p.payment_status='Paid'").executeQuery();
      if(r.next()) totalRevenue=r.getDouble(1);

      r=conn.prepareStatement("SELECT COALESCE(SUM(o.total_amount),0) FROM orders o JOIN payments p ON o.order_id=p.order_id WHERE p.payment_status='Paid' AND DATE(o.order_time)=CURDATE()").executeQuery();
      if(r.next()) todayRevenue=r.getDouble(1);

    }catch(Exception e){e.printStackTrace();}
    finally{if(conn!=null)try{conn.close();}catch(Exception e2){}}
%>
<!DOCTYPE html><html><head>
<title>Reports - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;text-decoration:none;color:#555;font-size:14px;font-weight:500;transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;}
.logout-btn:hover{background:#dc2626;color:#fff;}
.main{margin-left:230px;flex:1;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}
.print-btn{background:#a16207;color:#fff;border:none;padding:9px 20px;border-radius:8px;cursor:pointer;font-size:13px;font-family:"Poppins",sans-serif;font-weight:600;}
.print-btn:hover{background:#78350f;}
.section-title{font-size:18px;font-weight:700;color:#3b2f2f;margin:25px 0 15px;font-family:"Playfair Display",serif;display:flex;align-items:center;gap:8px;}
.stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-bottom:10px;}
.stat{background:#fff;border-radius:14px;padding:22px 20px;box-shadow:0 4px 12px rgba(0,0,0,.06);display:flex;align-items:center;gap:15px;}
.stat-icon{width:50px;height:50px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;}
.stat-info h3{font-size:24px;font-weight:700;color:#3b2f2f;}
.stat-info p{font-size:12px;color:#aaa;margin-top:3px;}
.two-col{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:20px;}
.card{background:#fff;border-radius:14px;padding:22px;box-shadow:0 4px 15px rgba(0,0,0,.06);}
.card h3{font-size:14px;font-weight:700;color:#a16207;margin-bottom:14px;font-family:"Playfair Display",serif;}
table{width:100%;border-collapse:collapse;}
thead th{padding:10px 12px;text-align:left;background:#fdf6f0;color:#a16207;font-size:12px;font-weight:600;text-transform:uppercase;}
tbody td{padding:11px 12px;border-bottom:1px solid #f9f0e8;font-size:13px;color:#555;}
tbody tr:last-child td{border-bottom:none;}
.badge-new{background:#fef9c3;color:#a16207;padding:3px 9px;border-radius:10px;font-size:11px;font-weight:600;}
.badge-comp{background:#dcfce7;color:#16a34a;padding:3px 9px;border-radius:10px;font-size:11px;font-weight:600;}
.badge-prep{background:#dbeafe;color:#1d4ed8;padding:3px 9px;border-radius:10px;font-size:11px;font-weight:600;}
@media(max-width:900px){.stats-grid,.two-col{grid-template-columns:1fr 1fr;}}
@media print{.sidebar,.topbar,.print-btn{display:none!important;}.main{margin-left:0!important;}.content{padding:10px!important;}}
</style>
</head><body>
<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp">&#128230; Orders</a></li>
    <li><a href="admin-tables.jsp">&#128196; Tables & QR</a></li>
    <li><a href="admin-manage-menu.jsp">&#127869; Manage Menu</a></li>
    <li><a href="admin-payments.jsp">&#128179; Payments</a></li>
    <li><a href="admin-reports.jsp" class="active">&#128200; Reports</a></li>
    <li><a href="feedback-admin.jsp">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact</a></li>
  </ul>
  <div class="sidebar-footer"><a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a></div>
</aside>
<div class="main">
  <div class="topbar">
    <h1>Reports & Analytics</h1>
    <div style="display:flex;align-items:center;gap:12px;">
      <button class="print-btn" onclick="window.print()">&#128438; Print Report</button>
      <div class="admin-badge">&#128100; <%= session.getAttribute("adminUser") %></div>
    </div>
  </div>
  <div class="content">

    <p class="section-title">&#128202; Summary</p>
    <div class="stats-grid">
      <div class="stat"><div class="stat-icon" style="background:#fff7ed;">&#128230;</div><div class="stat-info"><h3><%= totalOrders %></h3><p>Total Orders</p></div></div>
      <div class="stat"><div class="stat-icon" style="background:#f0fdf4;">&#128181;</div><div class="stat-info"><h3>&#8377;<%= String.format("%.0f",totalRevenue) %></h3><p>Total Revenue</p></div></div>
      <div class="stat"><div class="stat-icon" style="background:#eff6ff;">&#9989;</div><div class="stat-info"><h3><%= completedOrders %></h3><p>Completed Orders</p></div></div>
    </div>

    <p class="section-title">&#127774; Today's Summary</p>
    <div class="stats-grid">
      <div class="stat"><div class="stat-icon" style="background:#fdf6f0;">&#128336;</div><div class="stat-info"><h3><%= todayOrders %></h3><p>Today's Orders</p></div></div>
      <div class="stat"><div class="stat-icon" style="background:#f0fdf4;">&#128176;</div><div class="stat-info"><h3>&#8377;<%= String.format("%.0f",todayRevenue) %></h3><p>Today's Revenue</p></div></div>
      <div class="stat"><div class="stat-icon" style="background:#fef9c3;">&#127869;</div>
        <div class="stat-info">
          <%
          int todayCat=0;
          try(Connection cc=DBConnection.getConnection()){
            ResultSet rr=cc.prepareStatement("SELECT COUNT(DISTINCT o.order_id) FROM orders o WHERE DATE(o.order_time)=CURDATE() AND o.order_status='Completed'").executeQuery();
            if(rr.next()) todayCat=rr.getInt(1);
          }catch(Exception e){}
          %>
          <h3><%= todayCat %></h3><p>Completed Today</p>
        </div>
      </div>
    </div>

    <div class="two-col">

      <!-- TODAY'S ORDERS TABLE -->
      <div class="card">
        <h3>&#128336; Today's Orders</h3>
        <table>
          <thead><tr><th>ID</th><th>Customer</th><th>Amount</th><th>Status</th></tr></thead>
          <tbody>
          <%
          Connection conn3=null;
          try{
            conn3=DBConnection.getConnection();
            ResultSet tr=conn3.prepareStatement(
              "SELECT o.order_id, u.name, o.total_amount, o.order_status FROM orders o " +
              "JOIN users u ON o.user_id=u.user_id WHERE DATE(o.order_time)=CURDATE() ORDER BY o.order_time DESC"
            ).executeQuery();
            boolean any=false;
            while(tr.next()){any=true;
              String st=tr.getString("order_status");
              String bc="New".equals(st)?"badge-new":"Completed".equals(st)?"badge-comp":"badge-prep";
          %>
            <tr>
              <td>#<%= tr.getInt("order_id") %></td>
              <td><%= tr.getString("name") %></td>
              <td style="font-weight:600;color:#a16207;">&#8377;<%= String.format("%.0f",tr.getDouble("total_amount")) %></td>
              <td><span class="<%= bc %>"><%= st %></span></td>
            </tr>
          <%  }if(!any){%><tr><td colspan="4" style="text-align:center;padding:20px;color:#bbb;">No orders today yet.</td></tr><%}
          }catch(Exception e){out.print("<tr><td colspan='4' style='color:red;'>"+e.getMessage()+"</td></tr>");
          }finally{if(conn3!=null)try{conn3.close();}catch(Exception e2){}}%>
          </tbody>
        </table>
      </div>

      <!-- REVENUE BY PAYMENT METHOD -->
      <div class="card">
        <h3>&#128179; Revenue by Payment Method</h3>
        <table>
          <thead><tr><th>Method</th><th>Orders</th><th>Revenue</th></tr></thead>
          <tbody>
          <%
          Connection conn4=null;
          try{
            conn4=DBConnection.getConnection();
            ResultSet pr=conn4.prepareStatement(
              "SELECT p.payment_method, COUNT(*) as cnt, SUM(o.total_amount) as rev " +
              "FROM payments p JOIN orders o ON p.order_id=o.order_id " +
              "WHERE p.payment_status='Paid' GROUP BY p.payment_method"
            ).executeQuery();
            boolean any=false;
            while(pr.next()){any=true;}
            // Re-run since ResultSet exhausted
            pr=conn4.prepareStatement(
              "SELECT p.payment_method, COUNT(*) as cnt, SUM(o.total_amount) as rev " +
              "FROM payments p JOIN orders o ON p.order_id=o.order_id " +
              "WHERE p.payment_status='Paid' GROUP BY p.payment_method"
            ).executeQuery();
            any=false;
            while(pr.next()){any=true;%>
              <tr>
                <td><strong><%= pr.getString("payment_method") %></strong></td>
                <td><%= pr.getInt("cnt") %></td>
                <td style="font-weight:600;color:#a16207;">&#8377;<%= String.format("%.0f",pr.getDouble("rev")) %></td>
              </tr>
            <%}if(!any){%><tr><td colspan="3" style="text-align:center;padding:20px;color:#bbb;">No paid orders yet.</td></tr><%}
          }catch(Exception e){out.print("<tr><td colspan='3' style='color:red;'>"+e.getMessage()+"</td></tr>");
          }finally{if(conn4!=null)try{conn4.close();}catch(Exception e2){}}%>
          </tbody>
        </table>
      </div>

    </div>
  </div>
</div>
</body></html>
