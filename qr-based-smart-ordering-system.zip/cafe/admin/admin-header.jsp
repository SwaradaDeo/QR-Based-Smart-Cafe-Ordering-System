<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<link rel="stylesheet" href="css/admin-layout.css">

<header class="admin-header">

<div class="admin-logo">
Veloura Café Admin
</div>

<div class="admin-user">
Admin Panel
</div>

</header>