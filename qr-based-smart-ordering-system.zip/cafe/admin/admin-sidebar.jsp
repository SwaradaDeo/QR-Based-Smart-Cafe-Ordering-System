
<link rel="stylesheet" href="css/admin-layout.css">


<aside class="admin-sidebar">

<ul>

<li>
<a href="admin-dashboard.jsp">Dashboard</a>
</li>

<li>
<a href="admin-orders.jsp">Orders</a>
</li>

<li>
<a href="menu-manager.jsp">Manage Menu</a>
</li>

<li>
<a href="feedback-admin.jsp">Feedback</a>
</li>

<li>
<a href="report.jsp">Report</a>
</li>


<li>
<a href="admin-login.jsp">Logout</a>
</li>

</ul>

</aside>