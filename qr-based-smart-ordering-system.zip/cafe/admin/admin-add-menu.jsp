<%@ page contentType="text/html;charset=UTF-8"%>

<jsp:include page="admin-header.jsp"/>
<jsp:include page="admin-sidebar.jsp"/>

<link rel="stylesheet" href="css/add-menu.css">

<div class="menu-board">

<h1 class="menu-title">Veloura Café Menu Manager</h1>

<div class="menu-grid" id="menuGrid"></div>

</div>

<script src="js/add-menu.js"></script>