<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
%>
<!DOCTYPE html><html><head>
<title>Contact Messages - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;text-decoration:none;color:#555;font-size:14px;font-weight:500;transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;font-weight:500;}
.logout-btn:hover{background:#dc2626;color:#fff;}
.main{margin-left:230px;flex:1;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}
.table-card{background:#fff;border-radius:16px;padding:22px;box-shadow:0 4px 15px rgba(0,0,0,.06);}
table{width:100%;border-collapse:collapse;}
thead th{padding:12px 15px;text-align:left;background:#fdf6f0;color:#a16207;font-size:12px;font-weight:600;text-transform:uppercase;}
tbody td{padding:13px 15px;border-bottom:1px solid #f9f0e8;font-size:13px;color:#555;vertical-align:top;}
tbody tr:last-child td{border-bottom:none;}
tbody tr:hover{background:#fdfaf7;}
.no-data{text-align:center;color:#bbb;padding:40px;font-size:14px;}
.msg-text{max-width:350px;line-height:1.5;}
</style>
</head><body>

<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp">&#128230; Orders</a></li>
    <li><a href="admin-tables.jsp">&#128196; Tables &amp; QR</a></li>
    <li><a href="admin-manage-menu.jsp" id="nav-menu">&#127869; Manage Menu</a></li>
    <li><a href="admin-payments.jsp">&#128179; Payments</a></li>
    <li><a href="admin-reports.jsp">&#128200; Reports</a></li>
    <li><a href="feedback-admin.jsp" id="nav-feedback">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact</a></li>
  </ul>
  <div class="sidebar-footer">
    <a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <h1>Contact Messages</h1>
    <div class="admin-badge">👤 <%= session.getAttribute("adminUser") %></div>
  </div>
  <div class="content">
    <div class="table-card">
      <table>
        <thead><tr><th>#</th><th>Name</th><th>Email</th><th>Message</th><th>Date</th></tr></thead>
        <tbody>
        <%try(Connection conn=DBConnection.getConnection()){
          ResultSet rs=conn.prepareStatement("SELECT * FROM contact_messages ORDER BY created_at DESC").executeQuery();
          boolean any=false;
          while(rs.next()){any=true;%>
          <tr>
            <td>#<%= rs.getInt("message_id") %></td>
            <td><strong><%= rs.getString("name") %></strong></td>
            <td><a href="mailto:<%= rs.getString("email") %>" style="color:#a16207;"><%= rs.getString("email") %></a></td>
            <td class="msg-text"><%= rs.getString("message") %></td>
            <td style="white-space:nowrap;color:#aaa;"><%= rs.getTimestamp("created_at").toString().substring(0,16) %></td>
          </tr>
          <%}if(!any){%><tr><td colspan="5" class="no-data">📩 No contact messages yet.</td></tr><%}
          }catch(Exception e){%><tr><td colspan="5" class="no-data">Error: <%= e.getMessage() %></td></tr><%}%>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body></html>
