<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
%>
<!DOCTYPE html><html><head>
<title>Payments - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;text-decoration:none;color:#555;font-size:14px;font-weight:500;transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;}
.logout-btn:hover{background:#dc2626;color:#fff;}
.main{margin-left:230px;flex:1;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}
.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-bottom:25px;}
.scard{background:#fff;border-radius:14px;padding:20px;box-shadow:0 4px 12px rgba(0,0,0,.06);display:flex;align-items:center;gap:14px;}
.sicon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:22px;}
.sinfo h3{font-size:22px;font-weight:700;color:#3b2f2f;}
.sinfo p{font-size:11px;color:#aaa;margin-top:2px;}
.table-card{background:#fff;border-radius:14px;padding:22px;box-shadow:0 4px 15px rgba(0,0,0,.06);}
.table-card h3{font-size:15px;font-weight:700;color:#a16207;margin-bottom:16px;font-family:"Playfair Display",serif;}
table{width:100%;border-collapse:collapse;}
thead th{padding:11px 14px;text-align:left;background:#fdf6f0;color:#a16207;font-size:12px;font-weight:600;text-transform:uppercase;}
tbody td{padding:12px 14px;border-bottom:1px solid #f9f0e8;font-size:13px;color:#555;}
tbody tr:last-child td{border-bottom:none;}
tbody tr:hover{background:#fdfaf7;}
.badge{padding:3px 10px;border-radius:10px;font-size:11px;font-weight:600;}
.paid{background:#dcfce7;color:#16a34a;}
.pending{background:#fef9c3;color:#a16207;}
</style>
</head><body>
<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp">&#128230; Orders</a></li>
    <li><a href="admin-tables.jsp">&#128196; Tables & QR</a></li>
    <li><a href="admin-manage-menu.jsp">&#127869; Manage Menu</a></li>
    <li><a href="admin-payments.jsp" class="active">&#128179; Payments</a></li>
    <li><a href="admin-reports.jsp">&#128200; Reports</a></li>
    <li><a href="feedback-admin.jsp">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact</a></li>
  </ul>
  <div class="sidebar-footer"><a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a></div>
</aside>
<div class="main">
  <div class="topbar">
    <h1>Payment Information</h1>
    <div class="admin-badge">&#128100; <%= session.getAttribute("adminUser") %></div>
  </div>
  <div class="content">
    <%
    double totalRev=0, cashRev=0, upiRev=0, cardRev=0;
    Connection conn=null;
    try{
      conn=DBConnection.getConnection();
      ResultSet sr=conn.prepareStatement(
        "SELECT p.payment_method, SUM(o.total_amount) as rev FROM payments p " +
        "JOIN orders o ON p.order_id=o.order_id WHERE p.payment_status='Paid' GROUP BY p.payment_method"
      ).executeQuery();
      while(sr.next()){
        double v=sr.getDouble("rev");
        totalRev+=v;
        String m=sr.getString("payment_method");
        if("Cash".equals(m)) cashRev=v;
        else if("UPI".equals(m)) upiRev=v;
        else if("Card".equals(m)) cardRev=v;
      }
    }catch(Exception e){} finally{if(conn!=null)try{conn.close();}catch(Exception e2){}}
    %>
    <div class="stats">
      <div class="scard"><div class="sicon" style="background:#f0fdf4;">&#128181;</div><div class="sinfo"><h3>&#8377;<%= String.format("%.0f",totalRev) %></h3><p>Total Revenue (Paid)</p></div></div>
      <div class="scard"><div class="sicon" style="background:#eff6ff;">&#128241;</div><div class="sinfo"><h3>&#8377;<%= String.format("%.0f",upiRev) %></h3><p>UPI Revenue</p></div></div>
      <div class="scard"><div class="sicon" style="background:#fdf6f0;">&#128179;</div><div class="sinfo"><h3>&#8377;<%= String.format("%.0f",cashRev+cardRev) %></h3><p>Cash + Card Revenue</p></div></div>
    </div>
    <div class="table-card">
      <h3>All Payments</h3>
      <table>
        <thead><tr><th>#</th><th>Order ID</th><th>Customer</th><th>Amount</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
        <%
        Connection conn2=null;
        try{
          conn2=DBConnection.getConnection();
          ResultSet rs=conn2.prepareStatement(
            "SELECT p.payment_id, p.order_id, p.payment_method, p.payment_status, p.payment_date, " +
            "o.total_amount, u.name FROM payments p " +
            "JOIN orders o ON p.order_id=o.order_id " +
            "JOIN users u ON o.user_id=u.user_id ORDER BY p.payment_date DESC"
          ).executeQuery();
          boolean any=false;
          while(rs.next()){any=true;
            String st=rs.getString("payment_status");
        %>
          <tr>
            <td>#<%= rs.getInt("payment_id") %></td>
            <td>Order #<%= rs.getInt("order_id") %></td>
            <td><%= rs.getString("name") %></td>
            <td style="font-weight:600;color:#a16207;">&#8377;<%= String.format("%.2f",rs.getDouble("total_amount")) %></td>
            <td><%= rs.getString("payment_method") %></td>
            <td><span class="badge <%= "Paid".equals(st)?"paid":"pending" %>"><%= st %></span></td>
            <td style="color:#aaa;"><%= rs.getTimestamp("payment_date").toString().substring(0,16) %></td>
          </tr>
        <%  }if(!any){%><tr><td colspan="7" style="text-align:center;padding:30px;color:#bbb;">No payments yet.</td></tr><%}
        }catch(Exception e){out.print("<tr><td colspan='7' style='color:red;padding:20px;'>"+e.getMessage()+"</td></tr>");
        }finally{if(conn2!=null)try{conn2.close();}catch(Exception e2){}}%>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body></html>
