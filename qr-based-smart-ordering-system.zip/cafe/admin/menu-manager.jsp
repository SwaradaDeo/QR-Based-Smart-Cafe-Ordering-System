<%@ page contentType="text/html;charset=UTF-8"%>

<jsp:include page="admin-header.jsp"/>
<jsp:include page="admin-sidebar.jsp"/>

<link rel="stylesheet" href="css/menu-manager.css">

<div class="menu-manager">

<h1 class="menu-title">Menu Manager</h1>

<!-- ADD CATEGORY -->

<div class="add-category-box">

<input id="newCategory" placeholder="Category Name">
<input id="firstItem" placeholder="First Item Name">
<input id="firstPrice" placeholder="Price">

<button onclick="addCategory()">Add Category</button>

</div>


<div id="menuGrid" class="menu-grid"></div>

</div>

<script src="js/menu-manager.js"></script>