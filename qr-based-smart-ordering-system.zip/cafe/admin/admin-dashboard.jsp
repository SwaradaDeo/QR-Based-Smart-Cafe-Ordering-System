<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if (session.getAttribute("adminUser") == null) {
        response.sendRedirect(request.getContextPath() + "/admin/admin-login.jsp");
        return;
    }
    int totalOrders=0, totalItems=0, totalUsers=0, pendingOrders=0;
    try (Connection conn = DBConnection.getConnection()) {
        ResultSet rs;
        rs = conn.prepareStatement("SELECT COUNT(*) FROM orders").executeQuery();
        if(rs.next()) totalOrders = rs.getInt(1);
        rs = conn.prepareStatement("SELECT COUNT(*) FROM menu_items").executeQuery();
        if(rs.next()) totalItems = rs.getInt(1);
        rs = conn.prepareStatement("SELECT COUNT(*) FROM users WHERE role=\'customer\'").executeQuery();
        if(rs.next()) totalUsers = rs.getInt(1);
        rs = conn.prepareStatement("SELECT COUNT(*) FROM orders WHERE order_status=\'New\'").executeQuery();
        if(rs.next()) pendingOrders = rs.getInt(1);
    } catch(Exception e){ e.printStackTrace(); }
%>
<!DOCTYPE html>
<html>
<head>
<title>Admin Dashboard - Veloura Cafe</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;box-shadow:3px 0 15px rgba(0,0,0,0.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;font-family:"Poppins",sans-serif;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;text-decoration:none;color:#555;font-size:14px;font-weight:500;transition:0.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;font-weight:500;transition:0.2s;}
.logout-btn:hover{background:#dc2626;color:white;}
.main{margin-left:230px;flex:1;min-height:100vh;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,0.05);position:sticky;top:0;z-index:50;}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}
.stats-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:18px;margin-bottom:30px;}
.stat-card{background:#fff;border-radius:16px;padding:22px 18px;box-shadow:0 4px 15px rgba(0,0,0,0.06);display:flex;align-items:center;gap:15px;transition:transform 0.2s;}
.stat-card:hover{transform:translateY(-3px);}
.stat-icon{width:52px;height:52px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:22px;}
.icon-orange{background:#fff7ed;}
.icon-green{background:#f0fdf4;}
.icon-blue{background:#eff6ff;}
.icon-red{background:#fef2f2;}
.stat-info h3{font-size:26px;font-weight:700;color:#3b2f2f;}
.stat-info p{font-size:12px;color:#999;margin-top:2px;font-weight:500;}
.section-title{font-size:17px;font-weight:600;color:#3b2f2f;margin-bottom:15px;font-family:"Playfair Display",serif;}
.actions-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:30px;}
.action-card{background:#fff;border-radius:14px;padding:22px 18px;text-decoration:none;box-shadow:0 4px 12px rgba(0,0,0,0.05);display:flex;flex-direction:column;gap:8px;transition:0.2s;border:2px solid transparent;}
.action-card:hover{border-color:#a16207;transform:translateY(-2px);}
.action-card .icon{font-size:28px;}
.action-card h4{color:#3b2f2f;font-size:14px;}
.action-card p{color:#aaa;font-size:12px;}
.table-card{background:#fff;border-radius:16px;padding:22px;box-shadow:0 4px 15px rgba(0,0,0,0.06);}
table{width:100%;border-collapse:collapse;}
thead th{padding:11px 14px;text-align:left;background:#fdf6f0;color:#a16207;font-size:12px;font-weight:600;text-transform:uppercase;}
tbody td{padding:12px 14px;border-bottom:1px solid #f9f0e8;font-size:13px;color:#555;}
tbody tr:last-child td{border-bottom:none;}
tbody tr:hover{background:#fdfaf7;}
.badge{padding:4px 11px;border-radius:20px;font-size:11px;font-weight:600;}
.badge-new{background:#fef9c3;color:#a16207;}
.badge-preparing{background:#dbeafe;color:#1d4ed8;}
.badge-ready{background:#dcfce7;color:#16a34a;}
.badge-completed{background:#f3f4f6;color:#6b7280;}
.no-data{text-align:center;color:#bbb;padding:30px;font-size:14px;}
@media(max-width:900px){
  .stats-grid{grid-template-columns:repeat(2,1fr);}
  .actions-grid{grid-template-columns:repeat(2,1fr);}
}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp">&#128230; Orders</a></li>
    <li><a href="admin-tables.jsp">&#128196; Tables &amp; QR</a></li>
    <li><a href="admin-manage-menu.jsp" id="nav-menu">&#127869; Manage Menu</a></li>
    <li><a href="admin-payments.jsp">&#128179; Payments</a></li>
    <li><a href="admin-reports.jsp">&#128200; Reports</a></li>
    <li><a href="feedback-admin.jsp" id="nav-feedback">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact</a></li>
  </ul>
  <div class="sidebar-footer">
    <a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <h1>Dashboard</h1>
    <div class="admin-badge">👤 <%= session.getAttribute("adminUser") %></div>
  </div>

  <div class="content">

    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon icon-orange">📦</div>
        <div class="stat-info"><h3><%= totalOrders %></h3><p>Total Orders</p></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon icon-green">🍽️</div>
        <div class="stat-info"><h3><%= totalItems %></h3><p>Menu Items</p></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon icon-blue">👥</div>
        <div class="stat-info"><h3><%= totalUsers %></h3><p>Customers</p></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon icon-red">⏳</div>
        <div class="stat-info"><h3><%= pendingOrders %></h3><p>Pending Orders</p></div>
      </div>
    </div>

    <p class="section-title">Quick Actions</p>
    <div class="actions-grid">
      <a href="admin-orders.jsp" class="action-card">
        <div class="icon">📦</div>
        <h4>Manage Orders</h4>
        <p>View and update order statuses</p>
      </a>
      <a href="admin-manage-menu.jsp" class="action-card">
        <div class="icon">🍕</div>
        <h4>Manage Menu</h4>
        <p>Edit, add or remove menu items</p>
      </a>
      <a href="feedback-admin.jsp" class="action-card">
        <div class="icon">⭐</div>
        <h4>View Feedback</h4>
        <p>Read customer reviews and ratings</p>
      </a>
    </div>

    <p class="section-title">Recent Orders</p>
    <div class="table-card">
      <table>
        <thead>
          <tr>
            <th>Order ID</th><th>Customer</th><th>Amount</th><th>Status</th><th>Time</th>
          </tr>
        </thead>
        <tbody>
        <%
          try (Connection conn2 = DBConnection.getConnection()) {
            String sql = "SELECT o.order_id, u.name, o.total_amount, o.order_status, o.order_time " +
                         "FROM orders o JOIN users u ON o.user_id=u.user_id " +
                         "ORDER BY o.order_time DESC LIMIT 10";
            ResultSet rs2 = conn2.prepareStatement(sql).executeQuery();
            boolean hasRows = false;
            while(rs2.next()){
              hasRows = true;
              String st = rs2.getString("order_status");
              String bc = "badge-new";
              if("Preparing".equals(st)) bc="badge-preparing";
              else if("Ready".equals(st)) bc="badge-ready";
              else if("Completed".equals(st)) bc="badge-completed";
        %>
          <tr>
            <td>#<%= rs2.getInt("order_id") %></td>
            <td><%= rs2.getString("name") %></td>
            <td>&#8377;<%= String.format("%.2f", rs2.getDouble("total_amount")) %></td>
            <td><span class="badge <%= bc %>"><%= st %></span></td>
            <td><%= rs2.getTimestamp("order_time").toString().substring(0,16) %></td>
          </tr>
        <%  }
            if(!hasRows){ %>
          <tr><td colspan="5" class="no-data">No orders yet. Orders will appear here once customers place them.</td></tr>
        <%  }
          } catch(Exception ex){ %>
          <tr><td colspan="5" class="no-data">Could not load orders: <%= ex.getMessage() %></td></tr>
        <% } %>
        </tbody>
      </table>
    </div>

  </div>
</div>
</body>
</html>