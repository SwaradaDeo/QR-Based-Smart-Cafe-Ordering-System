<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html>
<head>
<title>Tables & QR Codes - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<!-- QR Code library -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;text-decoration:none;color:#555;font-size:14px;font-weight:500;transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;font-weight:500;}
.logout-btn:hover{background:#dc2626;color:#fff;}
.main{margin-left:230px;flex:1;min-height:100vh;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);position:sticky;top:0;z-index:50;}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}
.alert{padding:12px 18px;border-radius:10px;font-size:13px;font-weight:500;margin-bottom:18px;}
.alert-success{background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;}
.alert-error{background:#fef2f2;color:#dc2626;border:1px solid #fecaca;}
.two-col{display:grid;grid-template-columns:300px 1fr;gap:22px;align-items:start;}
.card{background:#fff;border-radius:14px;padding:22px;box-shadow:0 4px 15px rgba(0,0,0,.06);margin-bottom:18px;}
.card h3{font-size:15px;font-weight:700;color:#a16207;margin-bottom:16px;font-family:"Playfair Display",serif;border-bottom:1px solid #f3e8e2;padding-bottom:10px;}
.form-group{margin-bottom:13px;}
.form-group label{display:block;font-size:12px;font-weight:600;color:#666;margin-bottom:5px;text-transform:uppercase;}
.form-group input{width:100%;padding:10px 12px;border-radius:8px;border:1px solid #e5d5c8;background:#fffaf6;font-family:"Poppins",sans-serif;font-size:13px;}
.form-group input:focus{outline:none;border-color:#a16207;}
.submit-btn{background:linear-gradient(135deg,#f59e0b,#a16207);color:#fff;border:none;padding:11px;border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;width:100%;font-family:"Poppins",sans-serif;}
.submit-btn:hover{background:linear-gradient(135deg,#a16207,#78350f);}

/* TABLE GRID */
.tables-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:18px;}
.table-card{background:#fff;border-radius:14px;padding:20px;box-shadow:0 4px 15px rgba(0,0,0,.06);text-align:center;border:2px solid #f3e8e2;transition:.2s;}
.table-card:hover{border-color:#a16207;transform:translateY(-2px);}
.table-num{font-size:22px;font-weight:700;color:#a16207;font-family:"Playfair Display",serif;margin-bottom:4px;}
.table-status{display:inline-block;padding:3px 10px;border-radius:10px;font-size:11px;font-weight:600;margin-bottom:12px;}
.status-available{background:#dcfce7;color:#16a34a;}
.status-occupied{background:#fee2e2;color:#dc2626;}
.qr-box{margin:12px auto;display:flex;justify-content:center;}
.qr-url{font-size:10px;color:#bbb;word-break:break-all;margin-bottom:12px;background:#fdf6f0;padding:6px;border-radius:6px;}
.table-actions{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;}
.btn-print{background:#a16207;color:#fff;border:none;padding:7px 14px;border-radius:7px;cursor:pointer;font-size:12px;font-family:"Poppins",sans-serif;}
.btn-print:hover{background:#78350f;}
.btn-reset{background:#f3f4f6;color:#6b7280;border:none;padding:7px 14px;border-radius:7px;cursor:pointer;font-size:12px;font-family:"Poppins",sans-serif;}
.btn-del{background:#fee2e2;color:#dc2626;border:none;padding:7px 14px;border-radius:7px;cursor:pointer;font-size:12px;font-family:"Poppins",sans-serif;}
.no-tables{text-align:center;color:#bbb;padding:40px;font-size:14px;grid-column:1/-1;}

/* PRINT STYLES */
@media print{
  .sidebar,.topbar,.content > :not(.print-area),.table-actions,.no-print{display:none!important;}
  .print-area{display:block!important;}
  .print-qr{page-break-inside:avoid;text-align:center;padding:30px;border:2px dashed #a16207;margin:20px;border-radius:12px;}
}
@media(max-width:900px){.two-col{grid-template-columns:1fr;}}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp">&#128230; Orders</a></li>
    <li><a href="admin-tables.jsp">&#128196; Tables &amp; QR</a></li>
    <li><a href="admin-manage-menu.jsp" id="nav-menu">&#127869; Manage Menu</a></li>
    <li><a href="admin-payments.jsp">&#128179; Payments</a></li>
    <li><a href="admin-reports.jsp">&#128200; Reports</a></li>
    <li><a href="feedback-admin.jsp" id="nav-feedback">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact</a></li>
  </ul>
  <div class="sidebar-footer">
    <a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <h1>Tables & QR Codes</h1>
    <div class="admin-badge">&#128100; <%= session.getAttribute("adminUser") %></div>
  </div>

  <div class="content">

    <% if("added".equals(msg)){  %><div class="alert alert-success">&#10003; Table added and QR code generated!</div><% }
       else if("deleted".equals(msg)){ %><div class="alert alert-success">&#10003; Table deleted.</div><% }
       else if("reset".equals(msg)){   %><div class="alert alert-success">&#10003; Table marked as available.</div><% }
       else if("error".equals(msg)){   %><div class="alert alert-error">&#10007; Error. Table number may already exist.</div><% } %>

    <div class="two-col">

      <!-- ADD TABLE FORM -->
      <div class="card">
        <h3>&#10133; Add New Table</h3>
        <form method="post" action="<%= request.getContextPath() %>/ManageTables">
          <input type="hidden" name="action" value="addTable">
          <div class="form-group">
            <label>Table Number *</label>
            <input type="number" name="tableNumber" placeholder="e.g. 1, 2, 3..." min="1" required>
          </div>
          <button class="submit-btn" type="submit">&#128196; Add Table & Generate QR</button>
        </form>
      </div>

      <!-- TABLES LIST -->
      <div>
        <div class="tables-grid" id="tablesGrid">
        <%
        String baseUrl = request.getScheme()+"://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath();
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            ResultSet rs = conn.prepareStatement(
                "SELECT * FROM tables ORDER BY table_number").executeQuery();
            boolean any = false;
            while(rs.next()){
                any = true;
                int    tid    = rs.getInt("table_id");
                int    tnum   = rs.getInt("table_number");
                String status = rs.getString("status");
                String qrUrl  = baseUrl + "/scan?table=" + tnum;
        %>
          <div class="table-card" id="tcard-<%= tid %>">
            <div class="table-num">Table #<%= tnum %></div>
            <span class="table-status status-<%= status %>"><%= status.toUpperCase() %></span>
            <div class="qr-box" id="qr-<%= tnum %>"></div>
            <div class="qr-url"><%= qrUrl %></div>
            <div class="table-actions">
              <button class="btn-print" onclick="printQR(<%= tnum %>, '<%= qrUrl %>')">&#128438; Print QR</button>
              <form method="post" action="<%= request.getContextPath() %>/ManageTables" style="display:inline">
                <input type="hidden" name="action"  value="resetTable">
                <input type="hidden" name="tableId" value="<%= tid %>">
                <button class="btn-reset" type="submit">&#9989; Free</button>
              </form>
              <form method="post" action="<%= request.getContextPath() %>/ManageTables" style="display:inline"
                onsubmit="return confirm('Delete Table #<%= tnum %>?')">
                <input type="hidden" name="action"  value="deleteTable">
                <input type="hidden" name="tableId" value="<%= tid %>">
                <button class="btn-del" type="submit">&#128465;</button>
              </form>
            </div>
          </div>
          <script>
            new QRCode(document.getElementById("qr-<%= tnum %>"), {
                text:   "<%= qrUrl %>",
                width:  140,
                height: 140,
                colorDark:  "#a16207",
                colorLight: "#ffffff"
            });
          </script>
        <%
            }
            if(!any){ out.print("<div class='no-tables'>No tables yet. Add tables using the form.</div>"); }
        } catch(Exception e) {
            out.print("<div class='no-tables' style='color:red;'>Error: "+e.getMessage()+"</div>");
        } finally {
            if(conn!=null) try{conn.close();}catch(Exception e2){}
        }
        %>
        </div>
      </div>

    </div>
  </div>
</div>

<script>
function printQR(tableNum, qrUrl) {
    var win = window.open('', '_blank', 'width=400,height=500');
    var qrDiv = document.getElementById("qr-" + tableNum).innerHTML;
    win.document.write(
        '<html><head><title>Table ' + tableNum + ' QR</title>' +
        '<style>body{font-family:Arial,sans-serif;text-align:center;padding:30px;}' +
        '.box{border:3px dashed #a16207;border-radius:12px;padding:25px;display:inline-block;}' +
        'h2{color:#a16207;margin-bottom:5px;}' +
        'p{color:#777;font-size:13px;margin-bottom:15px;}' +
        '.url{font-size:10px;color:#bbb;margin-top:10px;word-break:break-all;}' +
        '</style></head><body>' +
        '<div class="box">' +
        '<h2>&#9749; Veloura Cafe</h2>' +
        '<p>Scan to order from <strong>Table #' + tableNum + '</strong></p>' +
        qrDiv +
        '<div class="url">' + qrUrl + '</div>' +
        '</div>' +
        '<br><button onclick="window.print()" style="padding:10px 25px;background:#a16207;color:#fff;border:none;border-radius:8px;cursor:pointer;font-size:14px;">Print</button>' +
        '</body></html>'
    );
    win.document.close();
}
</script>

</body>
</html>
