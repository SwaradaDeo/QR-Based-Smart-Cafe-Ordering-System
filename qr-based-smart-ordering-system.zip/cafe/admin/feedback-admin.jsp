\<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html><html><head>
<title>Feedback - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;text-decoration:none;color:#555;font-size:14px;font-weight:500;transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;}
.logout-btn:hover{background:#dc2626;color:#fff;}
.main{margin-left:230px;flex:1;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}
.alert{padding:12px 16px;border-radius:10px;font-size:13px;margin-bottom:18px;}
.alert-success{background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:18px;}
.card{background:#fff;border-radius:14px;padding:20px;box-shadow:0 4px 12px rgba(0,0,0,.06);}
.fb-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;}
.fb-left{display:flex;align-items:center;gap:12px;}
.avatar{width:40px;height:40px;border-radius:50%;background:#fdf6f0;color:#a16207;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;border:2px solid #f3e8e2;flex-shrink:0;}
.fb-name{font-weight:600;color:#3b2f2f;font-size:14px;}
.fb-date{font-size:11px;color:#bbb;margin-top:1px;}
.stars{color:#f59e0b;font-size:18px;margin-bottom:10px;}
.fb-text{font-size:13px;color:#666;line-height:1.6;background:#fdfaf7;padding:11px;border-radius:8px;margin-bottom:12px;}
.del-btn{background:#fee2e2;color:#dc2626;border:none;padding:6px 14px;border-radius:7px;cursor:pointer;font-size:12px;font-family:"Poppins",sans-serif;font-weight:600;}
.del-btn:hover{background:#dc2626;color:#fff;}
.no-data{text-align:center;color:#bbb;padding:60px;font-size:14px;background:#fff;border-radius:14px;grid-column:1/-1;}
</style>
</head><body>
<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp">&#128230; Orders</a></li>
    <li><a href="admin-tables.jsp">&#128196; Tables & QR</a></li>
    <li><a href="admin-manage-menu.jsp">&#127869; Manage Menu</a></li>
    <li><a href="admin-payments.jsp">&#128179; Payments</a></li>
    <li><a href="admin-reports.jsp">&#128200; Reports</a></li>
    <li><a href="feedback-admin.jsp" class="active">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact</a></li>
  </ul>
  <div class="sidebar-footer"><a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a></div>
</aside>
<div class="main">
  <div class="topbar">
    <h1>Customer Feedback</h1>
    <div class="admin-badge">&#128100; <%= session.getAttribute("adminUser") %></div>
  </div>
  <div class="content">
    <% if("deleted".equals(msg)){ %><div class="alert alert-success">&#10003; Feedback deleted.</div><% } %>
    <div class="grid">
    <%
    Connection conn=null;
    try{
      conn=DBConnection.getConnection();
      ResultSet rs=conn.prepareStatement(
        "SELECT f.feedback_id, f.rating, f.comments, f.created_at, u.name FROM feedback f " +
        "JOIN users u ON f.user_id=u.user_id ORDER BY f.created_at DESC"
      ).executeQuery();
      boolean any=false;
      while(rs.next()){any=true;
        int rating=rs.getInt("rating");
        StringBuilder stars=new StringBuilder();
        for(int i=1;i<=5;i++) stars.append(i<=rating?"★":"☆");
    %>
      <div class="card">
        <div class="fb-head">
          <div class="fb-left">
            <div class="avatar"><%= rs.getString("name").charAt(0) %></div>
            <div>
              <div class="fb-name"><%= rs.getString("name") %></div>
              <div class="fb-date"><%= rs.getTimestamp("created_at").toString().substring(0,16) %></div>
            </div>
          </div>
          <form method="post" action="<%= request.getContextPath() %>/DeleteFeedback"
            onsubmit="return confirm('Delete this feedback?')">
            <input type="hidden" name="feedbackId" value="<%= rs.getInt("feedback_id") %>">
            <button class="del-btn" type="submit">&#128465; Delete</button>
          </form>
        </div>
        <div class="stars"><%= stars %></div>
        <div class="fb-text"><%= rs.getString("comments")!=null?rs.getString("comments"):"No comment." %></div>
      </div>
    <%  }if(!any){%><div class="no-data">&#11088; No feedback yet.</div><%}
    }catch(Exception e){%><div class="no-data" style="color:red;">Error: <%= e.getMessage() %></div><%}
    finally{if(conn!=null)try{conn.close();}catch(Exception e2){}}
    %>
    </div>
  </div>
</div>
</body></html>
