<jsp:include page="/components/header.jsp"/>

<section class="section about">

<img src="/images/burger.jpg">

<div class="about-text">

<h2>About Veloura Cafe</h2>

<p>
Veloura cafe is a modern aesthetic coffee space designed for calm,
comfort and creativity. Inspired by boutique cafes, our interiors
combine warm lighting, soft tones and minimalist design to create
a relaxing environment.
</p>

<p>
We serve handcrafted coffees, freshly baked desserts,
delicious pizzas, burgers and sandwiches made from
high-quality ingredients. Every item on our menu is prepared
with care to provide the perfect cafe experience.
</p>

<p>
Whether you are meeting friends, working on your ideas
or simply enjoying a quiet cup of coffee,
Veloura cafe offers a cozy and welcoming atmosphere.
</p>

</div>

</section>

<jsp:include page="/components/footer.jsp"/>
