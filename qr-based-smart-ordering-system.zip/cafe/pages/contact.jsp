<%@ page contentType="text/html;charset=UTF-8" %>
<%@ include file="/components/header.jsp" %>
<link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">

<section class="section" style="max-width:700px;margin:0 auto;">
  <h2 style="font-family:'Playfair Display',serif;color:#a16207;text-align:center;margin-bottom:10px;">Contact Us</h2>
  <p style="text-align:center;color:#777;margin-bottom:30px;">We'd love to hear from you. Fill out the form below!</p>

  <% if("true".equals(request.getParameter("sent"))){ %>
    <div style="background:#f0fdf4;color:#16a34a;padding:15px;border-radius:10px;margin-bottom:20px;text-align:center;font-weight:600;">
      &#10003; Message sent! We'll get back to you soon.
    </div>
  <% } %>

  <form class="contact-form" action="<%= request.getContextPath() %>/SubmitContact" method="post">
    <input  type="text"  name="name"    placeholder="Your Name"    required style="width:100%;padding:13px;border-radius:10px;border:1px solid #e5d5c8;background:#fffaf6;margin-bottom:15px;font-family:'Poppins',sans-serif;font-size:14px;">
    <input  type="email" name="email"   placeholder="Your Email"   required style="width:100%;padding:13px;border-radius:10px;border:1px solid #e5d5c8;background:#fffaf6;margin-bottom:15px;font-family:'Poppins',sans-serif;font-size:14px;">
    <textarea            name="message" placeholder="Your Message" required style="width:100%;padding:13px;border-radius:10px;border:1px solid #e5d5c8;background:#fffaf6;height:130px;resize:vertical;font-family:'Poppins',sans-serif;font-size:14px;margin-bottom:15px;"></textarea>
    <div style="text-align:center;">
      <button class="btn" type="submit" style="padding:13px 40px;font-size:15px;">Send Message</button>
    </div>
  </form>
</section>

<%@ include file="/components/footer.jsp" %>
