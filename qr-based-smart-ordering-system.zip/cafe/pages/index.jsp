<%@ include file="/components/header.jsp" %>

<link rel="stylesheet" href="/cafe/css/style.css">
<!-- HERO SECTION -->

<section class="hero">

<div class="hero-box">
<h1>Coffee and Cozy Bites</h1>
<p>Your coffee date deserves good food too.</p>

<a href="/cafe/user/menu.jsp" class="btn">Explore Menu</a>

</div>

</section>


<!-- SPECIAL MENU SECTION -->

<section class="section">

<h2>Our Special Menu</h2>

<div class="home-grid">

<div class="home-card">
<img src="https://images.unsplash.com/photo-1604382355076-af4b0eb60143?auto=format&fit=crop&w=800&q=80">
<h4>Italian Pizza</h4>
</div>

<div class="home-card">
<img src="https://images.unsplash.com/photo-1550547660-d9450f859349?auto=format&fit=crop&w=800&q=80">
<h4>Cheese Burger</h4>
</div>

<div class="home-card">
<img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80">
<h4>Caramel Latte</h4>
</div>

<div class="home-card">
<img src="https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=800&q=80">
<h4>Grilled Sandwich</h4>
</div>

</div>

</section>


<!-- CAFE GALLERY SECTION -->

<section class="section">

<h2>Our cafe Atmosphere</h2>

<div class="home-grid">

<div class="home-card">
<img src="https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?auto=format&fit=crop&w=900&q=80">
<h4>Cozy Interior</h4>
</div>

<div class="home-card">
<img src="https://images.unsplash.com/photo-1445116572660-236099ec97a0?auto=format&fit=crop&w=900&q=80">
<h4>cafe Seating</h4>
</div>

<div class="home-card">
<img src="https://images.unsplash.com/photo-1463797221720-6b07e6426c24?auto=format&fit=crop&w=900&q=80">
<h4>Coffee Corner</h4>
</div>

<div class="home-card">
<img src="https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=900&q=80">
<h4>Fresh Coffee</h4>
</div>

</div>

</section>

<section class="section about">

<img src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?auto=format&fit=crop&w=900&q=80">

<div class="about-text">

<h2>About Veloura Cafe</h2>

<p>
Veloura cafe is a modern aesthetic coffee space designed for calm,
comfort and creativity. Inspired by boutique cafe, our interiors
combine warm lighting, soft tones and minimalist design to create
a relaxing environment.
</p>

<p>
We serve handcrafted coffees, freshly baked desserts,
delicious pizzas, burgers and sandwiches made from
high-quality ingredients. Every item on our menu is prepared
with care to provide the perfect cafe experience.
</p>

<p>
Whether you are meeting friends, working on your ideas
or simply enjoying a quiet cup of coffee,
Veloura cafe offers a cozy and welcoming atmosphere.
</p>

</div>

</section>

<%@ include file="/components/footer.jsp" %>