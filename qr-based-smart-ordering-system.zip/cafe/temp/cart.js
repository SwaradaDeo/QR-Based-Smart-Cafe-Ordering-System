
document.addEventListener("DOMContentLoaded", renderCart);

function renderCart() {
    var cart   = JSON.parse(localStorage.getItem("cafeCart")) || {};
    var tbody  = document.getElementById("cartItems");
    var totEl  = document.getElementById("grandTotal");
    if (!tbody) return;

    var keys = Object.keys(cart);
    if (keys.length === 0) {
        tbody.innerHTML = "<tr><td colspan='4' style='text-align:center;padding:25px;color:#aaa;'>Cart is empty. <a href='menu.jsp' style='color:#a16207;'>Go to Menu</a></td></tr>";
        if (totEl) totEl.innerText = "0";
        return;
    }

    tbody.innerHTML = "";
    var grand = 0;
    keys.forEach(function(key) {
        var item  = cart[key];
        var total = item.price * item.quantity;
        grand += total;
        tbody.innerHTML += "<tr><td style='text-align:left'>" + item.name + "</td><td>&#8377;" + item.price + "</td><td>" + item.quantity + "</td><td>&#8377;" + total + "</td></tr>";
    });
    if (totEl) totEl.innerText = grand;
}

function placeOrder() {
    var cart = JSON.parse(localStorage.getItem("cafeCart")) || {};
    if (Object.keys(cart).length === 0) {
        alert("Your cart is empty! Please add items from the menu.");
        return;
    }

    var payment = document.querySelector('input[name="payment"]:checked').value;
    if (!confirm("Confirm order with payment via " + payment + "?")) return;

    var btn = document.getElementById("placeBtn");
    btn.disabled  = true;
    btn.innerText = "Placing Order...";

    var fd = new FormData();
    fd.append("items",         JSON.stringify(cart));
    fd.append("paymentMethod", payment);

    fetch(CTX + "/PlaceOrder", { method: "POST", body: fd })
        .then(function(r){ return r.json(); })
        .then(function(data) {
            if (data.success) {
                localStorage.removeItem("cafeCart");
                document.querySelector(".cart-card").style.display = "none";
                document.querySelector(".modify-btn").style.display = "none";
                btn.style.display = "none";
                startTracking(data.orderId, payment, data.total);
            } else {
                btn.disabled  = false;
                btn.innerText = "Place Order";
                alert("Error: " + data.message);
            }
        })
        .catch(function() {
            btn.disabled  = false;
            btn.innerText = "Place Order";
            alert("Network error. Please try again.");
        });
}

function startTracking(orderId, payment, total) {
    var box = document.getElementById("statusBox");
    box.style.display = "block";
    document.getElementById("orderInfo").innerText =
        "Order #" + orderId + "  |  Payment: " + payment + "  |  Total: Rs." + total;

    updateUI("New");

    var interval = setInterval(function() {
        fetch(CTX + "/OrderStatus?orderId=" + orderId)
            .then(function(r){ return r.json(); })
            .then(function(data) {
                updateUI(data.status);
                if (data.status === "Completed") {
                    clearInterval(interval);
                    setTimeout(function() {
                        if (confirm("Your order is complete! Leave us feedback?")) {
                            window.location.href = "feedback.jsp";
                        } else {
                            window.location.href = "menu.jsp";
                        }
                    }, 3000);
                }
            }).catch(function(){});
    }, 5000);
}

function updateUI(status) {
    var icon  = document.getElementById("statusIcon");
    var title = document.getElementById("statusTitle");
    var msg   = document.getElementById("statusMsg");
    var bar   = document.getElementById("progressBar");

    if (status === "New") {
        icon.innerText  = "⏳";
        title.innerText = "Order Received!";
        title.style.color = "#a16207";
        msg.innerText   = "Your order has been placed. Kitchen will start preparing it soon...";
        if (bar) bar.style.width = "15%";
    } else if (status === "Preparing") {
        icon.innerText  = "🍳";
        title.innerText = "Being Prepared";
        title.style.color = "#1d4ed8";
        msg.innerText   = "Our chefs are preparing your fresh order!";
        if (bar) bar.style.width = "55%";
    } else if (status === "Ready") {
        icon.innerText  = "✅";
        title.innerText = "Ready for Pickup!";
        title.style.color = "#16a34a";
        msg.innerText   = "Your order is ready! Please collect it from the counter.";
        if (bar) bar.style.width = "80%";
    } else if (status === "Completed") {
        icon.innerText  = "🎉";
        title.innerText = "Order Completed!";
        title.style.color = "#16a34a";
        msg.innerHTML   = "<strong>Thank you for dining at Veloura Cafe!</strong><br>We hope you enjoyed your meal!";
        if (bar) { bar.style.width = "100%"; bar.style.background = "#16a34a"; }
        document.getElementById("statusBox").style.background = "#f0fdf4";
        document.getElementById("statusBox").style.borderColor = "#86efac";
    }
}
