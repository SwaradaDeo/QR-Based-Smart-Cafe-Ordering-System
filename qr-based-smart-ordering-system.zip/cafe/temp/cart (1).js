
document.addEventListener("DOMContentLoaded", renderCart);

function getCart() {
    var cart = JSON.parse(localStorage.getItem("cafeCart")) || {};
    if (Object.keys(cart).length === 0) {
        var old = JSON.parse(localStorage.getItem("cart")) || {};
        if (Object.keys(old).length > 0) {
            localStorage.setItem("cafeCart", JSON.stringify(old));
            localStorage.removeItem("cart");
            return old;
        }
    }
    return cart;
}

function renderCart() {
    var cart  = getCart();
    var tbody = document.getElementById("cartItems");
    var totEl = document.getElementById("grandTotal");
    if (!tbody) return;

    var keys = Object.keys(cart);
    if (keys.length === 0) {
        tbody.innerHTML = "<tr><td colspan='4' style='text-align:center;padding:30px;color:#aaa;'>Your cart is empty.<br><a href='menu.jsp' style='color:#a16207;font-weight:600;'>&#8592; Go to Menu</a></td></tr>";
        if (totEl) totEl.innerText = "0";
        return;
    }

    tbody.innerHTML = "";
    var grand = 0;
    keys.forEach(function(key) {
        var item  = cart[key];
        var total = item.price * item.quantity;
        grand    += total;
        tbody.innerHTML +=
            "<tr>" +
            "<td style='text-align:left;font-weight:500;padding:12px 8px;'>" + item.name + "</td>" +
            "<td style='text-align:center;'>&#8377;" + item.price + "</td>" +
            "<td style='text-align:center;'>" + item.quantity + "</td>" +
            "<td style='text-align:center;font-weight:600;color:#a16207;'>&#8377;" + total + "</td>" +
            "</tr>";
    });
    if (totEl) totEl.innerText = grand;
}

function placeOrder() {
    var cart = getCart();
    if (Object.keys(cart).length === 0) {
        alert("Your cart is empty! Please add items from the menu.");
        return;
    }
    var paymentEl = document.querySelector('input[name="payment"]:checked');
    if (!paymentEl) { alert("Please select a payment method."); return; }
    var payment = paymentEl.value;

    if (!confirm("Confirm order with payment via " + payment + "?")) return;

    var btn = document.getElementById("placeBtn");
    if (btn) { btn.disabled = true; btn.innerText = "Placing Order..."; }

    var body = "items=" + encodeURIComponent(JSON.stringify(cart)) +
               "&paymentMethod=" + encodeURIComponent(payment);

    fetch(CTX + "/PlaceOrder", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: body
    })
    .then(function(r) { return r.text(); })
    .then(function(text) {
        var data;
        try { data = JSON.parse(text); } catch(e) {
            if (btn) { btn.disabled=false; btn.innerText="Place Order"; }
            alert("Server error: " + text.substring(0,150));
            return;
        }
        if (data.success) {
            // Save cart snapshot for invoice BEFORE clearing
            var cartSnapshot = JSON.parse(localStorage.getItem("cafeCart")) || {};
            localStorage.removeItem("cafeCart");
            localStorage.removeItem("cart");

            // Hide cart table and payment card
            var cartCard   = document.getElementById("cartCard");
            var payCard    = document.getElementById("paymentCard");
            if (cartCard) cartCard.style.display = "none";
            if (payCard)  payCard.style.display  = "none";

            startTracking(data.orderId, payment, data.total, cartSnapshot);
        } else {
            if (btn) { btn.disabled=false; btn.innerText="Place Order"; }
            alert("Error: " + (data.message || "Unknown error"));
        }
    })
    .catch(function(err) {
        if (btn) { btn.disabled=false; btn.innerText="Place Order"; }
        alert("Network error. Try again.");
    });
}

function startTracking(orderId, payment, total, cartSnapshot) {
    var box = document.getElementById("statusBox");
    if (box) box.style.display = "block";
    var infoEl = document.getElementById("orderInfo");
    if (infoEl) infoEl.innerText = "Order #" + orderId + "  |  " + payment + "  |  Rs." + total;

    updateStatusUI("New");

    var interval = setInterval(function() {
        fetch(CTX + "/OrderStatus?orderId=" + orderId)
            .then(function(r) { return r.json(); })
            .then(function(data) {
                updateStatusUI(data.status);
                if (data.status === "Completed") {
                    clearInterval(interval);
                    // Show invoice after 1.5 seconds
                    setTimeout(function() {
                        showInvoice(orderId, payment, total, cartSnapshot);
                    }, 1500);
                }
            }).catch(function(){});
    }, 5000);
}

function updateStatusUI(status) {
    var icon  = document.getElementById("statusIcon");
    var title = document.getElementById("statusTitle");
    var msg   = document.getElementById("statusMsg");
    var bar   = document.getElementById("progressBar");

    if (status === "New") {
        if(icon)  icon.innerText  = "\u23F3";
        if(title) { title.innerText="Order Received!"; title.style.color="#a16207"; }
        if(msg)   msg.innerText   = "Your order is placed. The kitchen will start soon...";
        if(bar)   bar.style.width = "15%";
    } else if (status === "Preparing") {
        if(icon)  icon.innerText  = "\uD83C\uDF73";
        if(title) { title.innerText="Being Prepared!"; title.style.color="#1d4ed8"; }
        if(msg)   msg.innerText   = "Our chefs are preparing your fresh order!";
        if(bar)   bar.style.width = "55%";
    } else if (status === "Ready") {
        if(icon)  icon.innerText  = "\u2705";
        if(title) { title.innerText="Ready for Pickup!"; title.style.color="#16a34a"; }
        if(msg)   msg.innerText   = "Your order is ready! Please collect from the counter.";
        if(bar)   bar.style.width = "80%";
    } else if (status === "Completed") {
        if(icon)  icon.innerText  = "\uD83C\uDF89";
        if(title) { title.innerText="Order Completed!"; title.style.color="#16a34a"; }
        if(msg)   msg.innerHTML   = "<strong>Thank you for dining at Veloura Cafe!</strong><br>Your invoice is ready below.";
        if(bar)   { bar.style.width="100%"; bar.style.background="#16a34a"; }
        var box = document.getElementById("statusBox");
        if(box)   { box.style.background="#f0fdf4"; box.style.borderColor="#86efac"; }
    }
}

function showInvoice(orderId, payment, total, cart) {
    var box = document.getElementById("invoiceBox");
    if (!box) return;
    box.style.display = "block";

    var now  = new Date();
    var date = now.toLocaleDateString("en-IN", {day:"2-digit",month:"short",year:"numeric"});
    var time = now.toLocaleTimeString("en-IN", {hour:"2-digit",minute:"2-digit"});

    var rows = "";
    var keys = Object.keys(cart);
    keys.forEach(function(k) {
        var item = cart[k];
        var sub  = item.price * item.quantity;
        rows += "<tr>" +
            "<td style='padding:9px 8px;text-align:left;border-bottom:1px solid #f3e8e2;'>" + item.name + "</td>" +
            "<td style='padding:9px 8px;text-align:center;border-bottom:1px solid #f3e8e2;'>&#8377;" + item.price + "</td>" +
            "<td style='padding:9px 8px;text-align:center;border-bottom:1px solid #f3e8e2;'>" + item.quantity + "</td>" +
            "<td style='padding:9px 8px;text-align:right;border-bottom:1px solid #f3e8e2;font-weight:600;color:#a16207;'>&#8377;" + sub + "</td>" +
            "</tr>";
    });

    box.innerHTML =
        "<div id='invoicePrint' style='background:#fff;border-radius:18px;padding:30px;box-shadow:0 8px 24px rgba(0,0,0,.1);font-family:Poppins,sans-serif;'>" +

        // Header
        "<div style='text-align:center;margin-bottom:20px;padding-bottom:18px;border-bottom:2px solid #f3e8e2;'>" +
        "<div style='font-size:36px;margin-bottom:6px;'>&#9749;</div>" +
        "<h2 style='font-family:Playfair Display,serif;color:#a16207;font-size:22px;margin-bottom:2px;'>Veloura Cafe</h2>" +
        "<p style='color:#999;font-size:12px;'>QR Based Smart Ordering System</p>" +
        "</div>" +

        // Invoice info
        "<div style='display:flex;justify-content:space-between;margin-bottom:18px;font-size:13px;'>" +
        "<div><strong>Invoice #" + orderId + "</strong><br><span style='color:#999;'>" + date + " at " + time + "</span></div>" +
        "<div style='text-align:right;'><strong>Payment: " + payment + "</strong><br><span style='background:#dcfce7;color:#16a34a;padding:2px 10px;border-radius:10px;font-size:11px;font-weight:600;'>PAID</span></div>" +
        "</div>" +

        // Items table
        "<table style='width:100%;border-collapse:collapse;margin-bottom:15px;font-size:13px;'>" +
        "<thead><tr style='background:#fdf6f0;'>" +
        "<th style='padding:10px 8px;text-align:left;color:#a16207;'>Item</th>" +
        "<th style='padding:10px 8px;text-align:center;color:#a16207;'>Price</th>" +
        "<th style='padding:10px 8px;text-align:center;color:#a16207;'>Qty</th>" +
        "<th style='padding:10px 8px;text-align:right;color:#a16207;'>Total</th>" +
        "</tr></thead><tbody>" + rows + "</tbody>" +
        "</table>" +

        // Total
        "<div style='text-align:right;font-size:18px;font-weight:700;color:#a16207;border-top:2px solid #f3e8e2;padding-top:12px;margin-bottom:20px;'>" +
        "Grand Total: &#8377;" + total +
        "</div>" +

        // Footer
        "<div style='text-align:center;color:#bbb;font-size:12px;border-top:1px dashed #f3e8e2;padding-top:15px;margin-bottom:20px;'>" +
        "Thank you for your order! We hope to see you again. &#128149;" +
        "</div>" +

        // Buttons
        "<div style='display:flex;gap:12px;justify-content:center;'>" +
        "<button onclick='printInvoice()' style='background:linear-gradient(135deg,#f59e0b,#a16207);color:#fff;border:none;padding:12px 28px;border-radius:10px;cursor:pointer;font-size:14px;font-weight:600;font-family:Poppins,sans-serif;'>&#128438; Print Invoice</button>" +
        "<a href='menu.jsp' style='background:#f3f4f6;color:#3b2f2f;border:none;padding:12px 28px;border-radius:10px;cursor:pointer;font-size:14px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;'>&#128722; Order Again</a>" +
        "<a href='feedback.jsp' style='background:#fdf6f0;color:#a16207;border:none;padding:12px 28px;border-radius:10px;cursor:pointer;font-size:14px;font-weight:600;text-decoration:none;display:inline-flex;align-items:center;'>&#11088; Feedback</a>" +
        "</div>" +
        "</div>";

    // Scroll to invoice
    box.scrollIntoView({ behavior: "smooth", block: "start" });
}

function printInvoice() {
    var content = document.getElementById("invoicePrint").innerHTML;
    var win = window.open("","_blank","width=600,height=700");
    win.document.write(
        "<html><head><title>Invoice - Veloura Cafe</title>" +
        "<link href='https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@400;500;600&display=swap' rel='stylesheet'>" +
        "<style>body{font-family:Poppins,sans-serif;padding:30px;max-width:560px;margin:auto;}@media print{button,.no-print{display:none!important;}}</style>" +
        "</head><body>" + content + "</body></html>"
    );
    win.document.close();
    setTimeout(function(){ win.print(); }, 800);
}
