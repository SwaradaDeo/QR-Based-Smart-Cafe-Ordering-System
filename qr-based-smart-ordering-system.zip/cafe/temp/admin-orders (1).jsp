<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
%>
<!DOCTYPE html><html><head>
<title>Orders - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;text-decoration:none;color:#555;font-size:14px;font-weight:500;transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;}
.logout-btn:hover{background:#dc2626;color:#fff;}
.main{margin-left:230px;flex:1;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);position:sticky;top:0;z-index:50;}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}
.board{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;}
.col{background:#fff;border-radius:14px;padding:18px;box-shadow:0 4px 15px rgba(0,0,0,.06);}
.col-title{font-size:14px;font-weight:700;padding-bottom:12px;margin-bottom:12px;border-bottom:2px solid #f3e8e2;display:flex;align-items:center;justify-content:space-between;}
.col-new .col-title{color:#a16207;}
.col-prep .col-title{color:#1d4ed8;}
.col-ready .col-title{color:#16a34a;}
.count{background:#f3e8e2;padding:2px 9px;border-radius:10px;font-size:11px;}
.ocard{background:#fdfaf7;border-radius:10px;padding:13px;margin-bottom:10px;border:1px solid #f3e8e2;}
.o-id{font-size:13px;font-weight:700;color:#3b2f2f;margin-bottom:4px;}
.o-meta{font-size:12px;color:#888;margin-bottom:3px;}
.o-table{font-size:12px;font-weight:600;color:#a16207;background:#fdf6f0;padding:2px 8px;border-radius:6px;display:inline-block;margin-bottom:5px;}
.o-amt{font-size:14px;font-weight:700;color:#a16207;margin-bottom:8px;}
.move-btn{width:100%;padding:8px;border:none;border-radius:7px;cursor:pointer;font-size:12px;font-weight:600;font-family:"Poppins",sans-serif;}
.btn-prep{background:#dbeafe;color:#1d4ed8;} .btn-prep:hover{background:#1d4ed8;color:#fff;}
.btn-ready{background:#dcfce7;color:#16a34a;} .btn-ready:hover{background:#16a34a;color:#fff;}
.btn-done{background:#f3f4f6;color:#6b7280;} .btn-done:hover{background:#6b7280;color:#fff;}
.empty{text-align:center;color:#ccc;font-size:13px;padding:20px;}
.refresh-btn{background:#a16207;color:#fff;border:none;padding:7px 16px;border-radius:7px;cursor:pointer;font-size:13px;font-family:"Poppins",sans-serif;}
@media(max-width:900px){.board{grid-template-columns:1fr;}}
</style>
</head><body>

<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp" class="active">&#128230; Orders</a></li>
    <li><a href="admin-tables.jsp">&#128196; Tables & QR</a></li>
    <li><a href="admin-manage-menu.jsp">&#127869; Manage Menu</a></li>
    <li><a href="feedback-admin.jsp">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact</a></li>
  </ul>
  <div class="sidebar-footer"><a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a></div>
</aside>

<div class="main">
  <div class="topbar">
    <h1>Orders Management</h1>
    <div style="display:flex;gap:10px;align-items:center;">
      <button class="refresh-btn" onclick="location.reload()">&#8635; Refresh</button>
      <div class="admin-badge">&#128100; <%= session.getAttribute("adminUser") %></div>
    </div>
  </div>
  <div class="content">
    <div class="board">

<%
String[] statuses   = {"New","Preparing","Ready"};
String[] colClasses = {"col-new","col-prep","col-ready"};
String[] icons      = {"&#128338;","&#127859;","&#9989;"};
String[] nextStatus = {"Preparing","Ready","Completed"};
String[] btnClasses = {"btn-prep","btn-ready","btn-done"};
String[] btnLabels  = {"&#127859; Start Preparing","&#9989; Mark Ready","&#127937; Complete"};

for(int s=0; s<3; s++){
  String st = statuses[s];
%>
      <div class="col <%= colClasses[s] %>">
        <div class="col-title">
          <%= icons[s] %> <%= st.equals("New")?"New Orders":st %>
          <%try(Connection c=DBConnection.getConnection()){
            PreparedStatement ps=c.prepareStatement("SELECT COUNT(*) FROM orders WHERE order_status=?");
            ps.setString(1,st); ResultSet r=ps.executeQuery();
            if(r.next()) out.print("<span class='count'>"+r.getInt(1)+"</span>");
          }catch(Exception e){}%>
        </div>
<%
  Connection conn2=null;
  try{
    conn2=DBConnection.getConnection();
    PreparedStatement ps2=conn2.prepareStatement(
      "SELECT o.order_id, o.total_amount, o.order_time, u.name, u.email, t.table_number " +
      "FROM orders o " +
      "JOIN users u ON o.user_id=u.user_id " +
      "LEFT JOIN tables t ON o.table_id=t.table_id " +
      "WHERE o.order_status=? ORDER BY o.order_time DESC");
    ps2.setString(1,st);
    ResultSet rs2=ps2.executeQuery();
    boolean any=false;
    while(rs2.next()){any=true;
      int tnum2 = rs2.getInt("table_number");
%>
        <div class="ocard">
          <div class="o-id">Order #<%= rs2.getInt("order_id") %></div>
          <% if(tnum2 > 0){ %><span class="o-table">&#128196; Table #<%= tnum2 %></span><% } %>
          <div class="o-meta">&#128100; <%= rs2.getString("name") %></div>
          <div class="o-amt">&#8377;<%= String.format("%.2f",rs2.getDouble("total_amount")) %></div>
          <div class="o-meta" style="margin-bottom:8px;">&#128336; <%= rs2.getTimestamp("order_time").toString().substring(0,16) %></div>
          <form method="post" action="<%= request.getContextPath() %>/UpdateOrderStatus">
            <input type="hidden" name="orderId" value="<%= rs2.getInt("order_id") %>">
            <input type="hidden" name="status"  value="<%= nextStatus[s] %>">
            <button class="move-btn <%= btnClasses[s] %>" type="submit"><%= btnLabels[s] %></button>
          </form>
        </div>
<%    }
    if(!any){out.print("<div class='empty'>No orders</div>");}
  }catch(Exception e2){out.print("<div class='empty' style='color:red;'>"+e2.getMessage()+"</div>");
  }finally{if(conn2!=null)try{conn2.close();}catch(Exception e3){}}
%>
      </div>
<% } %>
    </div>
  </div>
</div>
</body></html>
