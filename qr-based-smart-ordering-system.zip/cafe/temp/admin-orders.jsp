<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
%>
<!DOCTYPE html><html><head>
<title>Orders - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;text-decoration:none;color:#555;font-size:14px;font-weight:500;transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;font-weight:500;}
.logout-btn:hover{background:#dc2626;color:#fff;}
.main{margin-left:230px;flex:1;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);position:sticky;top:0;z-index:50;}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}
.board{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;}
.col{background:#fff;border-radius:16px;padding:20px;box-shadow:0 4px 15px rgba(0,0,0,.06);}
.col-title{font-size:15px;font-weight:600;padding-bottom:14px;margin-bottom:14px;border-bottom:2px solid #f3e8e2;display:flex;align-items:center;justify-content:space-between;}
.col-new .col-title{color:#a16207;}
.col-prep .col-title{color:#1d4ed8;}
.col-ready .col-title{color:#16a34a;}
.count-badge{background:#f3e8e2;padding:2px 10px;border-radius:10px;font-size:12px;}
.order-card{background:#fdfaf7;border-radius:10px;padding:14px;margin-bottom:12px;border:1px solid #f3e8e2;}
.order-id{font-size:13px;font-weight:700;color:#3b2f2f;margin-bottom:5px;}
.order-meta{font-size:12px;color:#888;margin-bottom:4px;}
.order-amount{font-size:14px;font-weight:700;color:#a16207;margin-bottom:10px;}
.move-form button{width:100%;padding:9px;border:none;border-radius:8px;cursor:pointer;font-size:12px;font-weight:600;transition:.2s;}
.btn-prepare{background:#dbeafe;color:#1d4ed8;}
.btn-prepare:hover{background:#1d4ed8;color:#fff;}
.btn-ready{background:#dcfce7;color:#16a34a;}
.btn-ready:hover{background:#16a34a;color:#fff;}
.btn-complete{background:#f3f4f6;color:#6b7280;}
.btn-complete:hover{background:#6b7280;color:#fff;}
.empty{text-align:center;color:#ccc;font-size:13px;padding:25px;}
.refresh-btn{background:#a16207;color:#fff;border:none;padding:8px 18px;border-radius:8px;cursor:pointer;font-size:13px;}
@media(max-width:900px){.board{grid-template-columns:1fr;}}
</style>
</head><body>

<aside class="sidebar">
  <div class="sidebar-logo">☕ Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">📊 Dashboard</a></li>
    <li><a href="admin-orders.jsp" class="active">📦 Orders</a></li>
    <li><a href="admin-manage-menu.jsp">🍽️ Manage Menu</a></li>
    <li><a href="feedback-admin.jsp">💬 Feedback</a></li>
    <li><a href="contact-admin.jsp">📩 Contact Messages</a></li>
  </ul>
  <div class="sidebar-footer"><a href="<%= request.getContextPath() %>/logout" class="logout-btn">🚪 Logout</a></div>
</aside>

<div class="main">
  <div class="topbar">
    <h1>Orders Management</h1>
    <div style="display:flex;align-items:center;gap:12px;">
      <button class="refresh-btn" onclick="location.reload()">&#8635; Refresh</button>
      <div class="admin-badge">👤 <%= session.getAttribute("adminUser") %></div>
    </div>
  </div>

  <div class="content">
    <div class="board">

      <!-- NEW -->
      <div class="col col-new">
        <div class="col-title">🆕 New Orders
          <%try(Connection c=DBConnection.getConnection()){ResultSet r=c.prepareStatement("SELECT COUNT(*) FROM orders WHERE order_status='New'").executeQuery();if(r.next())out.print("<span class='count-badge'>"+r.getInt(1)+"</span>");}catch(Exception e){}%>
        </div>
        <%try(Connection c=DBConnection.getConnection()){
          ResultSet r=c.prepareStatement("SELECT o.order_id,u.name,u.email,o.total_amount,o.order_time FROM orders o JOIN users u ON o.user_id=u.user_id WHERE o.order_status='New' ORDER BY o.order_time DESC").executeQuery();
          boolean any=false;
          while(r.next()){any=true;%>
          <div class="order-card">
            <div class="order-id">Order #<%= r.getInt("order_id") %></div>
            <div class="order-meta">👤 <%= r.getString("name") %></div>
            <div class="order-meta">📧 <%= r.getString("email") %></div>
            <div class="order-amount">&#8377;<%= String.format("%.2f",r.getDouble("total_amount")) %></div>
            <div class="order-meta" style="margin-bottom:10px;">🕐 <%= r.getTimestamp("order_time").toString().substring(0,16) %></div>
            <form class="move-form" method="post" action="<%= request.getContextPath() %>/UpdateOrderStatus">
              <input type="hidden" name="orderId" value="<%= r.getInt("order_id") %>">
              <input type="hidden" name="status"  value="Preparing">
              <button class="btn-prepare" type="submit">🍳 Start Preparing</button>
            </form>
          </div>
        <%}if(!any){%><div class="empty">No new orders</div><%}
        }catch(Exception e){out.print("<div class='empty'>Error: "+e.getMessage()+"</div>");}%>
      </div>

      <!-- PREPARING -->
      <div class="col col-prep">
        <div class="col-title">👨‍🍳 Preparing</div>
        <%try(Connection c=DBConnection.getConnection()){
          ResultSet r=c.prepareStatement("SELECT o.order_id,u.name,o.total_amount,o.order_time FROM orders o JOIN users u ON o.user_id=u.user_id WHERE o.order_status='Preparing' ORDER BY o.order_time DESC").executeQuery();
          boolean any=false;
          while(r.next()){any=true;%>
          <div class="order-card">
            <div class="order-id">Order #<%= r.getInt("order_id") %></div>
            <div class="order-meta">👤 <%= r.getString("name") %></div>
            <div class="order-amount">&#8377;<%= String.format("%.2f",r.getDouble("total_amount")) %></div>
            <div class="order-meta" style="margin-bottom:10px;">🕐 <%= r.getTimestamp("order_time").toString().substring(0,16) %></div>
            <form class="move-form" method="post" action="<%= request.getContextPath() %>/UpdateOrderStatus">
              <input type="hidden" name="orderId" value="<%= r.getInt("order_id") %>">
              <input type="hidden" name="status"  value="Ready">
              <button class="btn-ready" type="submit">✅ Mark Ready</button>
            </form>
          </div>
        <%}if(!any){%><div class="empty">No orders being prepared</div><%}
        }catch(Exception e){out.print("<div class='empty'>Error: "+e.getMessage()+"</div>");}%>
      </div>

      <!-- READY -->
      <div class="col col-ready">
        <div class="col-title">✅ Ready / Completed</div>
        <%try(Connection c=DBConnection.getConnection()){
          ResultSet r=c.prepareStatement("SELECT o.order_id,u.name,o.total_amount,o.order_status,o.order_time FROM orders o JOIN users u ON o.user_id=u.user_id WHERE o.order_status IN('Ready','Completed') ORDER BY o.order_time DESC LIMIT 10").executeQuery();
          boolean any=false;
          while(r.next()){any=true;
            String st=r.getString("order_status");
            String bc="Ready".equals(st)?"btn-complete":"";%>
          <div class="order-card">
            <div class="order-id">Order #<%= r.getInt("order_id") %> <small style="color:<%= "Ready".equals(st)?"#16a34a":"#6b7280" %>">(<%= st %>)</small></div>
            <div class="order-meta">👤 <%= r.getString("name") %></div>
            <div class="order-amount">&#8377;<%= String.format("%.2f",r.getDouble("total_amount")) %></div>
            <div class="order-meta" style="margin-bottom:10px;">🕐 <%= r.getTimestamp("order_time").toString().substring(0,16) %></div>
            <% if("Ready".equals(st)){ %>
            <form class="move-form" method="post" action="<%= request.getContextPath() %>/UpdateOrderStatus">
              <input type="hidden" name="orderId" value="<%= r.getInt("order_id") %>">
              <input type="hidden" name="status"  value="Completed">
              <button class="btn-complete" type="submit">🏁 Mark Completed</button>
            </form>
            <% } %>
          </div>
        <%}if(!any){%><div class="empty">No ready/completed orders</div><%}
        }catch(Exception e){out.print("<div class='empty'>Error: "+e.getMessage()+"</div>");}%>
      </div>

    </div>
  </div>
</div>
</body></html>
