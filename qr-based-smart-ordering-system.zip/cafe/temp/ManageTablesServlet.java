package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ManageTables")
public class ManageTablesServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminUser") == null) {
            response.sendRedirect(request.getContextPath() + "/admin/admin-login.jsp");
            return;
        }

        String action = request.getParameter("action");
        String msg    = "error";
        Connection conn = null;

        try {
            conn = DBConnection.getConnection();

            if ("addTable".equals(action)) {
                int tableNumber = Integer.parseInt(request.getParameter("tableNumber"));
                // Check duplicate
                PreparedStatement check = conn.prepareStatement(
                    "SELECT table_id FROM tables WHERE table_number=?");
                check.setInt(1, tableNumber);
                if (check.executeQuery().next()) {
                    msg = "error";
                } else {
                    PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO tables(table_number, status) VALUES(?, 'available')");
                    ps.setInt(1, tableNumber);
                    ps.executeUpdate();
                    msg = "added";
                }

            } else if ("deleteTable".equals(action)) {
                int tableId = Integer.parseInt(request.getParameter("tableId"));
                PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM tables WHERE table_id=?");
                ps.setInt(1, tableId);
                ps.executeUpdate();
                msg = "deleted";

            } else if ("resetTable".equals(action)) {
                int tableId = Integer.parseInt(request.getParameter("tableId"));
                PreparedStatement ps = conn.prepareStatement(
                    "UPDATE tables SET status='available' WHERE table_id=?");
                ps.setInt(1, tableId);
                ps.executeUpdate();
                msg = "reset";
            }

        } catch (Exception e) {
            e.printStackTrace();
            msg = "error";
        } finally {
            if (conn != null) try { conn.close(); } catch (Exception ignored) {}
        }

        response.sendRedirect(request.getContextPath() + "/admin/admin-tables.jsp?msg=" + msg);
    }
}
