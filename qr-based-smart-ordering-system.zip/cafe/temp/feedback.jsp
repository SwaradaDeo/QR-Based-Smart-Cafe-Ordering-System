<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="/components/header.jsp" %>
<link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
<link rel="stylesheet" href="<%= request.getContextPath() %>/css/feedback.css">

<section class="feedback-wrapper">
  <h1 class="feedback-title">Guest Feedback</h1>
  <p class="feedback-sub">Your Thoughts — How was your experience?</p>

  <% if("true".equals(request.getParameter("sent"))){ %>
    <div style="text-align:center;background:#f0fdf4;color:#16a34a;padding:15px;border-radius:10px;margin-bottom:20px;font-weight:600;">
      &#10003; Thank you! Your feedback has been submitted.
    </div>
  <% } %>

  <form action="<%= request.getContextPath() %>/SubmitFeedback" method="post">

    <div class="feedback-card">
      <div class="feedback-left">
        <label>Overall Comments</label>
        <textarea name="comments" placeholder="Tell us about your experience..." required></textarea>
      </div>

      <div class="feedback-right">
        <div class="rating-item">
          <p>Overall Rating</p>
          <div class="stars" id="starGroup">
            <span data-val="1">&#9733;</span>
            <span data-val="2">&#9733;</span>
            <span data-val="3">&#9733;</span>
            <span data-val="4">&#9733;</span>
            <span data-val="5">&#9733;</span>
          </div>
          <input type="hidden" name="rating" id="ratingInput" value="5">
        </div>
      </div>
    </div>

    <div class="submit-box">
      <% if(session.getAttribute("userId") == null){ %>
        <p style="color:#dc2626;margin-bottom:10px;">Please <a href="<%= request.getContextPath() %>/user/login.jsp">login</a> to submit feedback.</p>
      <% } %>
      <button type="submit" class="submit-btn" <%= session.getAttribute("userId")==null?"disabled":"" %>>Submit Feedback</button>
    </div>

  </form>
</section>

<script>
var stars = document.querySelectorAll("#starGroup span");
var ratingInput = document.getElementById("ratingInput");
stars.forEach(function(star) {
    star.style.cursor = "pointer";
    star.style.fontSize = "28px";
    star.style.color = "#f59e0b";
    star.addEventListener("click", function() {
        var val = parseInt(this.getAttribute("data-val"));
        ratingInput.value = val;
        stars.forEach(function(s, i) {
            s.style.color = i < val ? "#f59e0b" : "#ddd";
        });
    });
    star.addEventListener("mouseover", function() {
        var val = parseInt(this.getAttribute("data-val"));
        stars.forEach(function(s, i) { s.style.color = i < val ? "#f59e0b" : "#ddd"; });
    });
});
</script>

<%@ include file="/components/footer.jsp" %>
