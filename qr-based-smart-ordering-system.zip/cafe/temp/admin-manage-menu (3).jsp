<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html><head>
<title>Manage Menu - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>

*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f5ede3;display:flex;}
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;
  box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;
  color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;
  text-decoration:none;color:#555;font-size:14px;font-weight:500;
  transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;
  color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;font-weight:600;}
.logout-btn:hover{background:#dc2626;color:#fff;}
.main{margin-left:230px;flex:1;min-height:100vh;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;
  align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);position:sticky;top:0;z-index:50;}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;
  font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:30px 35px;}


/* ── TOP ADD CATEGORY BAR ─────────────────────────────── */
.add-cat-bar{
  background:#fff;border-radius:14px;padding:20px 24px;
  box-shadow:0 4px 12px rgba(0,0,0,.06);margin-bottom:28px;
  display:flex;gap:12px;align-items:center;flex-wrap:wrap;
}
.add-cat-bar input{
  flex:1;min-width:140px;padding:11px 14px;
  border:1.5px solid #e8ddd5;border-radius:10px;
  font-family:"Poppins",sans-serif;font-size:13px;color:#3b2f2f;background:#fffaf6;
}
.add-cat-bar input:focus{outline:none;border-color:#a16207;background:#fff;}
.btn-gold{
  background:#a16207;color:#fff;border:none;padding:11px 22px;
  border-radius:10px;cursor:pointer;font-size:13px;font-weight:600;
  font-family:"Poppins",sans-serif;white-space:nowrap;transition:.2s;
}
.btn-gold:hover{background:#78350f;}

/* ── CATEGORY GRID ─────────────────────────────────────── */
.cat-grid{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:24px;
}

/* ── CATEGORY CARD ─────────────────────────────────────── */
.cat-card{
  background:#fff;border-radius:16px;padding:24px;
  box-shadow:0 4px 14px rgba(0,0,0,.07);
}
.cat-card-header{
  display:flex;justify-content:space-between;align-items:center;
  margin-bottom:18px;border-bottom:2px solid #f3e8e2;padding-bottom:12px;
}
.cat-card h3{
  font-family:"Playfair Display",serif;font-size:20px;
  color:#a16207;margin:0;
}
.btn-del-cat{
  background:#fee2e2;color:#dc2626;border:none;padding:7px 14px;
  border-radius:8px;cursor:pointer;font-size:12px;font-weight:600;
  font-family:"Poppins",sans-serif;transition:.2s;white-space:nowrap;
}
.btn-del-cat:hover{background:#dc2626;color:#fff;}

/* ── ITEM ROW ───────────────────────────────────────────── */
.item-row{
  display:grid;grid-template-columns:1fr 70px 70px 70px;
  align-items:center;gap:8px;
  padding:11px 0;border-bottom:1px solid #f3e8e2;font-size:13px;
}
.item-row:last-of-type{border-bottom:none;}
.item-name-txt{color:#3b2f2f;font-weight:500;}
.item-price-txt{color:#a16207;font-weight:700;}
.btn-edit{
  background:#a16207;color:#fff;border:none;padding:6px 12px;
  border-radius:7px;cursor:pointer;font-size:12px;font-family:"Poppins",sans-serif;
}
.btn-edit:hover{background:#78350f;}
.btn-del{
  background:#a16207;color:#fff;border:none;padding:6px 12px;
  border-radius:7px;cursor:pointer;font-size:12px;font-family:"Poppins",sans-serif;
}
.btn-del:hover{background:#7c1d1d;}

/* ── ADD ITEM ROW ───────────────────────────────────────── */
.add-item-row{
  display:flex;gap:8px;margin-top:16px;align-items:center;
}
.add-item-row input{
  flex:1;padding:9px 12px;border:1.5px solid #e8ddd5;border-radius:8px;
  font-family:"Poppins",sans-serif;font-size:13px;background:#fffaf6;
}
.add-item-row input:focus{outline:none;border-color:#a16207;}
.add-item-row .price-in{max-width:90px;}
.btn-add-item{
  background:#a16207;color:#fff;border:none;padding:9px 18px;
  border-radius:8px;cursor:pointer;font-size:13px;font-weight:600;
  font-family:"Poppins",sans-serif;white-space:nowrap;
}
.btn-add-item:hover{background:#78350f;}

.alert{padding:11px 16px;border-radius:9px;font-size:13px;font-weight:500;margin-bottom:18px;}
.alert-success{background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;}
.alert-error  {background:#fef2f2;color:#dc2626;border:1px solid #fecaca;}

/* edit modal */
.modal-bg{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:200;align-items:center;justify-content:center;}
.modal-bg.open{display:flex;}
.modal{background:#fff;border-radius:16px;padding:30px;width:360px;box-shadow:0 20px 50px rgba(0,0,0,.2);}
.modal h3{font-family:"Playfair Display",serif;color:#a16207;margin-bottom:18px;font-size:18px;}
.modal input{width:100%;padding:10px 13px;border:1.5px solid #e8ddd5;border-radius:9px;
  font-family:"Poppins",sans-serif;font-size:13px;margin-bottom:13px;background:#fffaf6;}
.modal input:focus{outline:none;border-color:#a16207;}
.modal-btns{display:flex;gap:10px;justify-content:flex-end;}
.btn-cancel{background:#f3f4f6;color:#555;border:none;padding:9px 18px;border-radius:8px;cursor:pointer;font-family:"Poppins",sans-serif;}

@media(max-width:1100px){.cat-grid{grid-template-columns:repeat(2,1fr);}}
@media(max-width:700px) {.cat-grid{grid-template-columns:1fr;}}
</style>
</head><body>

<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp">&#128230; Orders</a></li>
    <li><a href="admin-tables.jsp">&#128196; Tables &amp; QR</a></li>
    <li><a href="admin-manage-menu.jsp" id="nav-menu">&#127869; Manage Menu</a></li>
    <li><a href="admin-payments.jsp">&#128179; Payments</a></li>
    <li><a href="admin-reports.jsp">&#128200; Reports</a></li>
    <li><a href="feedback-admin.jsp" id="nav-feedback">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact</a></li>
  </ul>
  <div class="sidebar-footer">
    <a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <h1>Menu Manager</h1>
    <div class="admin-badge">&#128100; <%= session.getAttribute("adminUser") %></div>
  </div>
  <div class="content">

    <% if("cat_added".equals(msg)){   %><div class="alert alert-success">&#10003; Category added!</div><%}
       else if("item_added".equals(msg)){  %><div class="alert alert-success">&#10003; Item added!</div><%}
       else if("cat_deleted".equals(msg)){ %><div class="alert alert-success">&#10003; Category deleted.</div><%}
       else if("item_deleted".equals(msg)){%><div class="alert alert-success">&#10003; Item deleted.</div><%}
       else if("item_updated".equals(msg)){%><div class="alert alert-success">&#10003; Item updated!</div><%}
       else if("error_empty".equals(msg)){ %><div class="alert alert-error">&#10007; Fill all required fields.</div><%}
       else if("error".equals(msg)){       %><div class="alert alert-error">&#10007; An error occurred.</div><%}%>

    <!-- ADD CATEGORY BAR -->
    <form class="add-cat-bar" method="post" action="<%= request.getContextPath() %>/ManageMenu">
      <input type="hidden" name="action" value="addCategory">
      <input type="text"   name="categoryName" placeholder="Category Name" required>
      <input type="text"   name="firstItemName" placeholder="First Item Name">
      <input type="number" name="firstItemPrice" placeholder="Price" min="1" step="1">
      <button class="btn-gold" type="submit">Add Category</button>
    </form>

    <!-- CATEGORY CARDS GRID -->
    <div class="cat-grid">
    <%
    Connection conn=null;
    try{
      conn=DBConnection.getConnection();
      ResultSet cats=conn.prepareStatement("SELECT * FROM categories ORDER BY category_name").executeQuery();
      boolean anyCat=false;
      while(cats.next()){
        anyCat=true;
        int catId=cats.getInt("category_id");
        String catName=cats.getString("category_name");
    %>
      <div class="cat-card">
        <div class="cat-card-header">
          <h3><%= catName %></h3>
          <form method="post" action="<%= request.getContextPath() %>/ManageMenu" style="display:inline;"
            onsubmit="return confirm('Delete category \'<%= catName %>\' and ALL its items? This cannot be undone.')">
            <input type="hidden" name="action"     value="deleteCategory">
            <input type="hidden" name="categoryId" value="<%= catId %>">
            <button class="btn-del-cat" type="submit">&#128465; Delete Category</button>
          </form>
        </div>

        <%
        Connection ic=null;
        try{
          ic=DBConnection.getConnection();
          PreparedStatement ips=ic.prepareStatement("SELECT * FROM menu_items WHERE category_id=? ORDER BY item_name");
          ips.setInt(1,catId);
          ResultSet items=ips.executeQuery();
          while(items.next()){
            int iId=items.getInt("item_id");
            String iName=items.getString("item_name");
            int iPrice=(int)items.getDouble("price");
        %>
          <div class="item-row">
            <span class="item-name-txt"><%= iName %></span>
            <span class="item-price-txt">&#8377;<%= iPrice %></span>
            <button class="btn-edit" type="button"
              onclick="openEdit(<%= iId %>,'<%= iName.replace("'","\\'") %>',<%= iPrice %>)">Edit</button>
            <form method="post" action="<%= request.getContextPath() %>/ManageMenu" style="display:inline"
              onsubmit="return confirm('Delete <%= iName %>?')">
              <input type="hidden" name="action" value="deleteItem">
              <input type="hidden" name="itemId" value="<%= iId %>">
              <button class="btn-del" type="submit">Delete</button>
            </form>
          </div>
        <%  }
        }catch(Exception ie){out.print("<p style='color:red;font-size:12px;'>"+ie.getMessage()+"</p>");
        }finally{if(ic!=null)try{ic.close();}catch(Exception e2){}}%>

        <!-- ADD ITEM ROW -->
        <form class="add-item-row" method="post" action="<%= request.getContextPath() %>/ManageMenu">
          <input type="hidden" name="action"     value="addItem">
          <input type="hidden" name="categoryId" value="<%= catId %>">
          <input type="text"   name="itemName"  placeholder="Item name" required>
          <input type="number" name="price" placeholder="Price" min="1" class="price-in" required>
          <button class="btn-add-item" type="submit">Add</button>
        </form>

      </div>
    <%  }
      if(!anyCat){%>
        <div style="grid-column:1/-1;text-align:center;color:#bbb;padding:60px;font-size:14px;">
          No categories yet. Add one using the bar above.
        </div>
    <%  }
    }catch(Exception e){out.print("<p style='color:red;'>Error: "+e.getMessage()+"</p>");
    }finally{if(conn!=null)try{conn.close();}catch(Exception e2){}}%>
    </div>

  </div>
</div>

<!-- EDIT MODAL -->
<div class="modal-bg" id="editModal">
  <div class="modal">
    <h3>&#9998; Edit Item</h3>
    <form method="post" action="<%= request.getContextPath() %>/ManageMenu">
      <input type="hidden" name="action" value="updateItem">
      <input type="hidden" name="itemId" id="editItemId">
      <label style="font-size:12px;font-weight:600;color:#888;text-transform:uppercase;">Item Name</label>
      <input type="text"   name="itemName"  id="editItemName"  required>
      <label style="font-size:12px;font-weight:600;color:#888;text-transform:uppercase;">Price (&#8377;)</label>
      <input type="number" name="price"     id="editItemPrice" min="1" required>
      <div class="modal-btns">
        <button type="button" class="btn-cancel" onclick="closeEdit()">Cancel</button>
        <button type="submit" class="btn-gold">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
document.getElementById("nav-menu").classList.add("active");
function openEdit(id, name, price){
  document.getElementById("editItemId").value    = id;
  document.getElementById("editItemName").value  = name;
  document.getElementById("editItemPrice").value = price;
  document.getElementById("editModal").classList.add("open");
}
function closeEdit(){ document.getElementById("editModal").classList.remove("open"); }
document.getElementById("editModal").addEventListener("click", function(e){
  if(e.target===this) closeEdit();
});
</script>
</body></html>
