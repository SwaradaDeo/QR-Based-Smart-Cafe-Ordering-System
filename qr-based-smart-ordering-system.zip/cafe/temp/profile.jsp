<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%@ include file="/components/header.jsp" %>

<%
    if (session.getAttribute("userId") == null) {
        response.sendRedirect(request.getContextPath() + "/user/login.jsp");
        return;
    }
    int userId = (int) session.getAttribute("userId");
    String uName="", uEmail="", uPhone="", uAddress="", uRole="";
    int totalOrders = 0; double totalSpent = 0;

    Connection conn = null;
    try {
        conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("SELECT * FROM users WHERE user_id=?");
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            uName    = rs.getString("name");
            uEmail   = rs.getString("email");
            uPhone   = rs.getString("phone") != null ? rs.getString("phone") : "";
            uAddress = rs.getString("address") != null ? rs.getString("address") : "";
            uRole    = rs.getString("role");
        }
        PreparedStatement os = conn.prepareStatement(
            "SELECT COUNT(*), COALESCE(SUM(total_amount),0) FROM orders WHERE user_id=?");
        os.setInt(1, userId);
        ResultSet or2 = os.executeQuery();
        if (or2.next()) { totalOrders=(int)or2.getLong(1); totalSpent=or2.getDouble(2); }
    } catch (Exception e) { e.printStackTrace(); }
    finally { if(conn!=null) try{conn.close();}catch(Exception e2){} }

    String msg = request.getParameter("msg");
%>

<style>
.profile-wrap{max-width:900px;margin:50px auto;padding:0 20px 60px;}
.profile-header{display:flex;align-items:center;gap:25px;background:#fff;border-radius:18px;padding:30px;box-shadow:0 4px 20px rgba(0,0,0,.08);margin-bottom:25px;}
.avatar-circle{width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#f59e0b,#a16207);color:#fff;display:flex;align-items:center;justify-content:center;font-size:32px;font-weight:700;font-family:'Playfair Display',serif;flex-shrink:0;}
.profile-info h2{font-family:'Playfair Display',serif;color:#3b2f2f;font-size:24px;margin-bottom:4px;}
.profile-info p{color:#a16207;font-size:13px;font-weight:500;}
.stats-row{display:grid;grid-template-columns:repeat(2,1fr);gap:15px;margin-bottom:25px;}
.stat-box{background:#fff;border-radius:14px;padding:20px;text-align:center;box-shadow:0 4px 12px rgba(0,0,0,.06);}
.stat-box h3{font-size:26px;font-weight:700;color:#a16207;}
.stat-box p{font-size:12px;color:#999;margin-top:4px;}
.form-card{background:#fff;border-radius:18px;padding:30px;box-shadow:0 4px 20px rgba(0,0,0,.08);}
.form-card h3{font-family:'Playfair Display',serif;color:#a16207;font-size:18px;margin-bottom:22px;border-bottom:1px solid #f3e8e2;padding-bottom:12px;}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-bottom:18px;}
.form-group{display:flex;flex-direction:column;gap:6px;}
.form-group label{font-size:12px;font-weight:600;color:#888;text-transform:uppercase;letter-spacing:.5px;}
.form-group input,.form-group textarea{padding:11px 14px;border:1.5px solid #e8ddd5;border-radius:10px;font-family:'Poppins',sans-serif;font-size:14px;color:#3b2f2f;background:#fffaf6;transition:border .2s;}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:#a16207;background:#fff;}
.form-group textarea{height:80px;resize:vertical;}
.save-btn{background:linear-gradient(135deg,#f59e0b,#a16207);color:#fff;border:none;padding:13px 35px;border-radius:10px;font-size:14px;font-weight:600;cursor:pointer;font-family:'Poppins',sans-serif;box-shadow:0 6px 18px rgba(161,98,7,.3);transition:.2s;}
.save-btn:hover{transform:translateY(-2px);box-shadow:0 10px 24px rgba(161,98,7,.4);}
.divider{border:none;border-top:2px dashed #f3e8e2;margin:25px 0;}
.msg-success{background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;padding:12px 16px;border-radius:10px;margin-bottom:20px;font-size:13px;}
.msg-error  {background:#fef2f2;color:#dc2626;border:1px solid #fecaca;padding:12px 16px;border-radius:10px;margin-bottom:20px;font-size:13px;}
@media(max-width:600px){.form-row{grid-template-columns:1fr;}.stats-row{grid-template-columns:1fr 1fr;}}
</style>

<div class="profile-wrap">

  <div class="profile-header">
    <div class="avatar-circle"><%= uName.length()>0 ? String.valueOf(uName.charAt(0)).toUpperCase() : "U" %></div>
    <div class="profile-info">
      <h2><%= uName %></h2>
      <p>&#9749; <%= uEmail %> &nbsp;|&nbsp; <%= uRole.substring(0,1).toUpperCase()+uRole.substring(1) %></p>
    </div>
  </div>

  <div class="stats-row">
    <div class="stat-box">
      <h3><%= totalOrders %></h3>
      <p>Total Orders</p>
    </div>
    <div class="stat-box">
      <h3>&#8377;<%= String.format("%.0f", totalSpent) %></h3>
      <p>Total Spent</p>
    </div>
  </div>

  <div class="form-card">
    <% if ("success".equals(msg)) { %>
      <div class="msg-success">&#10003; Profile updated successfully!</div>
    <% } else if ("wrongpass".equals(msg)) { %>
      <div class="msg-error">&#10007; Current password is incorrect.</div>
    <% } else if ("error".equals(msg)) { %>
      <div class="msg-error">&#10007; Something went wrong. Please try again.</div>
    <% } %>

    <h3>&#128100; Edit Profile</h3>

    <form action="<%= request.getContextPath() %>/UpdateProfile" method="post">
      <div class="form-row">
        <div class="form-group">
          <label>Full Name</label>
          <input type="text" name="name" value="<%= uName %>" required>
        </div>
        <div class="form-group">
          <label>Email</label>
          <input type="email" value="<%= uEmail %>" disabled style="background:#f5f5f5;color:#aaa;">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label>Phone Number</label>
          <input type="tel" name="phone" value="<%= uPhone %>" placeholder="+91 9876543210">
        </div>
        <div class="form-group">
          <label>Address</label>
          <input type="text" name="address" value="<%= uAddress %>" placeholder="Your address">
        </div>
      </div>

      <hr class="divider">
      <h3>&#128274; Change Password <small style="font-size:12px;color:#bbb;font-weight:400;">(leave blank to keep current)</small></h3>

      <div class="form-row">
        <div class="form-group">
          <label>Current Password *</label>
          <input type="password" name="currentPassword" placeholder="Required to save changes" required>
        </div>
        <div class="form-group">
          <label>New Password</label>
          <input type="password" name="newPassword" placeholder="Leave blank to keep current">
        </div>
      </div>

      <div style="text-align:right;margin-top:10px;">
        <button type="submit" class="save-btn">Save Changes</button>
      </div>
    </form>
  </div>

</div>

<%@ include file="/components/footer.jsp" %>
