let cart = JSON.parse(localStorage.getItem("cart")) || {};
document.addEventListener("DOMContentLoaded", function () {

let cart = {};

// PLUS BUTTON
document.querySelectorAll(".plus").forEach(btn => {

btn.onclick = function () {

let row = this.closest(".menu-row");

let name = row.dataset.name;
let price = parseInt(row.dataset.price);

let qtyElement = row.querySelector(".qty");

let qty = parseInt(qtyElement.innerText) + 1;

qtyElement.innerText = qty;

cart[name] = {
name: name,
price: price,
quantity: qty
};

localStorage.setItem("cart", JSON.stringify(cart));

};

});


// MINUS BUTTON
document.querySelectorAll(".minus").forEach(btn => {

btn.onclick = function () {

let row = this.closest(".menu-row");

let name = row.dataset.name;

let qtyElement = row.querySelector(".qty");

let qty = parseInt(qtyElement.innerText);

if (qty > 0) {

qty--;

qtyElement.innerText = qty;

if (qty === 0) {

delete cart[name];

} else {

cart[name].quantity = qty;

}

localStorage.setItem("cart", JSON.stringify(cart));

}

};

});


// ADD CART BUTTON
document.getElementById("cartBtn").onclick = function () {

cart = {};   // reset cart

document.querySelectorAll(".menu-row").forEach(row => {

let qty = parseInt(row.querySelector(".qty").innerText);

if (qty > 0) {

let name = row.dataset.name;
let price = parseInt(row.dataset.price);

cart[name] = {
name: name,
price: price,
quantity: qty
};

}

});

if (Object.keys(cart).length === 0) {

alert("Please select items first");
return;

}

localStorage.setItem("cart", JSON.stringify(cart));

this.innerText = "View Cart";

this.onclick = function () {

window.location.href = "cart.jsp";

};

};

});   // ← THIS WAS MISSING
document.querySelectorAll(".menu-row").forEach(row => {

let name = row.dataset.name;

if(cart[name]){

row.querySelector(".qty").innerText = cart[name].quantity;

}

});