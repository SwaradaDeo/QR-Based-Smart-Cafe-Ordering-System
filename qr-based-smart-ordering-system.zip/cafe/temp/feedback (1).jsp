<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="/components/header.jsp" %>
<style>
body{background:#f5ede3;}
.fb-page{max-width:900px;margin:50px auto;padding:0 20px 70px;}
.fb-page h1{text-align:center;font-family:"Playfair Display",serif;
  font-size:38px;color:#a16207;margin-bottom:8px;}
.fb-page .sub{text-align:center;color:#aaa;font-size:14px;margin-bottom:40px;}

.alert-success{background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;
  padding:13px 18px;border-radius:10px;margin-bottom:25px;font-size:14px;text-align:center;}

.fb-card{background:#fff;border-radius:20px;padding:40px;
  box-shadow:0 6px 24px rgba(0,0,0,.08);display:grid;
  grid-template-columns:1fr 1fr;gap:40px;margin-bottom:30px;}

/* LEFT — Questions */
.fb-left h4{font-size:14px;font-weight:600;color:#3b2f2f;margin-bottom:8px;}
.fb-left textarea{
  width:100%;padding:12px 14px;border:1.5px solid #e8ddd5;border-radius:12px;
  font-family:"Poppins",sans-serif;font-size:13px;color:#3b2f2f;
  background:#fffaf6;resize:vertical;height:100px;margin-bottom:22px;
  transition:border .2s;
}
.fb-left textarea:focus{outline:none;border-color:#a16207;background:#fff;}

/* RIGHT — Star ratings */
.fb-right .rating-group{margin-bottom:24px;}
.fb-right .rating-group label{
  display:block;font-size:14px;font-weight:600;color:#3b2f2f;margin-bottom:10px;
}
.stars{display:flex;gap:8px;}
.stars span{font-size:28px;color:#e0d0c0;cursor:pointer;transition:color .15s;line-height:1;}
.stars span.lit{color:#a16207;}

/* SUBMIT */
.fb-footer{text-align:center;}
.submit-btn{
  background:#a16207;color:#fff;border:none;padding:15px 60px;
  border-radius:30px;font-size:16px;font-weight:600;cursor:pointer;
  font-family:"Poppins",sans-serif;box-shadow:0 8px 20px rgba(161,98,7,.3);
  transition:.2s;
}
.submit-btn:hover{background:#78350f;transform:translateY(-2px);}
.login-notice{text-align:center;background:#fdf6f0;color:#a16207;
  padding:14px;border-radius:10px;margin-bottom:20px;font-size:14px;}

@media(max-width:700px){.fb-card{grid-template-columns:1fr;gap:20px;padding:25px;}}
</style>

<div class="fb-page">
  <h1>Guest Feedback</h1>
  <p class="sub">Your Thoughts — How was your experience?</p>

  <% if("true".equals(request.getParameter("sent"))){ %>
    <div class="alert-success">&#10003; Thank you! Your feedback has been submitted.</div>
  <% } %>

  <% if(session.getAttribute("userId")==null){ %>
    <div class="login-notice">
      &#128274; Please <a href="<%= request.getContextPath() %>/user/login.jsp" style="color:#a16207;font-weight:700;">login</a> to submit feedback.
    </div>
  <% } %>

  <form action="<%= request.getContextPath() %>/SubmitFeedback" method="post">
    <input type="hidden" name="foodRating"      id="foodRatingVal"      value="0">
    <input type="hidden" name="serviceRating"   id="serviceRatingVal"   value="0">
    <input type="hidden" name="ambienceRating"  id="ambienceRatingVal"  value="0">
    <input type="hidden" name="cleanRating"     id="cleanRatingVal"     value="0">
    <input type="hidden" name="rating"          id="overallRating"      value="5">

    <div class="fb-card">

      <!-- LEFT: Text questions -->
      <div class="fb-left">
        <h4>Did we meet your expectations?</h4>
        <textarea name="q1" placeholder="Your answer..."></textarea>

        <h4>How was your overall experience?</h4>
        <textarea name="comments" placeholder="Your answer..." required></textarea>

        <h4>Would you recommend us to friends or family?</h4>
        <textarea name="q3" placeholder="Your answer..."></textarea>
      </div>

      <!-- RIGHT: Star ratings -->
      <div class="fb-right">

        <div class="rating-group">
          <label>Food Quality</label>
          <div class="stars" data-field="foodRatingVal">
            <span data-v="1">&#9733;</span><span data-v="2">&#9733;</span>
            <span data-v="3">&#9733;</span><span data-v="4">&#9733;</span>
            <span data-v="5">&#9733;</span>
          </div>
        </div>

        <div class="rating-group">
          <label>Service</label>
          <div class="stars" data-field="serviceRatingVal">
            <span data-v="1">&#9733;</span><span data-v="2">&#9733;</span>
            <span data-v="3">&#9733;</span><span data-v="4">&#9733;</span>
            <span data-v="5">&#9733;</span>
          </div>
        </div>

        <div class="rating-group">
          <label>Ambience</label>
          <div class="stars" data-field="ambienceRatingVal">
            <span data-v="1">&#9733;</span><span data-v="2">&#9733;</span>
            <span data-v="3">&#9733;</span><span data-v="4">&#9733;</span>
            <span data-v="5">&#9733;</span>
          </div>
        </div>

        <div class="rating-group">
          <label>Cleanliness</label>
          <div class="stars" data-field="cleanRatingVal">
            <span data-v="1">&#9733;</span><span data-v="2">&#9733;</span>
            <span data-v="3">&#9733;</span><span data-v="4">&#9733;</span>
            <span data-v="5">&#9733;</span>
          </div>
        </div>

      </div>
    </div>

    <div class="fb-footer">
      <button type="submit" class="submit-btn"
        <%= session.getAttribute("userId")==null?"disabled style='opacity:.5;cursor:not-allowed;'":"" %>>
        Submit Feedback
      </button>
    </div>
  </form>
</div>

<script>
document.querySelectorAll(".stars").forEach(function(group){
  var field  = group.getAttribute("data-field");
  var spans  = group.querySelectorAll("span");

  spans.forEach(function(star){
    star.addEventListener("mouseover", function(){
      var v = parseInt(this.getAttribute("data-v"));
      spans.forEach(function(s){ s.classList.toggle("lit", parseInt(s.getAttribute("data-v"))<=v); });
    });
    star.addEventListener("mouseleave", function(){
      var cur = parseInt(document.getElementById(field).value) || 0;
      spans.forEach(function(s){ s.classList.toggle("lit", parseInt(s.getAttribute("data-v"))<=cur); });
    });
    star.addEventListener("click", function(){
      var v = parseInt(this.getAttribute("data-v"));
      document.getElementById(field).value = v;
      spans.forEach(function(s){ s.classList.toggle("lit", parseInt(s.getAttribute("data-v"))<=v); });
      // overall = avg of all 4
      var vals = ["foodRatingVal","serviceRatingVal","ambienceRatingVal","cleanRatingVal"]
        .map(function(id){ return parseInt(document.getElementById(id).value)||0; });
      var avg = Math.round(vals.reduce(function(a,b){return a+b;},0)/vals.length);
      document.getElementById("overallRating").value = avg||5;
    });
  });
});
</script>

<%@ include file="/components/footer.jsp" %>
