<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%
    if(session.getAttribute("adminUser")==null){
        response.sendRedirect(request.getContextPath()+"/admin/admin-login.jsp"); return;
    }
    String msg = request.getParameter("msg");
%>
<!DOCTYPE html>
<html>
<head>
<title>Manage Menu - Veloura Admin</title>
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box;}
body{font-family:"Poppins",sans-serif;background:#f6efe7;display:flex;}

/* SIDEBAR */
.sidebar{width:230px;height:100vh;background:#fff;position:fixed;top:0;left:0;
  box-shadow:3px 0 15px rgba(0,0,0,.07);display:flex;flex-direction:column;z-index:100;}
.sidebar-logo{padding:22px 20px;font-family:"Playfair Display",serif;font-size:19px;
  color:#a16207;border-bottom:1px solid #f3e8e2;background:#fffaf6;}
.sidebar-logo span{font-size:11px;color:#aaa;display:block;margin-top:3px;}
.sidebar ul{list-style:none;padding:12px 0;flex:1;}
.sidebar ul li a{display:flex;align-items:center;gap:10px;padding:13px 22px;
  text-decoration:none;color:#555;font-size:14px;font-weight:500;
  transition:.2s;border-left:3px solid transparent;}
.sidebar ul li a:hover,.sidebar ul li a.active{background:#fdf6f0;color:#a16207;border-left:3px solid #a16207;}
.sidebar-footer{padding:18px;border-top:1px solid #f3e8e2;}
.logout-btn{display:block;text-align:center;padding:10px;background:#fee2e2;
  color:#dc2626;text-decoration:none;border-radius:8px;font-size:13px;font-weight:500;}
.logout-btn:hover{background:#dc2626;color:#fff;}

/* MAIN */
.main{margin-left:230px;flex:1;min-height:100vh;}
.topbar{background:#fff;padding:18px 35px;display:flex;justify-content:space-between;
  align-items:center;box-shadow:0 2px 10px rgba(0,0,0,.05);position:sticky;top:0;z-index:50;}
.topbar h1{font-size:22px;color:#3b2f2f;font-family:"Playfair Display",serif;}
.admin-badge{background:#fdf6f0;color:#a16207;padding:8px 16px;border-radius:20px;
  font-size:13px;font-weight:600;border:1px solid #f3e8e2;}
.content{padding:25px 35px;}

/* ALERTS */
.alert{padding:12px 18px;border-radius:10px;font-size:13px;font-weight:500;margin-bottom:18px;}
.alert-success{background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;}
.alert-error{background:#fef2f2;color:#dc2626;border:1px solid #fecaca;}

/* LAYOUT */
.two-col{display:grid;grid-template-columns:360px 1fr;gap:22px;align-items:start;}

/* CARDS */
.card{background:#fff;border-radius:14px;padding:22px;
  box-shadow:0 4px 15px rgba(0,0,0,.06);margin-bottom:18px;}
.card h3{font-size:15px;font-weight:700;color:#a16207;margin-bottom:16px;
  font-family:"Playfair Display",serif;border-bottom:1px solid #f3e8e2;padding-bottom:10px;}

/* FORMS */
.form-group{margin-bottom:13px;}
.form-group label{display:block;font-size:12px;font-weight:600;color:#666;margin-bottom:5px;text-transform:uppercase;letter-spacing:.3px;}
.form-group input,
.form-group select,
.form-group textarea{
  width:100%;padding:10px 12px;border-radius:8px;
  border:1px solid #e5d5c8;background:#fffaf6;
  font-family:"Poppins",sans-serif;font-size:13px;color:#3b2f2f;
  transition:border .2s;}
.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus{outline:none;border-color:#a16207;background:#fff;}
.form-group textarea{height:75px;resize:vertical;}
.submit-btn{background:linear-gradient(135deg,#f59e0b,#a16207);color:#fff;
  border:none;padding:11px;border-radius:8px;cursor:pointer;
  font-size:13px;font-weight:600;width:100%;margin-top:4px;transition:.2s;
  font-family:"Poppins",sans-serif;}
.submit-btn:hover{background:linear-gradient(135deg,#a16207,#78350f);transform:translateY(-1px);}

/* MENU LIST */
.menu-panel{background:#fff;border-radius:14px;padding:22px;box-shadow:0 4px 15px rgba(0,0,0,.06);}
.menu-panel h3{font-size:15px;font-weight:700;color:#a16207;margin-bottom:16px;
  font-family:"Playfair Display",serif;border-bottom:1px solid #f3e8e2;padding-bottom:10px;
  display:flex;justify-content:space-between;align-items:center;}
.cat-block{border:1px solid #f3e8e2;border-radius:10px;margin-bottom:12px;overflow:hidden;}
.cat-header{padding:13px 16px;background:#fdf6f0;display:flex;
  justify-content:space-between;align-items:center;}
.cat-name{font-weight:600;color:#a16207;font-size:14px;display:flex;align-items:center;gap:8px;}
.cat-count{background:#f3e8e2;color:#a16207;padding:2px 8px;border-radius:10px;font-size:11px;}
.cat-actions{display:flex;gap:6px;align-items:center;}
.btn-toggle{background:#fff;border:1px solid #e5d5c8;color:#a16207;
  padding:5px 12px;border-radius:6px;cursor:pointer;font-size:12px;font-family:"Poppins",sans-serif;}
.btn-toggle:hover{background:#fdf6f0;}
.btn-del-cat{background:#fee2e2;color:#dc2626;border:none;
  padding:5px 12px;border-radius:6px;cursor:pointer;font-size:12px;font-family:"Poppins",sans-serif;}
.btn-del-cat:hover{background:#dc2626;color:#fff;}

.cat-items{display:none;padding:10px 16px 14px;}
.item-row{display:flex;justify-content:space-between;align-items:center;
  padding:9px 0;border-bottom:1px solid #f9f0e8;font-size:13px;}
.item-row:last-child{border-bottom:none;}
.item-info{flex:1;}
.item-name{font-weight:600;color:#3b2f2f;font-size:13px;}
.item-desc{font-size:11px;color:#bbb;margin-top:2px;}
.item-price{font-weight:700;color:#a16207;font-size:14px;margin:0 14px;}
.btn-del-item{background:#fee2e2;color:#dc2626;border:none;
  padding:4px 10px;border-radius:6px;cursor:pointer;font-size:11px;font-family:"Poppins",sans-serif;}
.btn-del-item:hover{background:#dc2626;color:#fff;}
.no-items{color:#ccc;font-size:13px;padding:10px 0;text-align:center;}
.empty-menu{text-align:center;color:#bbb;padding:40px;font-size:14px;}

@media(max-width:1000px){.two-col{grid-template-columns:1fr;}}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sidebar-logo">&#9749; Veloura Admin<span>Management Panel</span></div>
  <ul>
    <li><a href="admin-dashboard.jsp">&#128202; Dashboard</a></li>
    <li><a href="admin-orders.jsp">&#128230; Orders</a></li>
    <li><a href="admin-manage-menu.jsp" class="active">&#127869; Manage Menu</a></li>
    <li><a href="feedback-admin.jsp">&#128172; Feedback</a></li>
    <li><a href="contact-admin.jsp">&#128233; Contact Messages</a></li>
  </ul>
  <div class="sidebar-footer">
    <a href="<%= request.getContextPath() %>/logout" class="logout-btn">&#128682; Logout</a>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <h1>Manage Menu</h1>
    <div class="admin-badge">&#128100; <%= session.getAttribute("adminUser") %></div>
  </div>

  <div class="content">

    <!-- ALERT MESSAGES -->
    <% if("cat_added".equals(msg)){   %><div class="alert alert-success">&#10003; Category added successfully!</div><% }
       else if("item_added".equals(msg)){  %><div class="alert alert-success">&#10003; Menu item added successfully!</div><% }
       else if("cat_deleted".equals(msg)){ %><div class="alert alert-success">&#10003; Category deleted.</div><% }
       else if("item_deleted".equals(msg)){%><div class="alert alert-success">&#10003; Item deleted.</div><% }
       else if("error_empty".equals(msg)){ %><div class="alert alert-error">&#10007; Please fill in all required fields.</div><% }
       else if("error".equals(msg)){       %><div class="alert alert-error">&#10007; An error occurred. Please try again.</div><% } %>

    <div class="two-col">

      <!-- LEFT FORMS -->
      <div>

        <!-- ADD CATEGORY -->
        <div class="card">
          <h3>&#10133; Add New Category</h3>
          <form method="post" action="<%= request.getContextPath() %>/ManageMenu">
            <input type="hidden" name="action" value="addCategory">
            <div class="form-group">
              <label>Category Name *</label>
              <input type="text" name="categoryName" placeholder="e.g. Pizza, Burgers, Coffee..." required>
            </div>
            <div class="form-group">
              <label>Description</label>
              <textarea name="description" placeholder="Short description (optional)"></textarea>
            </div>
            <button class="submit-btn" type="submit">Add Category</button>
          </form>
        </div>

        <!-- ADD MENU ITEM -->
        <div class="card">
          <h3>&#127869; Add Menu Item</h3>
          <form method="post" action="<%= request.getContextPath() %>/ManageMenu">
            <input type="hidden" name="action" value="addItem">
            <div class="form-group">
              <label>Select Category *</label>
              <select name="categoryId" required>
                <option value="">-- Select Category --</option>
                <%
                Connection catConn = null;
                try {
                  catConn = DBConnection.getConnection();
                  ResultSet catRs = catConn.prepareStatement(
                    "SELECT category_id, category_name FROM categories ORDER BY category_name"
                  ).executeQuery();
                  while(catRs.next()){
                %>
                  <option value="<%= catRs.getInt("category_id") %>">
                    <%= catRs.getString("category_name") %>
                  </option>
                <%  }
                } catch(Exception e){ out.print("<option>Error loading</option>"); }
                  finally { if(catConn!=null) try{catConn.close();}catch(Exception e2){} }
                %>
              </select>
            </div>
            <div class="form-group">
              <label>Item Name *</label>
              <input type="text" name="itemName" placeholder="e.g. Margherita Pizza" required>
            </div>
            <div class="form-group">
              <label>Price (&#8377;) *</label>
              <input type="number" name="price" placeholder="249" min="1" step="1" required>
            </div>
            <div class="form-group">
              <label>Description</label>
              <textarea name="description" placeholder="Item description (optional)"></textarea>
            </div>
            <button class="submit-btn" type="submit">Add Menu Item</button>
          </form>
        </div>

      </div>

      <!-- RIGHT: CURRENT MENU LIST -->
      <div class="menu-panel">
        <h3>
          &#128203; Current Menu
          <span style="font-size:12px;color:#aaa;font-weight:400;">
            <%
            try(Connection cc=DBConnection.getConnection()){
              ResultSet cr=cc.prepareStatement("SELECT COUNT(*) FROM categories").executeQuery();
              ResultSet ir=cc.prepareStatement("SELECT COUNT(*) FROM menu_items").executeQuery();
              int cats=0,items=0;
              if(cr.next()) cats=cr.getInt(1);
              if(ir.next()) items=ir.getInt(1);
              out.print(cats+" categories, "+items+" items");
            }catch(Exception e){}
            %>
          </span>
        </h3>

        <%
        Connection menuConn = null;
        try {
          menuConn = DBConnection.getConnection();
          ResultSet cats = menuConn.prepareStatement(
            "SELECT * FROM categories ORDER BY category_name"
          ).executeQuery();

          boolean anyCat = false;
          while(cats.next()){
            anyCat = true;
            int catId     = cats.getInt("category_id");
            String catName= cats.getString("category_name");

            // Count items in this category
            PreparedStatement cntPs = menuConn.prepareStatement(
              "SELECT COUNT(*) FROM menu_items WHERE category_id=?");
            cntPs.setInt(1, catId);
            ResultSet cntRs = cntPs.executeQuery();
            int itemCount = cntRs.next() ? cntRs.getInt(1) : 0;
        %>

        <div class="cat-block">
          <div class="cat-header">
            <div class="cat-name">
              &#128193; <%= catName %>
              <span class="cat-count"><%= itemCount %> items</span>
            </div>
            <div class="cat-actions">
              <button class="btn-toggle" type="button" onclick="toggleCat(<%= catId %>)">
                &#9660; Show Items
              </button>
              <form method="post" action="<%= request.getContextPath() %>/ManageMenu"
                style="display:inline;"
                onsubmit="return confirm('Delete category '<%= catName %>' and ALL its items?')">
                <input type="hidden" name="action"     value="deleteCategory">
                <input type="hidden" name="categoryId" value="<%= catId %>">
                <button class="btn-del-cat" type="submit">&#128465; Delete</button>
              </form>
            </div>
          </div>

          <div class="cat-items" id="cat-<%= catId %>">
          <%
            Connection itemConn = null;
            try {
              itemConn = DBConnection.getConnection();
              PreparedStatement itemPs = itemConn.prepareStatement(
                "SELECT * FROM menu_items WHERE category_id=? ORDER BY item_name");
              itemPs.setInt(1, catId);
              ResultSet items = itemPs.executeQuery();
              boolean anyItem = false;
              while(items.next()){
                anyItem = true;
          %>
            <div class="item-row">
              <div class="item-info">
                <div class="item-name"><%= items.getString("item_name") %></div>
                <% String iDesc = items.getString("description");
                   if(iDesc != null && !iDesc.trim().isEmpty()){ %>
                  <div class="item-desc"><%= iDesc %></div>
                <% } %>
              </div>
              <span class="item-price">&#8377;<%= String.format("%.0f", items.getDouble("price")) %></span>
              <form method="post" action="<%= request.getContextPath() %>/ManageMenu"
                onsubmit="return confirm('Delete '<%= items.getString("item_name") %>'?')">
                <input type="hidden" name="action" value="deleteItem">
                <input type="hidden" name="itemId" value="<%= items.getInt("item_id") %>">
                <button class="btn-del-item" type="submit">&#10005; Delete</button>
              </form>
            </div>
          <%
              }
              if(!anyItem){
          %>
            <div class="no-items">No items yet. Add items using the form.</div>
          <%
              }
            } catch(Exception e2){
              out.print("<div class='no-items' style='color:red;'>Error: "+e2.getMessage()+"</div>");
            } finally {
              if(itemConn != null) try{ itemConn.close(); }catch(Exception e3){}
            }
          %>
          </div>
        </div>

        <%
          }
          if(!anyCat){
        %>
          <div class="empty-menu">
            &#127869; No categories yet.<br>
            <small>Add a category first using the form on the left.</small>
          </div>
        <%
          }
        } catch(Exception e){
          out.print("<div class='empty-menu' style='color:red;'>DB Error: "+e.getMessage()+"</div>");
        } finally {
          if(menuConn != null) try{ menuConn.close(); }catch(Exception e4){}
        }
        %>

      </div><!-- end menu-panel -->

    </div><!-- end two-col -->
  </div><!-- end content -->
</div><!-- end main -->

<script>
function toggleCat(id) {
    var el  = document.getElementById("cat-" + id);
    var btn = el.previousElementSibling.querySelector(".btn-toggle");
    if (el.style.display === "block") {
        el.style.display = "none";
        btn.innerHTML    = "&#9660; Show Items";
    } else {
        el.style.display = "block";
        btn.innerHTML    = "&#9650; Hide Items";
    }
}
</script>

</body>
</html>
