<%@ page contentType="text/html;charset=UTF-8" %>
<%@ include file="/components/header.jsp" %>
<link rel="stylesheet" href="<%= request.getContextPath() %>/css/cart.css">

<% if(session.getAttribute("userId") == null){ %>
<div style="text-align:center;padding:80px 20px;">
  <h2 style="color:#a16207;font-family:'Playfair Display',serif;">Please Login First</h2>
  <p style="color:#777;margin:15px 0;">You need to be logged in to place an order.</p>
  <a href="<%= request.getContextPath() %>/user/login.jsp" class="btn">Login Now</a>
</div>
<% } else { %>

<div class="cart-container">
  <h2 class="cart-title">Order Summary</h2>
  <div class="cart-layout">

    <div class="cart-card">
      <table class="cart-table">
        <thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Total</th></tr></thead>
        <tbody id="cartItems"><tr><td colspan="4" style="text-align:center;color:#aaa;padding:20px;">Loading...</td></tr></tbody>
      </table>
      <div style="text-align:right;padding:15px 10px 5px;font-size:16px;font-weight:700;color:#a16207;">
        Grand Total: &#8377;<span id="grandTotal">0</span>
      </div>
    </div>

    <div class="summary-card">
      <h3>Payment Method</h3>
      <div class="payment-options">
        <label class="payment-item"><input type="radio" name="payment" value="Cash" checked> &nbsp;&#128181; Cash</label>
        <label class="payment-item"><input type="radio" name="payment" value="UPI"> &nbsp;&#128241; UPI</label>
        <label class="payment-item"><input type="radio" name="payment" value="Card"> &nbsp;&#128179; Card</label>
      </div>
      <div class="checkout-buttons">
        <button onclick="window.location.href='menu.jsp'" class="modify-btn">&#9998; Modify Order</button>
        <button onclick="placeOrder()" class="order-btn" id="placeBtn">&#10003; Place Order</button>
      </div>

      <div id="statusBox" style="display:none;margin-top:20px;padding:20px;border-radius:14px;background:#fdf6f0;border:2px solid #f3e8e2;text-align:center;">
        <div id="statusIcon"  style="font-size:40px;margin-bottom:8px;">&#9203;</div>
        <div id="statusTitle" style="font-weight:700;color:#a16207;font-size:16px;margin-bottom:6px;">Order Placed!</div>
        <div id="statusMsg"   style="font-size:13px;color:#777;line-height:1.6;margin-bottom:10px;"></div>
        <div style="background:#f3e8e2;border-radius:20px;height:6px;overflow:hidden;margin:12px 0;">
          <div id="progressBar" style="height:100%;width:0%;background:linear-gradient(90deg,#f59e0b,#a16207);border-radius:20px;transition:width 0.8s;"></div>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:10px;color:#bbb;margin-bottom:12px;">
          <span>Placed</span><span>Preparing</span><span>Ready</span><span>Done</span>
        </div>
        <div id="orderInfo" style="font-size:11px;color:#bbb;border-top:1px solid #f3e8e2;padding-top:10px;"></div>
      </div>
    </div>

  </div>
</div>
<% } %>

<script>var CTX = "<%= request.getContextPath() %>";</script>
<script src="<%= request.getContextPath() %>/js/cart.js"></script>
<%@ include file="/components/footer.jsp" %>
