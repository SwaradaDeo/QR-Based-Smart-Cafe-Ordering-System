<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Admin Login — Veloura Café</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,700;1,500&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }

  :root {
    --gold:      #a16207;
    --gold-lt:   #f59e0b;
    --gold-dk:   #78350f;
    --cream:     #fdf8f2;
    --brown:     #3b2f2f;
    --muted:     #9c8778;
  }

  body {
    font-family: "Poppins", sans-serif;
    background: var(--cream);
    min-height: 100vh;
    display: flex;
    overflow: hidden;
  }

  /* ── LEFT PANEL ── */
  .left-panel {
    width: 52%;
    background: linear-gradient(160deg, #3b2f2f 0%, #1c1410 60%, #0e0a07 100%);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: 60px;
    position: relative;
    overflow: hidden;
  }

  /* Decorative circles */
  .left-panel::before {
    content: "";
    position: absolute;
    width: 400px; height: 400px;
    border-radius: 50%;
    border: 1px solid rgba(161,98,7,0.15);
    top: -100px; left: -100px;
  }
  .left-panel::after {
    content: "";
    position: absolute;
    width: 300px; height: 300px;
    border-radius: 50%;
    border: 1px solid rgba(161,98,7,0.1);
    bottom: -80px; right: -80px;
  }

  .brand {
    text-align: center;
    position: relative;
    z-index: 2;
  }

  .coffee-icon {
    font-size: 56px;
    display: block;
    margin-bottom: 20px;
    animation: float 3s ease-in-out infinite;
  }

  @keyframes float {
    0%, 100% { transform: translateY(0); }
    50%       { transform: translateY(-8px); }
  }

  .brand-name {
    font-family: "Playfair Display", serif;
    font-size: 42px;
    color: #fff;
    line-height: 1.1;
    margin-bottom: 8px;
  }

  .brand-name span {
    color: var(--gold-lt);
    font-style: italic;
  }

  .brand-tagline {
    font-size: 13px;
    color: rgba(255,255,255,0.4);
    letter-spacing: 3px;
    text-transform: uppercase;
    margin-bottom: 50px;
  }

  /* Decorative divider */
  .divider {
    display: flex;
    align-items: center;
    gap: 14px;
    margin-bottom: 40px;
  }
  .divider-line {
    width: 60px; height: 1px;
    background: linear-gradient(90deg, transparent, rgba(161,98,7,0.5));
  }
  .divider-line.right {
    background: linear-gradient(270deg, transparent, rgba(161,98,7,0.5));
  }
  .divider-dot {
    width: 6px; height: 6px;
    border-radius: 50%;
    background: var(--gold);
  }

  .features {
    list-style: none;
    text-align: left;
    width: 100%;
    max-width: 280px;
  }
  .features li {
    color: rgba(255,255,255,0.55);
    font-size: 13px;
    padding: 8px 0;
    border-bottom: 1px solid rgba(255,255,255,0.06);
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .features li:last-child { border-bottom: none; }
  .features li span {
    color: var(--gold-lt);
    font-size: 16px;
  }

  /* ── RIGHT PANEL ── */
  .right-panel {
    width: 48%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 60px 50px;
    background: var(--cream);
    position: relative;
  }

  /* Subtle background pattern */
  .right-panel::before {
    content: "";
    position: absolute;
    inset: 0;
    background-image: radial-gradient(circle, rgba(161,98,7,0.04) 1px, transparent 1px);
    background-size: 28px 28px;
  }

  .login-box {
    width: 100%;
    max-width: 380px;
    position: relative;
    z-index: 2;
    animation: slideUp 0.6s ease both;
  }

  @keyframes slideUp {
    from { opacity:0; transform:translateY(24px); }
    to   { opacity:1; transform:translateY(0); }
  }

  .login-header {
    margin-bottom: 36px;
  }

  .login-header h2 {
    font-family: "Playfair Display", serif;
    font-size: 32px;
    color: var(--brown);
    margin-bottom: 6px;
  }

  .login-header p {
    font-size: 13px;
    color: var(--muted);
  }

  /* Error / success */
  .msg-box {
    padding: 12px 16px;
    border-radius: 10px;
    font-size: 13px;
    margin-bottom: 22px;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .msg-error   { background: #fef2f2; color: #dc2626; border: 1px solid #fecaca; }
  .msg-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }

  /* INPUT GROUPS */
  .input-group {
    margin-bottom: 18px;
    position: relative;
  }

  .input-group label {
    display: block;
    font-size: 11px;
    font-weight: 600;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 8px;
  }

  .input-wrap {
    position: relative;
    display: flex;
    align-items: center;
  }

  .input-icon {
    position: absolute;
    left: 14px;
    font-size: 16px;
    color: var(--muted);
    pointer-events: none;
    transition: color 0.2s;
  }

  .input-group input {
    width: 100%;
    padding: 13px 14px 13px 42px;
    border: 1.5px solid #e8ddd5;
    border-radius: 12px;
    background: #fff;
    font-family: "Poppins", sans-serif;
    font-size: 14px;
    color: var(--brown);
    transition: border 0.25s, box-shadow 0.25s;
    outline: none;
  }

  .input-group input:focus {
    border-color: var(--gold);
    box-shadow: 0 0 0 3px rgba(161,98,7,0.1);
  }

  .input-group input:focus + .input-icon,
  .input-wrap:focus-within .input-icon {
    color: var(--gold);
  }

  /* Toggle password */
  .toggle-pw {
    position: absolute;
    right: 14px;
    background: none;
    border: none;
    cursor: pointer;
    font-size: 16px;
    color: var(--muted);
    padding: 0;
    transition: color 0.2s;
  }
  .toggle-pw:hover { color: var(--gold); }

  /* LOGIN BUTTON */
  .login-btn {
    width: 100%;
    padding: 14px;
    background: linear-gradient(135deg, var(--gold-lt), var(--gold));
    color: #fff;
    border: none;
    border-radius: 12px;
    font-family: "Poppins", sans-serif;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    margin-top: 8px;
    position: relative;
    overflow: hidden;
    transition: transform 0.2s, box-shadow 0.2s;
    box-shadow: 0 6px 20px rgba(161,98,7,0.35);
    letter-spacing: 0.3px;
  }

  .login-btn::before {
    content: "";
    position: absolute;
    top: 0; left: -100%;
    width: 100%; height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.15), transparent);
    transition: left 0.5s;
  }

  .login-btn:hover { transform: translateY(-2px); box-shadow: 0 10px 28px rgba(161,98,7,0.45); }
  .login-btn:hover::before { left: 100%; }
  .login-btn:active { transform: translateY(0); }

  .login-btn .btn-content { display: flex; align-items: center; justify-content: center; gap: 8px; }
  .login-btn .spinner { display: none; width: 18px; height: 18px; border: 2px solid rgba(255,255,255,0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .login-btn.loading .btn-text  { display: none; }
  .login-btn.loading .spinner   { display: block; }

  .back-link {
    display: block;
    text-align: center;
    margin-top: 22px;
    font-size: 13px;
    color: var(--muted);
    text-decoration: none;
    transition: color 0.2s;
  }
  .back-link:hover { color: var(--gold); }

  /* ── RESPONSIVE ── */
  @media (max-width: 768px) {
    body { flex-direction: column; }
    .left-panel  { width: 100%; padding: 40px 30px 30px; min-height: auto; }
    .right-panel { width: 100%; padding: 40px 25px; }
    .brand-name  { font-size: 30px; }
    .features    { display: none; }
    .divider     { display: none; }
  }
</style>
</head>
<body>

<!-- ── LEFT PANEL ── -->
<div class="left-panel">
  <div class="brand">
    <span class="coffee-icon">&#9749;</span>
    <h1 class="brand-name">Veloura<br><span>Café</span></h1>
    <p class="brand-tagline">Admin Portal</p>

    <div class="divider">
      <div class="divider-line"></div>
      <div class="divider-dot"></div>
      <div class="divider-line right"></div>
    </div>

    <ul class="features">
      <li><span>&#128230;</span> Manage live orders in real time</li>
      <li><span>&#128196;</span> Generate QR codes for tables</li>
      <li><span>&#127869;</span> Add &amp; update menu items</li>
      <li><span>&#128172;</span> View customer feedback</li>
      <li><span>&#128202;</span> Live dashboard &amp; analytics</li>
    </ul>
  </div>
</div>

<!-- ── RIGHT PANEL ── -->
<div class="right-panel">
  <div class="login-box">

    <div class="login-header">
      <h2>Welcome back</h2>
      <p>Sign in to your admin panel</p>
    </div>

    <% if (request.getAttribute("error") != null) { %>
      <div class="msg-box msg-error">
        &#9888;&nbsp; <%= request.getAttribute("error") %>
      </div>
    <% } %>

    <form action="<%= request.getContextPath() %>/AdminLoginServlet" method="post" id="loginForm">

      <div class="input-group">
        <label>Email Address</label>
        <div class="input-wrap">
          <span class="input-icon">&#9993;</span>
          <input type="email" name="username" placeholder="admin@veloura.com" required autocomplete="email">
        </div>
      </div>

      <div class="input-group">
        <label>Password</label>
        <div class="input-wrap">
          <span class="input-icon">&#128274;</span>
          <input type="password" name="password" id="pwField" placeholder="Enter your password" required autocomplete="current-password">
          <button type="button" class="toggle-pw" onclick="togglePw()" id="toggleBtn">&#128065;</button>
        </div>
      </div>

      <button type="submit" class="login-btn" id="loginBtn">
        <div class="btn-content">
          <span class="btn-text">Sign In to Dashboard</span>
          <div class="spinner"></div>
        </div>
      </button>

    </form>

    <a href="<%= request.getContextPath() %>/pages/index.jsp" class="back-link">
      &#8592; Back to Website
    </a>

  </div>
</div>

<script>
function togglePw() {
  var f = document.getElementById("pwField");
  var b = document.getElementById("toggleBtn");
  if (f.type === "password") {
    f.type = "text";
    b.innerHTML = "&#128064;";
  } else {
    f.type = "password";
    b.innerHTML = "&#128065;";
  }
}

document.getElementById("loginForm").addEventListener("submit", function() {
  var btn = document.getElementById("loginBtn");
  btn.classList.add("loading");
  btn.disabled = true;
  // Re-enable after 4s as fallback if error
  setTimeout(function() { btn.classList.remove("loading"); btn.disabled = false; }, 4000);
});
</script>

</body>
</html>
