<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<jsp:include page="/components/header.jsp"/>

<link rel="stylesheet" href="/cafe/css/style.css">
<link rel="stylesheet" href="/cafe/css/menu.css">

<section class="menu-container">

<h2 class="menu-title">Our Café Menu</h2><br><br>

<div class="menu-grid">

<!-- ================= PIZZA ================= -->

<div class="menu-category">
<img src="/cafe/images/pizza.jpg" class="category-img">
<h3>Pizza</h3>

<div class="menu-row" data-name="Margherita Pizza" data-price="249"><span>Margherita Pizza</span><span class="price">₹249</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Veggie Delight Pizza" data-price="269"><span>Veggie Delight Pizza</span><span class="price">₹269</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Paneer Tikka Pizza" data-price="299"><span>Paneer Tikka Pizza</span><span class="price">₹299</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cheese Burst Pizza" data-price="319"><span>Cheese Burst Pizza</span><span class="price">₹319</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Farmhouse Pizza" data-price="289"><span>Farmhouse Pizza</span><span class="price">₹289</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Mushroom Corn Pizza" data-price="279"><span>Mushroom Corn Pizza</span><span class="price">₹279</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


<!-- ================= BURGERS ================= -->

<div class="menu-category">
<img src="/cafe/images/burger.jpg" class="category-img">
<h3>Burgers</h3>

<div class="menu-row" data-name="Classic Veg Burger" data-price="129"><span>Classic Veg Burger</span><span class="price">₹129</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cheese Burst Burger" data-price="149"><span>Cheese Burst Burger</span><span class="price">₹149</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Grilled Paneer Burger" data-price="159"><span>Grilled Paneer Burger</span><span class="price">₹159</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Peri Peri Burger" data-price="169"><span>Peri Peri Burger</span><span class="price">₹169</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Double Cheese Burger" data-price="179"><span>Double Cheese Burger</span><span class="price">₹179</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Spicy Mexican Burger" data-price="189"><span>Spicy Mexican Burger</span><span class="price">₹189</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


<!-- ================= COFFEES ================= -->

<div class="menu-category">
<img src="/cafe/images/coffee.jpg" class="category-img">
<h3>Coffees</h3>

<div class="menu-row" data-name="Caramel Latte" data-price="199"><span>Caramel Latte</span><span class="price">₹199</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cappuccino" data-price="179"><span>Cappuccino</span><span class="price">₹179</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Mocha" data-price="209"><span>Mocha</span><span class="price">₹209</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cold Brew" data-price="189"><span>Cold Brew</span><span class="price">₹189</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Hazelnut Latte" data-price="219"><span>Hazelnut Latte</span><span class="price">₹219</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Vanilla Iced Coffee" data-price="229"><span>Vanilla Iced Coffee</span><span class="price">₹229</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


<!-- ================= DESSERTS ================= -->

<div class="menu-category">
<img src="/cafe/images/deserts.jpg" class="category-img">
<h3>Desserts</h3>

<div class="menu-row" data-name="Chocolate Brownie" data-price="149"><span>Chocolate Brownie</span><span class="price">₹149</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Red Velvet Cake" data-price="169"><span>Red Velvet Cake</span><span class="price">₹169</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Classic Cheesecake" data-price="189"><span>Classic Cheesecake</span><span class="price">₹189</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Blueberry Muffin" data-price="129"><span>Blueberry Muffin</span><span class="price">₹129</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Tiramisu Slice" data-price="199"><span>Tiramisu Slice</span><span class="price">₹199</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Chocolate Donut" data-price="99"><span>Chocolate Donut</span><span class="price">₹99</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


<!-- ================= BEVERAGES ================= -->

<div class="menu-category">
<img src="/cafe/images/bevrages.jpg" class="category-img">
<h3>Beverages</h3>

<div class="menu-row" data-name="Iced Tea" data-price="129"><span>Iced Tea</span><span class="price">₹129</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Strawberry Shake" data-price="159"><span>Strawberry Shake</span><span class="price">₹159</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Mango Smoothie" data-price="169"><span>Mango Smoothie</span><span class="price">₹169</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Chocolate Milkshake" data-price="179"><span>Chocolate Milkshake</span><span class="price">₹179</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Mint Mojito" data-price="149"><span>Mint Mojito</span><span class="price">₹149</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Peach Cooler" data-price="159"><span>Peach Cooler</span><span class="price">₹159</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


<!-- ================= PASTA ================= -->

<div class="menu-category">
<img src="/cafe/images/pasta.jpg" class="category-img">
<h3>Pasta</h3>

<div class="menu-row" data-name="White Sauce Pasta" data-price="209"><span>White Sauce Pasta</span><span class="price">₹209</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Red Sauce Pasta" data-price="219"><span>Red Sauce Pasta</span><span class="price">₹219</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Pink Sauce Pasta" data-price="229"><span>Pink Sauce Pasta</span><span class="price">₹229</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Pesto Pasta" data-price="249"><span>Pesto Pasta</span><span class="price">₹249</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cheesy Alfredo Pasta" data-price="259"><span>Cheesy Alfredo Pasta</span><span class="price">₹259</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Arrabbiata Pasta" data-price="269"><span>Arrabbiata Pasta</span><span class="price">₹269</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


<!-- ================= MOMOS ================= -->

<div class="menu-category">
<img src="/cafe/images/momos.jpg" class="category-img">
<h3>Momos</h3>

<div class="menu-row" data-name="Veg Steamed Momos" data-price="129"><span>Veg Steamed Momos</span><span class="price">₹129</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Paneer Momos" data-price="149"><span>Paneer Momos</span><span class="price">₹149</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Fried Momos" data-price="159"><span>Fried Momos</span><span class="price">₹159</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cheese Corn Momos" data-price="169"><span>Cheese Corn Momos</span><span class="price">₹169</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Tandoori Momos" data-price="179"><span>Tandoori Momos</span><span class="price">₹179</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Peri Peri Momos" data-price="189"><span>Peri Peri Momos</span><span class="price">₹189</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


<!-- ================= SANDWICHES ================= -->

<div class="menu-category">
<img src="/cafe/images/sandwitches.jpg" class="category-img">
<h3>Sandwiches</h3>

<div class="menu-row" data-name="Grilled Veg Sandwich" data-price="139"><span>Grilled Veg Sandwich</span><span class="price">₹139</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cheese Corn Sandwich" data-price="149"><span>Cheese Corn Sandwich</span><span class="price">₹149</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Paneer Club Sandwich" data-price="159"><span>Paneer Club Sandwich</span><span class="price">₹159</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Peri Peri Sandwich" data-price="169"><span>Peri Peri Sandwich</span><span class="price">₹169</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Mexican Veg Sandwich" data-price="179"><span>Mexican Veg Sandwich</span><span class="price">₹179</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cheese Burst Sandwich" data-price="189"><span>Cheese Burst Sandwich</span><span class="price">₹189</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


<!-- ================= FRENCH FRIES ================= -->

<div class="menu-category">
<img src="/cafe/images/fries.jpg" class="category-img">
<h3>French Fries</h3>

<div class="menu-row" data-name="Classic French Fries" data-price="99"><span>Classic French Fries</span><span class="price">₹99</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Peri Peri Fries" data-price="119"><span>Peri Peri Fries</span><span class="price">₹119</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Cheese Fries" data-price="129"><span>Cheese Fries</span><span class="price">₹129</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Loaded Fries" data-price="149"><span>Loaded Fries</span><span class="price">₹149</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Garlic Parmesan Fries" data-price="159"><span>Garlic Parmesan Fries</span><span class="price">₹159</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

<div class="menu-row" data-name="Chilli Cheese Fries" data-price="159"><span>Chilli Cheese Fries</span><span class="price">₹159</span><div class="qty-box"><button class="minus">-</button><span class="qty">0</span><button class="plus">+</button></div></div>

</div>


</div>


</div>

<div style="text-align:center;margin:40px 0 30px;">
  <button id="cartBtn" style="background:linear-gradient(135deg,#f59e0b,#a16207);color:white;padding:15px 50px;border:none;border-radius:30px;font-size:16px;font-weight:600;cursor:pointer;box-shadow:0 8px 20px rgba(0,0,0,0.15);transition:0.3s;font-family:'Poppins',sans-serif;">
    🛒 Go to Cart
  </button>
</div>

</section>

<script src="<%= request.getContextPath() %>/js/menu.js"></script>

<%@ include file="/components/footer.jsp" %>
