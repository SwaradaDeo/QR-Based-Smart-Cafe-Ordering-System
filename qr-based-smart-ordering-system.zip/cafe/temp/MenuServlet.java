package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ManageMenu")
public class MenuServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminUser") == null) {
            response.sendRedirect(request.getContextPath() + "/admin/admin-login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        String msg    = "done";

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();

            if ("addCategory".equals(action)) {
                String catName = request.getParameter("categoryName");
                String desc    = request.getParameter("description");
                if (catName == null || catName.trim().isEmpty()) {
                    msg = "error_empty";
                } else {
                    PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO categories(category_name, description) VALUES(?,?)");
                    ps.setString(1, catName.trim());
                    ps.setString(2, desc != null ? desc.trim() : "");
                    ps.executeUpdate();
                    msg = "cat_added";
                }

            } else if ("addItem".equals(action)) {
                String catIdStr = request.getParameter("categoryId");
                String name     = request.getParameter("itemName");
                String desc     = request.getParameter("description");
                String priceStr = request.getParameter("price");

                if (catIdStr == null || catIdStr.isEmpty() || name == null || name.trim().isEmpty() || priceStr == null) {
                    msg = "error_empty";
                } else {
                    int    catId = Integer.parseInt(catIdStr);
                    double price = Double.parseDouble(priceStr);
                    PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO menu_items(category_id, item_name, description, price, status) VALUES(?,?,?,?,'available')");
                    ps.setInt(1, catId);
                    ps.setString(2, name.trim());
                    ps.setString(3, desc != null ? desc.trim() : "");
                    ps.setDouble(4, price);
                    ps.executeUpdate();
                    msg = "item_added";
                }

            } else if ("deleteItem".equals(action)) {
                int itemId = Integer.parseInt(request.getParameter("itemId"));
                PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM menu_items WHERE item_id=?");
                ps.setInt(1, itemId);
                ps.executeUpdate();
                msg = "item_deleted";

            } else if ("deleteCategory".equals(action)) {
                int catId = Integer.parseInt(request.getParameter("categoryId"));
                PreparedStatement ps1 = conn.prepareStatement(
                    "DELETE FROM menu_items WHERE category_id=?");
                ps1.setInt(1, catId);
                ps1.executeUpdate();
                PreparedStatement ps2 = conn.prepareStatement(
                    "DELETE FROM categories WHERE category_id=?");
                ps2.setInt(1, catId);
                ps2.executeUpdate();
                msg = "cat_deleted";
            }

        } catch (Exception e) {
            e.printStackTrace();
            msg = "error";
        } finally {
            if (conn != null) try { conn.close(); } catch (Exception ignored) {}
        }

        response.sendRedirect(request.getContextPath() + "/admin/admin-manage-menu.jsp?msg=" + msg);
    }
}
