<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html>
<head>
<title>Veloura Café</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
</head>
<body>

<header class="navbar">
  <h2 class="logo">Veloura Café</h2>

  <button class="hamburger" id="hamburger" aria-label="Menu">&#9776;</button>

  <nav id="mainNav">
    <a href="<%= request.getContextPath() %>/pages/index.jsp">Home</a>
    <a href="<%= request.getContextPath() %>/user/menu.jsp">Menu</a>
    <a href="<%= request.getContextPath() %>/user/cart.jsp">Cart &#128722;</a>
    <a href="<%= request.getContextPath() %>/pages/about.jsp">About</a>
    <a href="<%= request.getContextPath() %>/pages/contact.jsp">Contact</a>
    <a href="<%= request.getContextPath() %>/user/feedback.jsp">Feedback</a>
    <% if (session.getAttribute("userName") != null) { %>
      <a href="<%= request.getContextPath() %>/user/profile.jsp" style="color:#a16207;font-weight:600;">Hi, <%= session.getAttribute("userName") %></a>
      <a href="<%= request.getContextPath() %>/logout">Logout</a>
    <% } else { %>
      <a href="<%= request.getContextPath() %>/user/login.jsp" class="btn">Login</a>
    <% } %>
  </nav>
</header>

<script>
  document.getElementById('hamburger').addEventListener('click', function() {
    document.getElementById('mainNav').classList.toggle('nav-open');
  });
</script>
