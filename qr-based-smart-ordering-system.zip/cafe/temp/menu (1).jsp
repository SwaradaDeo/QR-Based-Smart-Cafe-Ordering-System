<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%@ include file="/components/header.jsp" %>

<link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
<link rel="stylesheet" href="<%= request.getContextPath() %>/css/menu.css">

<%
    // Table number from QR scan (stored in session)
    Integer tableId  = (Integer) session.getAttribute("tableId");
    Integer tableNum = (Integer) session.getAttribute("tableNumber");
%>

<% if (tableNum != null) { %>
<div style="background:linear-gradient(135deg,#a16207,#78350f);color:#fff;text-align:center;padding:12px;font-size:14px;font-weight:600;">
    &#128196; You are ordering from <strong>Table #<%= tableNum %></strong>
</div>
<% } %>

<section class="menu-container">
<h2 class="menu-title">Our Café Menu</h2><br>

<div class="menu-grid">
<%
Connection conn = null;
try {
    conn = DBConnection.getConnection();

    // Load all categories
    ResultSet cats = conn.prepareStatement(
        "SELECT * FROM categories ORDER BY category_name"
    ).executeQuery();

    while (cats.next()) {
        int    catId   = cats.getInt("category_id");
        String catName = cats.getString("category_name");

        // Load items for this category
        PreparedStatement ips = conn.prepareStatement(
            "SELECT * FROM menu_items WHERE category_id=? AND status='available' ORDER BY item_name");
        ips.setInt(1, catId);
        ResultSet items = ips.executeQuery();

        boolean hasItems = false;
        StringBuilder rows = new StringBuilder();

        while (items.next()) {
            hasItems = true;
            String iName  = items.getString("item_name").replace("\"","&quot;");
            int    iPrice = (int) items.getDouble("price");
            String iDesc  = items.getString("description");
            rows.append("<div class=\"menu-row\" data-name=\"").append(iName)
                .append("\" data-price=\"").append(iPrice).append("\">")
                .append("<div class=\"item-info-col\">")
                .append("<span class=\"item-label\">").append(items.getString("item_name")).append("</span>");
            if (iDesc != null && !iDesc.trim().isEmpty()) {
                rows.append("<span class=\"item-desc-small\">").append(iDesc).append("</span>");
            }
            rows.append("</div>")
                .append("<span class=\"price\">&#8377;").append(iPrice).append("</span>")
                .append("<div class=\"qty-box\">")
                .append("<button class=\"minus\">-</button>")
                .append("<span class=\"qty\">0</span>")
                .append("<button class=\"plus\">+</button>")
                .append("</div></div>");
        }

        if (hasItems) {
%>
<div class="menu-category">
    <h3><%= catName %></h3>
    <%= rows.toString() %>
</div>
<%
        }
    }
} catch (Exception e) {
    out.print("<p style='color:red;padding:20px;'>Menu load error: " + e.getMessage() + "</p>");
} finally {
    if (conn != null) try { conn.close(); } catch (Exception ignored) {}
}
%>
</div>

<div style="text-align:center;margin:40px 0 30px;">
  <button id="cartBtn" style="background:linear-gradient(135deg,#f59e0b,#a16207);color:white;padding:15px 50px;border:none;border-radius:30px;font-size:16px;font-weight:600;cursor:pointer;box-shadow:0 8px 20px rgba(0,0,0,0.15);font-family:'Poppins',sans-serif;">
    &#128722; Go to Cart
  </button>
</div>

</section>

<script src="<%= request.getContextPath() %>/js/menu.js"></script>

<%@ include file="/components/footer.jsp" %>
