<footer class="footer">

<div class="footer-container">

<!-- CONTACT -->

<div class="footer-col">

<h3>CONTACT</h3>

<p>
C-37 C Block, 1st Floor Radial Rd 5<br>
Connaught Place, New Delhi 110001
</p>

<p class="phone">Call : +91 9999611334</p>

</div>


<!-- SUBSCRIBE -->

<div class="footer-col center">

<h2 class="footer-logo">Veloura Cafe</h2>

<p>Join our mailing list for updates,<br>
Get news & offers events.</p>

<div class="subscribe-box">

<input type="email" placeholder="Enter Your Email">

<button>Subscribe</button>

</div>

</div>


<!-- TIMING -->

<div class="footer-col">

<h3>TIMING</h3>

<p>Mon - Fri : 11am - 1am</p>
<p>Sat - Sun : 11am - 1am</p>

<div class="social">

<a href="#">Instagram</a>
<a href="#">Facebook</a>

</div>

</div>

</div>


<div class="footer-bottom">

<p>Copyright © 2026 Veloura-Cafe | All Rights Reserved</p>

<div class="footer-links">
<a href="#">Terms & Conditions</a>
<a href="#">Privacy Policy</a>
</div>

</div>

</footer>

</body>
</html>