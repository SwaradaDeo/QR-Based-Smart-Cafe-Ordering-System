document.addEventListener("DOMContentLoaded", function () {

    // Always use "cafeCart" — also clear old "cart" key on load
    localStorage.removeItem("cart");   // clear old key if exists
    var cart = JSON.parse(localStorage.getItem("cafeCart")) || {};

    // Restore quantities on page load
    document.querySelectorAll(".menu-row").forEach(function(row) {
        var name = row.dataset.name;
        if (cart[name]) {
            row.querySelector(".qty").innerText = cart[name].quantity;
        }
    });

    // PLUS button
    document.querySelectorAll(".plus").forEach(function(btn) {
        btn.onclick = function () {
            var row   = this.closest(".menu-row");
            var name  = row.dataset.name;
            var price = parseInt(row.dataset.price);
            var qtyEl = row.querySelector(".qty");
            var qty   = parseInt(qtyEl.innerText) + 1;

            qtyEl.innerText = qty;
            cart[name] = { name: name, price: price, quantity: qty };
            localStorage.setItem("cafeCart", JSON.stringify(cart));
            updateCartBtn();
        };
    });

    // MINUS button
    document.querySelectorAll(".minus").forEach(function(btn) {
        btn.onclick = function () {
            var row   = this.closest(".menu-row");
            var name  = row.dataset.name;
            var qtyEl = row.querySelector(".qty");
            var qty   = parseInt(qtyEl.innerText);

            if (qty > 0) {
                qty--;
                qtyEl.innerText = qty;
                if (qty === 0) {
                    delete cart[name];
                } else {
                    cart[name].quantity = qty;
                }
                localStorage.setItem("cafeCart", JSON.stringify(cart));
                updateCartBtn();
            }
        };
    });

    function updateCartBtn() {
        var btn   = document.getElementById("cartBtn");
        if (!btn) return;
        var total = 0;
        Object.keys(cart).forEach(function(k) { total += cart[k].quantity; });
        if (total > 0) {
            btn.innerText = "View Cart (" + total + " items) \u2192";
            btn.style.background = "linear-gradient(135deg,#16a34a,#15803d)";
        } else {
            btn.innerText = "\uD83D\uDED2 Go to Cart";
            btn.style.background = "linear-gradient(135deg,#f59e0b,#a16207)";
        }
    }

    var cartBtn = document.getElementById("cartBtn");
    if (cartBtn) {
        updateCartBtn();
        cartBtn.onclick = function () {
            if (Object.keys(cart).length === 0) {
                alert("Please add at least one item to your cart first!");
                return;
            }
            window.location.href = "cart.jsp";
        };
    }

});