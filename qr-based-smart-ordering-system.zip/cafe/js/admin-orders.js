document.addEventListener("DOMContentLoaded", function(){

let orders = JSON.parse(localStorage.getItem("orders")) || [];

let newOrdersBox = document.getElementById("newOrders");
let preparingOrdersBox = document.getElementById("preparingOrders");
let readyOrdersBox = document.getElementById("readyOrders");


orders.forEach(order => {

let itemsHTML = "";

/* show ordered items */

for(let item in order.items){

itemsHTML += item + " x " + order.items[item].quantity + "<br>";

}

/* create order card */

let card = document.createElement("div");

card.className = "order-card";

card.innerHTML = `
<div class="order-items">

${itemsHTML}

<br>
<b>Payment:</b> ${order.payment}

</div>

<button class="order-btn start-btn">Start Preparing</button>
`;

newOrdersBox.appendChild(card);


/* start preparing button */

card.querySelector(".start-btn").onclick = function(){

moveToPreparing(card);

};

});


/* move to preparing */

function moveToPreparing(card){

card.querySelector("button").remove();

let btn = document.createElement("button");

btn.innerText = "Mark Ready";

btn.className = "order-btn";

btn.onclick = function(){

moveToReady(card);

};

card.appendChild(btn);

preparingOrdersBox.appendChild(card);

}


/* move to ready */

function moveToReady(card){

card.querySelector("button").remove();

let btn = document.createElement("button");

btn.innerText = "Complete";

btn.className = "order-btn";

btn.onclick = function(){

card.remove();

};

card.appendChild(btn);

readyOrdersBox.appendChild(card);

}

});