const menuData={

Pizza:[
["Margherita Pizza",249],
["Veggie Delight Pizza",269],
["Paneer Tikka Pizza",299],
["Cheese Burst Pizza",319],
["Farmhouse Pizza",289],
["Mushroom Corn Pizza",279]
],

Burgers:[
["Classic Veg Burger",129],
["Cheese Burst Burger",149],
["Grilled Paneer Burger",159],
["Peri Peri Burger",169],
["Double Cheese Burger",179],
["Spicy Mexican Burger",189]
],

Coffee:[
["Caramel Latte",199],
["Cappuccino",179],
["Mocha",209],
["Cold Brew",189],
["Hazelnut Latte",219],
["Vanilla Iced Coffee",229]
],

Desserts:[
["Chocolate Brownie",149],
["Red Velvet Cake",169],
["Classic Cheesecake",189],
["Blueberry Muffin",129],
["Tiramisu Slice",199],
["Chocolate Donut",99]
],

Beverages:[
["Iced Tea",129],
["Strawberry Shake",159],
["Mango Smoothie",169],
["Chocolate Milkshake",179],
["Mint Mojito",149],
["Peach Cooler",159]
],

Pasta:[
["White Sauce Pasta",229],
["Red Sauce Pasta",219],
["Pink Sauce Pasta",239],
["Pesto Pasta",249],
["Cheesy Alfredo Pasta",259],
["Arrabbiata Pasta",269]
],

Momos:[
["Veg Steamed Momos",129],
["Paneer Momos",149],
["Fried Momos",159],
["Cheese Corn Momos",169],
["Tandoori Momos",179],
["Peri Peri Momos",189]
],

Sandwiches:[
["Grilled Veg Sandwich",139],
["Cheese Corn Sandwich",149],
["Paneer Club Sandwich",159],
["Peri Peri Sandwich",169],
["Mexican Veg Sandwich",179],
["Cheese Burst Sandwich",189]
],

Fries:[
["Classic French Fries",99],
["Peri Peri Fries",119],
["Cheese Fries",129],
["Loaded Fries",149],
["Garlic Parmesan Fries",139],
["Chilli Cheese Fries",159]
]

};


function renderMenu(){

let grid=document.getElementById("menuGrid");

grid.innerHTML="";

for(let category in menuData){

let card=document.createElement("div");

card.className="category-card";

let items="";

menuData[category].forEach((item,index)=>{

items+=`

<div class="menu-item">

<span class="item-name">${item[0]}</span>

<span class="item-price">₹${item[1]}</span>

<div class="menu-actions">

<button onclick="editItem('${category}',${index})">Edit</button>

<button onclick="deleteItem('${category}',${index})">Delete</button>

</div>

</div>

`;

});

card.innerHTML=`

<h2>${category}</h2>

${items}

<div class="add-box">

<input id="${category}Name" placeholder="Item name">

<input id="${category}Price" placeholder="Price">

<button onclick="addItem('${category}')">Add</button>

</div>

`;

grid.appendChild(card);

}

}



function addItem(category){

let name=document.getElementById(category+"Name").value;

let price=document.getElementById(category+"Price").value;

menuData[category].push([name,price]);

renderMenu();

}



function deleteItem(category,index){

menuData[category].splice(index,1);

renderMenu();

}



function editItem(category,index){

let newPrice=prompt("Enter new price");

if(newPrice){

menuData[category][index][1]=newPrice;

renderMenu();

}

}



function addCategory(){

let category=document.getElementById("newCategory").value;

let item=document.getElementById("firstItem").value;

let price=document.getElementById("firstPrice").value;

if(!category || !item || !price){
alert("Fill all fields");
return;
}

menuData[category]=[
[item,price]
];

renderMenu();

}



renderMenu();