let ratings = {};

document.querySelectorAll(".stars").forEach(group=>{

let stars = group.querySelectorAll("span");

stars.forEach((star,index)=>{

/* hover highlight */
star.addEventListener("mouseover",()=>{

stars.forEach((s,i)=>{
s.style.color = i <= index ? "#d28b00" : "#ccc";
});

});

/* remove hover highlight */
star.addEventListener("mouseout",()=>{

stars.forEach((s,i)=>{
s.style.color = s.classList.contains("active") ? "#d28b00" : "#ccc";
});

});

/* click rating */
star.addEventListener("click",()=>{

stars.forEach(s=>{
s.classList.remove("active");
});

for(let i=0;i<=index;i++){
stars[i].classList.add("active");
}

ratings[group.dataset.rate] = index + 1;

});

});

});