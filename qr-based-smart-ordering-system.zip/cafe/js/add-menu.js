document.addEventListener("DOMContentLoaded", function(){

let newBox = document.getElementById("newOrders");
let preparingBox = document.getElementById("preparingOrders");
let readyBox = document.getElementById("readyOrders");


/* Example order coming from customer */

addNewOrder("Table 4",["Margherita Pizza","Cold Coffee"]);



function addNewOrder(table,items){

let card = document.createElement("div");

card.className="order-card";

card.innerHTML=`

<div class="order-items">
<b>${table}</b><br>
${items.join("<br>")}
</div>

<button class="order-btn startBtn">Start Preparing</button>

`;

newBox.appendChild(card);

card.querySelector(".startBtn").onclick=function(){

moveToPreparing(card);

};

}



function moveToPreparing(card){

card.querySelector("button").remove();

let btn=document.createElement("button");

btn.innerText="Mark Ready";

btn.className="order-btn";

btn.onclick=function(){

moveToReady(card);

};

card.appendChild(btn);

preparingBox.appendChild(card);

}



function moveToReady(card){

card.querySelector("button").remove();

let btn=document.createElement("button");

btn.innerText="Complete";

btn.className="order-btn";

btn.onclick=function(){

card.remove();

};

card.appendChild(btn);

readyBox.appendChild(card);

}

});