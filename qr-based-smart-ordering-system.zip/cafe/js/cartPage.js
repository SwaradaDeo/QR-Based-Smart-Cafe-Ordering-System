// Load cart from localStorage and render table
function renderCart() {
    const cart      = JSON.parse(localStorage.getItem('cafeCart')) || [];
    const tbody     = document.getElementById('cartItems');
    const totalSpan = document.getElementById('grandTotal');

    if (cart.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align:center">Your cart is empty</td></tr>';
        totalSpan.textContent = '0';
        return;
    }

    let html  = '';
    let grand = 0;

    cart.forEach(item => {
        const lineTotal = item.price * item.qty;
        grand += lineTotal;
        html += `<tr>
          <td>${item.name}</td>
          <td>₹${item.price}</td>
          <td>${item.qty}</td>
          <td>₹${lineTotal}</td>
        </tr>`;
    });

    tbody.innerHTML       = html;
    totalSpan.textContent = grand;
}

// Place order — sends to backend
function placeOrder() {
    const cart = JSON.parse(localStorage.getItem('cafeCart')) || [];

    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }

    const paymentMethod = document.querySelector('input[name="payment"]:checked').value;

    const formData = new FormData();
    formData.append('items',         JSON.stringify(cart));
    formData.append('paymentMethod', paymentMethod);

    fetch('/cafe/placeOrder', { method: 'POST', body: formData })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                localStorage.removeItem('cafeCart');
                document.getElementById('orderMsg').innerHTML =
                    `✅ Order #${data.orderId} placed! Payment: ${paymentMethod}`;
                setTimeout(() => { window.location.href = '/cafe/user/menu.jsp'; }, 3000);
            } else {
                document.getElementById('orderMsg').style.color = 'red';
                document.getElementById('orderMsg').textContent = data.message;
            }
        })
        .catch(() => {
            document.getElementById('orderMsg').style.color = 'red';
            document.getElementById('orderMsg').textContent = 'Error placing order. Please try again.';
        });
}

document.addEventListener('DOMContentLoaded', renderCart);