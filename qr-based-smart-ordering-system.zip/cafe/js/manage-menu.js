function openCategory(category){

let sections = document.querySelectorAll(".menu-category");
let tabs = document.querySelectorAll(".tab-btn");

sections.forEach(sec=>{
sec.classList.remove("active");
});

tabs.forEach(btn=>{
btn.classList.remove("active");
});

document.getElementById(category).classList.add("active");

event.target.classList.add("active");

}



function editPrice(button){

let menuItem = button.parentElement;

let priceElement = menuItem.querySelector(".item-price");

let currentPrice = priceElement.innerText.replace("₹","");

let newPrice = prompt("Change Price:", currentPrice);

if(newPrice !== null && newPrice !== ""){

priceElement.innerText = "₹" + newPrice;

}

}