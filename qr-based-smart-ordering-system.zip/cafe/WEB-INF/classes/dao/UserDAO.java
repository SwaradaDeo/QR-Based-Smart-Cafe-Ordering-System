package dao;

import model.User;
import util.DBConnection;

import java.sql.*;

public class UserDAO {

    Connection conn;

    public UserDAO(){
        conn = DBConnection.getConnection();
    }

    public boolean registerUser(User user){

        boolean status=false;

        try{

            String sql="INSERT INTO users(name,email,password) VALUES(?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1,user.getName());
            ps.setString(2,user.getEmail());
            ps.setString(3,user.getPassword());

            int i = ps.executeUpdate();

            if(i>0){
                status=true;
            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return status;
    }

    public User loginUser(String email,String password){

        User user=null;

        try{

            String sql="SELECT * FROM users WHERE email=? AND password=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1,email);
            ps.setString(2,password);

            ResultSet rs = ps.executeQuery();

            if(rs.next()){

                user=new User();
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));

            }

        }catch(Exception e){
            e.printStackTrace();
        }

        return user;
    }
}