package util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    private static Connection conn;

    public static Connection getConnection(){

        try{

            Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/aditya","root","");

        }catch(Exception e){
            e.printStackTrace();
        }

        return conn;
    }
}