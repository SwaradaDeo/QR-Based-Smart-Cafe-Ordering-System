<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="util.DBConnection, java.sql.*" %>
<%@ include file="/components/header.jsp" %>

<link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">
<link rel="stylesheet" href="<%= request.getContextPath() %>/css/menu.css">

<%
    Integer tableNum = (Integer) session.getAttribute("tableNumber");

    // Map category names to images
    java.util.Map<String,String> catImages = new java.util.HashMap<>();
    catImages.put("pizza",       "pizza.jpg");
    catImages.put("burgers",     "burger.jpg");
    catImages.put("burger",      "burger.jpg");
    catImages.put("coffee",      "coffee.jpg");
    catImages.put("coffees",     "coffee.jpg");
    catImages.put("desserts",    "deserts.jpg");
    catImages.put("dessert",     "deserts.jpg");
    catImages.put("beverages",   "bevrages.jpg");
    catImages.put("beverage",    "bevrages.jpg");
    catImages.put("pasta",       "pasta.jpg");
    catImages.put("sandwiches",  "sandwitches.jpg");
    catImages.put("sandwich",    "sandwitches.jpg");
    catImages.put("momos",       "momos.jpg");
    catImages.put("momo",        "momos.jpg");
    catImages.put("french fries","fries.jpg");
    catImages.put("fries",       "fries.jpg");
%>

<% if (tableNum != null) { %>
<div style="background:linear-gradient(135deg,#a16207,#78350f);color:#fff;text-align:center;padding:13px;font-size:14px;font-weight:600;letter-spacing:.3px;">
    &#128196; You are ordering from &nbsp;<strong>Table #<%= tableNum %></strong>&nbsp; — Welcome!
</div>
<% } %>

<section class="menu-container">
<h2 class="menu-title">Our Café Menu</h2>

<div class="menu-grid">
<%
Connection conn = null;
try {
    conn = DBConnection.getConnection();
    ResultSet cats = conn.prepareStatement(
        "SELECT * FROM categories ORDER BY category_name").executeQuery();

    boolean anyCat = false;
    while (cats.next()) {
        int    catId   = cats.getInt("category_id");
        String catName = cats.getString("category_name");

        PreparedStatement ips = conn.prepareStatement(
            "SELECT * FROM menu_items WHERE category_id=? AND status='available' ORDER BY item_name");
        ips.setInt(1, catId);
        ResultSet items = ips.executeQuery();

        StringBuilder rows = new StringBuilder();
        boolean hasItems = false;

        while (items.next()) {
            hasItems = true;
            String iName  = items.getString("item_name");
            String iNameQ = iName.replace("\"","&quot;");
            int    iPrice = (int) items.getDouble("price");
            String iDesc  = items.getString("description");

            rows.append("<div class=\"menu-row\" data-name=\"").append(iNameQ)
                .append("\" data-price=\"").append(iPrice).append("\">");
            rows.append("<span class=\"item-name-label\">").append(iName).append("</span>");
            rows.append("<span class=\"price\">&#8377;").append(iPrice).append("</span>");
            rows.append("<div class=\"qty-box\">")
                .append("<button class=\"minus\">-</button>")
                .append("<span class=\"qty\">0</span>")
                .append("<button class=\"plus\">+</button>")
                .append("</div>");
            rows.append("</div>");
        }

        if (!hasItems) continue;
        anyCat = true;

        // Find matching image
        String imgKey = catName.toLowerCase().trim();
        String imgFile = catImages.getOrDefault(imgKey, "pizza.jpg");
        String imgPath = request.getContextPath() + "/images/" + imgFile;
%>

<div class="menu-category">
    <img src="<%= imgPath %>" class="category-img" alt="<%= catName %>">
    <h3><%= catName %></h3>
    <%= rows.toString() %>
</div>

<%
    }

    if (!anyCat) {
        out.print("<div style='grid-column:1/-1;text-align:center;padding:60px;color:#aaa;'>"
            + "<p style='font-size:18px;margin-bottom:10px;'>No menu items yet.</p>"
            + "<p>Admin: please add categories and items in Manage Menu.</p>"
            + "</div>");
    }

} catch (Exception e) {
    out.print("<div style='grid-column:1/-1;color:red;padding:20px;'>Error loading menu: " + e.getMessage() + "</div>");
} finally {
    if (conn != null) try { conn.close(); } catch (Exception ignored) {}
}
%>
</div>

<div style="text-align:center; margin:40px 0 30px;">
  <button id="cartBtn">&#128722; Go to Cart</button>
</div>

</section>

<script src="<%= request.getContextPath() %>/js/menu.js"></script>
<%@ include file="/components/footer.jsp" %>
