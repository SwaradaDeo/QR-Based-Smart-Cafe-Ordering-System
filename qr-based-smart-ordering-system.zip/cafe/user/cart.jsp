<%@ page contentType="text/html;charset=UTF-8" %>
<%@ include file="/components/header.jsp" %>
<link rel="stylesheet" href="<%= request.getContextPath() %>/css/cart.css">

<% if(session.getAttribute("userId") == null){ %>
<div style="text-align:center;padding:80px 20px;">
  <h2 style="color:#a16207;font-family:'Playfair Display',serif;">Please Login First</h2>
  <p style="color:#777;margin:15px 0;">You need to be logged in to place an order.</p>
  <a href="<%= request.getContextPath() %>/user/login.jsp" class="btn">Login Now</a>
</div>
<% } else { %>

<div class="cart-container">
  <h2 class="cart-title">Order Summary</h2>

  <!-- CART TABLE -->
  <div class="cart-card" id="cartCard">
    <table class="cart-table">
      <thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Total</th></tr></thead>
      <tbody id="cartItems"><tr><td colspan="4" style="text-align:center;color:#aaa;padding:20px;">Loading...</td></tr></tbody>
    </table>
    <div style="text-align:right;padding:15px 10px 5px;font-size:16px;font-weight:700;color:#a16207;">
      Grand Total: &#8377;<span id="grandTotal">0</span>
    </div>
  </div>

  <!-- PAYMENT + STATUS — centered -->
  <div class="center-card" id="paymentCard">
    <div class="summary-card">
      <h3>Payment Method</h3>
      <div class="payment-options">
        <label class="payment-item"><input type="radio" name="payment" value="Cash" checked> &nbsp;&#128181; Cash</label>
        <label class="payment-item"><input type="radio" name="payment" value="UPI"> &nbsp;&#128241; UPI</label>
        <label class="payment-item"><input type="radio" name="payment" value="Card"> &nbsp;&#128179; Card</label>
      </div>
      <div class="checkout-buttons">
        <button onclick="window.location.href='menu.jsp'" class="modify-btn">&#9998; Modify Order</button>
        <button onclick="placeOrder()" class="order-btn" id="placeBtn">&#10003; Place Order</button>
      </div>
    </div>
  </div>

  <!-- ORDER STATUS BOX (shown after order placed) -->
  <div id="statusBox" style="display:none;max-width:540px;margin:30px auto 0;padding:28px;border-radius:18px;background:#fdf6f0;border:2px solid #f3e8e2;text-align:center;box-shadow:0 8px 24px rgba(0,0,0,.08);">
    <div id="statusIcon"  style="font-size:48px;margin-bottom:10px;">&#9203;</div>
    <div id="statusTitle" style="font-weight:700;color:#a16207;font-size:18px;margin-bottom:8px;font-family:'Playfair Display',serif;">Order Placed!</div>
    <div id="statusMsg"   style="font-size:13px;color:#777;line-height:1.7;margin-bottom:14px;"></div>
    <div style="background:#f3e8e2;border-radius:20px;height:8px;overflow:hidden;margin:14px 0;">
      <div id="progressBar" style="height:100%;width:0%;background:linear-gradient(90deg,#f59e0b,#a16207);border-radius:20px;transition:width 0.9s ease;"></div>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:10px;color:#bbb;margin-bottom:14px;">
      <span>Placed</span><span>Preparing</span><span>Ready</span><span>Done</span>
    </div>
    <div id="orderInfo" style="font-size:12px;color:#bbb;border-top:1px solid #f3e8e2;padding-top:12px;"></div>
  </div>

  <!-- INVOICE (shown after Completed) -->
  <div id="invoiceBox" style="display:none;max-width:540px;margin:25px auto 60px;">
  </div>

</div>
<% } %>

<script>var CTX = "<%= request.getContextPath() %>";</script>
<script src="<%= request.getContextPath() %>/js/cart.js"></script>
<%@ include file="/components/footer.jsp" %>
