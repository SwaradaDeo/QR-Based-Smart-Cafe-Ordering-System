<%@ page contentType="text/html;charset=UTF-8" %>
<%@ include file="/components/header.jsp" %>

<section class="auth-section">
<div class="auth-box">

  <h2>Create Account</h2>

  <% if (request.getAttribute("error") != null) { %>
    <p style="color:red; background:#fee2e2; padding:10px; border-radius:8px; margin-bottom:15px;">
      <%= request.getAttribute("error") %>
    </p>
  <% } %>

  <form action="<%= request.getContextPath() %>/register" method="post">
    <input type="text"     name="name"     placeholder="Full Name"     required>
    <input type="email"    name="email"    placeholder="Email Address" required>
    <input type="password" name="password" placeholder="Password"      required>
    <button class="btn" type="submit">Register</button>
  </form>

  <a href="login.jsp">Already have an account? Login</a>

</div>
</section>

<%@ include file="/components/footer.jsp" %>