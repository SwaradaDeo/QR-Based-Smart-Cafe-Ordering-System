<%@ page contentType="text/html;charset=UTF-8" %>
<%@ include file="/components/header.jsp" %>

<link rel="stylesheet" href="<%= request.getContextPath() %>/css/style.css">

<% if(session.getAttribute("userId") == null){ %>
  <div style="text-align:center;padding:80px;">
    <h2 style="color:#a16207">Please login to view your order.</h2>
    <a href="<%= request.getContextPath() %>/user/login.jsp" class="btn">Login</a>
  </div>
<% } else { %>

<section style="min-height:70vh;display:flex;align-items:center;justify-content:center;padding:40px 20px;">
<div style="width:100%;max-width:500px;text-align:center;">

  <h2 style="font-family:\'Playfair Display\',serif;color:#a16207;margin-bottom:30px;">My Order Status</h2>

  <div id="statusCard" style="background:#fff;border-radius:20px;padding:40px;box-shadow:0 10px 30px rgba(0,0,0,0.08);">

    <div id="statusIcon"  style="font-size:60px;margin-bottom:15px;">&#9203;</div>
    <div id="statusTitle" style="font-size:22px;font-weight:700;color:#a16207;margin-bottom:10px;">Checking Status...</div>
    <div id="statusMsg"   style="font-size:14px;color:#777;line-height:1.7;margin-bottom:20px;"></div>

    <!-- Progress Bar -->
    <div style="background:#f3e8e2;border-radius:20px;height:8px;margin:20px 0;overflow:hidden;">
      <div id="progressBar" style="height:100%;width:0%;background:linear-gradient(90deg,#f59e0b,#a16207);border-radius:20px;transition:width 0.8s ease;"></div>
    </div>

    <div style="display:flex;justify-content:space-between;font-size:11px;color:#bbb;margin-bottom:25px;">
      <span>Placed</span><span>Preparing</span><span>Ready</span><span>Done</span>
    </div>

    <div id="orderInfo" style="font-size:12px;color:#bbb;border-top:1px solid #f3e8e2;padding-top:15px;"></div>

  </div>

  <a href="menu.jsp" style="display:inline-block;margin-top:20px;color:#a16207;text-decoration:none;font-size:14px;">&#8592; Back to Menu</a>

</div>
</section>

<% } %>

<script>
const CTX     = "<%= request.getContextPath() %>";
const orderId = new URLSearchParams(window.location.search).get("orderId");

if (orderId) {
    pollStatus();
    setInterval(pollStatus, 5000);
} else {
    document.getElementById("statusTitle").innerText = "No Order Found";
    document.getElementById("statusMsg").innerText   = "Please place an order first.";
}

function pollStatus() {
    fetch(CTX + "/OrderStatus?orderId=" + orderId)
        .then(r => r.json())
        .then(data => {
            let icon  = document.getElementById("statusIcon");
            let title = document.getElementById("statusTitle");
            let msg   = document.getElementById("statusMsg");
            let bar   = document.getElementById("progressBar");
            let info  = document.getElementById("orderInfo");

            info.innerText = "Order #" + orderId + " | &#8377;" + (data.total||"") + " | " + (data.time||"");

            if (data.status === "New") {
                icon.innerText  = "\u23F3";
                title.innerText = "Order Received";
                title.style.color = "#a16207";
                msg.innerText   = "Your order has been placed successfully. The kitchen will start preparing it shortly.";
                bar.style.width = "10%";
                bar.style.background = "linear-gradient(90deg,#f59e0b,#a16207)";

            } else if (data.status === "Preparing") {
                icon.innerText  = "\uD83D\uDC68\u200D\uD83C\uDF73";
                title.innerText = "Being Prepared";
                title.style.color = "#1d4ed8";
                msg.innerText   = "Our chefs are preparing your fresh order. It won\'t take long!";
                bar.style.width = "50%";
                bar.style.background = "linear-gradient(90deg,#3b82f6,#1d4ed8)";

            } else if (data.status === "Ready") {
                icon.innerText  = "\u2705";
                title.innerText = "Ready for Pickup!";
                title.style.color = "#16a34a";
                msg.innerText   = "Your order is ready! Please proceed to collect it from the counter.";
                bar.style.width = "80%";
                bar.style.background = "linear-gradient(90deg,#22c55e,#16a34a)";

            } else if (data.status === "Completed") {
                icon.innerText  = "\uD83C\uDF89";
                title.innerText = "Order Completed!";
                title.style.color = "#16a34a";
                msg.innerHTML   = "<strong>Thank you for dining at Veloura Café!</strong><br><br>We hope you enjoyed your meal. Your feedback means a lot to us!";
                bar.style.width = "100%";
                bar.style.background = "linear-gradient(90deg,#22c55e,#16a34a)";
                document.getElementById("statusCard").style.background = "#f0fdf4";

                // Show feedback button
                if (!document.getElementById("fbBtn")) {
                    let btn = document.createElement("a");
                    btn.id        = "fbBtn";
                    btn.href      = "feedback.jsp";
                    btn.className = "btn";
                    btn.style     = "margin-top:15px;display:inline-block;";
                    btn.innerText = "Leave Feedback \u2B50";
                    document.getElementById("statusCard").appendChild(btn);
                }
            }
        })
        .catch(() => {});
}
</script>

<%@ include file="/components/footer.jsp" %>
