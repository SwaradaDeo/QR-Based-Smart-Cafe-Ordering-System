<%@ page contentType="text/html;charset=UTF-8" %>
<%@ include file="/components/header.jsp" %>

<section class="auth-section">
<div class="auth-box">

  <h2>Welcome Back</h2>

  <% if (request.getAttribute("error") != null) { %>
    <p style="color:red;background:#fee2e2;padding:10px;border-radius:8px;margin-bottom:15px;">
      <%= request.getAttribute("error") %>
    </p>
  <% } %>
  <% if ("true".equals(request.getParameter("registered"))) { %>
    <p style="color:green;background:#dcfce7;padding:10px;border-radius:8px;margin-bottom:15px;">
      Registered successfully! Please login.
    </p>
  <% } %>
  <% if (session.getAttribute("tableNumber") != null) { %>
    <p style="color:#a16207;background:#fdf6f0;padding:10px;border-radius:8px;margin-bottom:15px;text-align:center;font-weight:600;">
      &#128196; Table #<%= session.getAttribute("tableNumber") %> — Login to order
    </p>
  <% } %>

  <form action="<%= request.getContextPath() %>/login" method="post">
    <input type="hidden" name="next" value="<%= request.getParameter("next") != null ? request.getParameter("next") : "" %>">
    <input type="email"    name="email"    placeholder="Email Address" required>
    <input type="password" name="password" placeholder="Password"      required>
    <button class="btn" type="submit">Login</button>
  </form>

  <a href="register.jsp">Don't have an account? Register</a>

</div>
</section>

<%@ include file="/components/footer.jsp" %>
