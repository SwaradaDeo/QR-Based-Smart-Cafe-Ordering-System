USE cafe_db;

-- Clear existing data first (safe to run multiple times)
DELETE FROM menu_items;
DELETE FROM categories;
ALTER TABLE categories AUTO_INCREMENT = 1;
ALTER TABLE menu_items AUTO_INCREMENT = 1;

-- ── CATEGORIES ─────────────────────────────────────────────────────────
INSERT INTO categories (category_name, description) VALUES
('Pizza',       'Freshly baked Italian style pizzas'),
('Burgers',     'Juicy gourmet burgers'),
('Coffee',      'Handcrafted hot and cold coffees'),
('Desserts',    'Sweet treats and baked goods'),
('Beverages',   'Fresh juices and cold drinks'),
('Pasta',       'Classic Italian pasta dishes'),
('Sandwiches',  'Grilled and toasted sandwiches'),
('Momos',       'Steamed and fried dumplings'),
('French Fries','Crispy fries with dips');

-- ── PIZZA ──────────────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(1, 'Margherita Pizza',      'Classic tomato base with mozzarella',     249, 'available'),
(1, 'Veggie Delight Pizza',  'Loaded with fresh vegetables',            269, 'available'),
(1, 'Paneer Tikka Pizza',    'Spicy paneer with bell peppers',          299, 'available'),
(1, 'Cheese Burst Pizza',    'Extra cheese stuffed crust',              319, 'available'),
(1, 'Farmhouse Pizza',       'Mushroom, onion, capsicum, tomato',       289, 'available'),
(1, 'Mushroom Corn Pizza',   'Golden corn with mushrooms',              279, 'available');

-- ── BURGERS ────────────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(2, 'Classic Veg Burger',    'Crispy patty with lettuce and sauce',     129, 'available'),
(2, 'Cheese Burst Burger',   'Extra cheese with jalapenos',             149, 'available'),
(2, 'Grilled Paneer Burger', 'Tandoori paneer patty',                   159, 'available'),
(2, 'Peri Peri Burger',      'Spicy peri peri sauce burger',            169, 'available'),
(2, 'Double Cheese Burger',  'Double patty double cheese',              179, 'available'),
(2, 'Spicy Mexican Burger',  'Mexican spices with salsa',               189, 'available');

-- ── COFFEE ─────────────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(3, 'Caramel Latte',         'Espresso with caramel and steamed milk',  199, 'available'),
(3, 'Cappuccino',            'Classic espresso with frothy milk',       179, 'available'),
(3, 'Mocha',                 'Rich chocolate espresso blend',           209, 'available'),
(3, 'Cold Brew',             'Smooth cold brewed coffee',               189, 'available'),
(3, 'Hazelnut Latte',        'Espresso with hazelnut syrup',            219, 'available'),
(3, 'Vanilla Iced Coffee',   'Chilled vanilla flavored coffee',         229, 'available');

-- ── DESSERTS ───────────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(4, 'Chocolate Brownie',     'Warm fudgy brownie with ice cream',       149, 'available'),
(4, 'Belgian Waffle',        'Crispy waffle with honey and berries',    179, 'available'),
(4, 'Tiramisu',              'Classic Italian coffee dessert',          199, 'available'),
(4, 'Cheesecake',            'Creamy NY style cheesecake',              189, 'available'),
(4, 'Gulab Jamun',           'Soft syrup soaked dumplings',             99,  'available');

-- ── BEVERAGES ──────────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(5, 'Fresh Lime Soda',       'Refreshing lime with soda',               79,  'available'),
(5, 'Mango Lassi',           'Thick sweet mango yogurt drink',          99,  'available'),
(5, 'Strawberry Milkshake',  'Fresh strawberry blended milkshake',      129, 'available'),
(5, 'Virgin Mojito',         'Mint lime and soda mocktail',             109, 'available'),
(5, 'Cold Coffee',           'Blended iced coffee with milk',           119, 'available');

-- ── PASTA ──────────────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(6, 'Penne Arrabbiata',      'Spicy tomato sauce with penne',           179, 'available'),
(6, 'Spaghetti Aglio Olio',  'Garlic olive oil and herbs',              169, 'available'),
(6, 'Mac and Cheese',        'Creamy cheddar macaroni',                 159, 'available'),
(6, 'Pesto Pasta',           'Fresh basil pesto with fusilli',          189, 'available');

-- ── SANDWICHES ─────────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(7, 'Grilled Veg Sandwich',  'Grilled veggies with cheese',             119, 'available'),
(7, 'Club Sandwich',         'Triple decker with mayo and veggies',     149, 'available'),
(7, 'Paneer Sandwich',       'Spiced paneer with chutneys',             139, 'available'),
(7, 'Cheese Toast',          'Buttered bread with melted cheese',       99,  'available');

-- ── MOMOS ──────────────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(8, 'Steamed Veg Momos',     'Soft steamed dumplings with chutney',     99,  'available'),
(8, 'Fried Veg Momos',       'Crispy fried dumplings',                  109, 'available'),
(8, 'Paneer Momos',          'Spiced paneer stuffed momos',             119, 'available'),
(8, 'Tandoori Momos',        'Grilled momos with smoky flavor',         129, 'available');

-- ── FRENCH FRIES ───────────────────────────────────────────────────────
INSERT INTO menu_items (category_id, item_name, description, price, status) VALUES
(9, 'Classic Salted Fries',  'Golden crispy fries with ketchup',        79,  'available'),
(9, 'Peri Peri Fries',       'Spicy peri peri seasoned fries',          99,  'available'),
(9, 'Chilli Cheese Fries',   'Fries topped with cheese sauce',          119, 'available'),
(9, 'Loaded Fries',          'Fries with sour cream and jalapenos',     139, 'available');

SELECT 'Categories added:', COUNT(*) FROM categories;
SELECT 'Menu items added:', COUNT(*) FROM menu_items;