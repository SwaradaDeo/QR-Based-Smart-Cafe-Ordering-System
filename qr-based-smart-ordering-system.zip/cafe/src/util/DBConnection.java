package util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {

        // ── CHANGE THESE IF NEEDED ──────────────────────────
        String host     = "localhost";
        String port     = "3306";
        String dbName   = "cafe_db";
        String user     = "root";
        String password = "";        // ← add your MySQL password here if you have one
        // ────────────────────────────────────────────────────

        String url = "jdbc:mysql://" + host + ":" + port + "/" + dbName
                   + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

        System.out.println("[DB] Trying to connect: " + url);

        try {
            // Try new driver
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                System.out.println("[DB] Using driver: com.mysql.cj.jdbc.Driver");
            } catch (ClassNotFoundException e1) {
                // Fallback to old driver
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("[DB] Using driver: com.mysql.jdbc.Driver");
            }

            Connection conn = DriverManager.getConnection(url, user, password);
            System.out.println("[DB] Connection SUCCESS");
            return conn;

        } catch (Exception e) {
            System.out.println("[DB] Connection FAILED: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}