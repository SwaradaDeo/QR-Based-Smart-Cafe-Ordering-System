package dao;

import util.DBConnection;
import java.sql.*;

public class AdminDAO {

    public int getTotalOrders() {
        return getCount("SELECT COUNT(*) FROM orders");
    }

    public int getTotalMenuItems() {
        return getCount("SELECT COUNT(*) FROM menu_items");
    }

    public int getTotalUsers() {
        return getCount("SELECT COUNT(*) FROM users WHERE role='customer'");
    }

    public int getPendingOrders() {
        return getCount("SELECT COUNT(*) FROM orders WHERE order_status='New'");
    }

    private int getCount(String sql) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
}