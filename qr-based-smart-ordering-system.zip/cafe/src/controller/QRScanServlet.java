package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/scan")
public class QRScanServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String tableParam = request.getParameter("table");

        if (tableParam == null || tableParam.trim().isEmpty()) {
            response.sendRedirect(request.getContextPath() + "/pages/index.jsp");
            return;
        }

        int tableNumber = 0;
        int tableId     = 0;
        try {
            tableNumber = Integer.parseInt(tableParam.trim());
        } catch (NumberFormatException e) {
            response.sendRedirect(request.getContextPath() + "/pages/index.jsp");
            return;
        }

        // Look up table_id from DB
        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT table_id FROM tables WHERE table_number=?");
            ps.setInt(1, tableNumber);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                tableId = rs.getInt("table_id");
                // Mark table as occupied
                PreparedStatement upd = conn.prepareStatement(
                    "UPDATE tables SET status='occupied' WHERE table_id=?");
                upd.setInt(1, tableId);
                upd.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Store table info in session
        HttpSession session = request.getSession();
        session.setAttribute("tableId",     tableId);
        session.setAttribute("tableNumber", tableNumber);

        // If not logged in, go to login first, then come back to menu
        if (session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/user/login.jsp?next=menu");
        } else {
            response.sendRedirect(request.getContextPath() + "/user/menu.jsp");
        }
    }
}
