package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;
import java.util.regex.*;

@WebServlet("/PlaceOrder")
public class PlaceOrderServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            out.print("{\"success\":false,\"message\":\"Please login first\"}");
            return;
        }

        int    userId        = (int) session.getAttribute("userId");
        String paymentMethod = request.getParameter("paymentMethod");
        String itemsJson     = request.getParameter("items");

        // Table info from session (set by QR scan)
        Integer tableId = (Integer) session.getAttribute("tableId");

        if (itemsJson == null || itemsJson.trim().isEmpty() ||
            itemsJson.trim().equals("{}") || itemsJson.trim().equals("null")) {
            out.print("{\"success\":false,\"message\":\"Cart is empty\"}");
            return;
        }
        if (paymentMethod == null) paymentMethod = "Cash";

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            conn.setAutoCommit(false);

            // Calculate total
            double total = 0;
            Pattern pat = Pattern.compile("\"price\"\\s*:\\s*\"?(\\d+\\.?\\d*)\"?[^}]*\"quantity\"\\s*:\\s*\"?(\\d+)\"?");
            Matcher m   = pat.matcher(itemsJson);
            while (m.find()) {
                total += Double.parseDouble(m.group(1)) * Integer.parseInt(m.group(2));
            }

            // Insert order — include table_id if from QR scan
            PreparedStatement orderPs;
            if (tableId != null && tableId > 0) {
                orderPs = conn.prepareStatement(
                    "INSERT INTO orders(user_id, table_id, total_amount, order_status) VALUES(?,?,?,'New')",
                    Statement.RETURN_GENERATED_KEYS);
                orderPs.setInt(1, userId);
                orderPs.setInt(2, tableId);
                orderPs.setDouble(3, total);
            } else {
                orderPs = conn.prepareStatement(
                    "INSERT INTO orders(user_id, total_amount, order_status) VALUES(?,?,'New')",
                    Statement.RETURN_GENERATED_KEYS);
                orderPs.setInt(1, userId);
                orderPs.setDouble(2, total);
            }
            orderPs.executeUpdate();

            ResultSet keys = orderPs.getGeneratedKeys();
            int orderId = 0;
            if (keys.next()) orderId = keys.getInt(1);

            // Insert payment
            PreparedStatement payPs = conn.prepareStatement(
                "INSERT INTO payments(order_id, payment_method, payment_status) VALUES(?,?,'Pending')");
            payPs.setInt(1, orderId);
            payPs.setString(2, paymentMethod);
            payPs.executeUpdate();

            conn.commit();

            String tableInfo = (tableId != null && tableId > 0) ?
                ",\"tableNumber\":" + session.getAttribute("tableNumber") : "";
            out.print("{\"success\":true,\"orderId\":" + orderId + ",\"total\":" + total + tableInfo + "}");

        } catch (Exception e) {
            if (conn != null) try { conn.rollback(); } catch (Exception ignored) {}
            e.printStackTrace();
            out.print("{\"success\":false,\"message\":\"" + e.getMessage().replace("\"","'") + "\"}");
        } finally {
            if (conn != null) try { conn.close(); } catch (Exception ignored) {}
        }
    }
}