package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/OrderStatus")
public class OrderStatusServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        String orderIdStr = request.getParameter("orderId");
        if (orderIdStr == null) { out.print("{\"status\":\"unknown\"}"); return; }

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "SELECT order_status, total_amount, order_time FROM orders WHERE order_id=?");
            ps.setInt(1, Integer.parseInt(orderIdStr));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                String status = rs.getString("order_status");
                double total  = rs.getDouble("total_amount");
                String time   = rs.getTimestamp("order_time").toString().substring(0, 16);
                out.print("{\"status\":\"" + status + "\",\"total\":" + total + ",\"time\":\"" + time + "\"}");
            } else {
                out.print("{\"status\":\"unknown\"}");
            }
        } catch (Exception e) {
            out.print("{\"status\":\"error\"}");
        }
    }
}