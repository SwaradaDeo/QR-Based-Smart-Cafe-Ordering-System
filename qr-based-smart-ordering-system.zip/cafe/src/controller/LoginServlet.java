package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email    = request.getParameter("email");
        String password = request.getParameter("password");
        String next     = request.getParameter("next");

        Connection con = null;
        try {
            con = DBConnection.getConnection();
            if (con == null) {
                request.setAttribute("error", "Database connection failed.");
                request.getRequestDispatcher("/user/login.jsp").forward(request, response);
                return;
            }

            PreparedStatement ps = con.prepareStatement(
                "SELECT * FROM users WHERE email=? AND password=?");
            ps.setString(1, email.trim());
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                HttpSession session = request.getSession();
                session.setAttribute("userId",    rs.getInt("user_id"));
                session.setAttribute("userName",  rs.getString("name"));
                session.setAttribute("userEmail", rs.getString("email"));
                session.setAttribute("userRole",  rs.getString("role"));

                String role = rs.getString("role");
                if ("admin".equals(role)) {
                    session.setAttribute("adminUser", rs.getString("name"));
                    response.sendRedirect(request.getContextPath() + "/admin/admin-dashboard.jsp");
                } else if ("menu".equals(next)) {
                    // Came from QR scan
                    response.sendRedirect(request.getContextPath() + "/user/menu.jsp");
                } else {
                    response.sendRedirect(request.getContextPath() + "/user/menu.jsp");
                }
            } else {
                request.setAttribute("error", "Invalid email or password.");
                request.getRequestDispatcher("/user/login.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error: " + e.getMessage());
            request.getRequestDispatcher("/user/login.jsp").forward(request, response);
        } finally {
            if (con != null) try { con.close(); } catch (Exception ignored) {}
        }
    }
}
