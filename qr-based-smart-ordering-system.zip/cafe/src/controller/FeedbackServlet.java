package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/SubmitFeedback")
public class FeedbackServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/user/login.jsp");
            return;
        }

        int    userId   = (int) session.getAttribute("userId");
        String comments = request.getParameter("comments");
        String ratingStr= request.getParameter("rating");
        int    rating   = (ratingStr != null && !ratingStr.isEmpty()) ? Integer.parseInt(ratingStr) : 5;

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO feedback(user_id, rating, comments) VALUES(?,?,?)");
            ps.setInt(1, userId);
            ps.setInt(2, rating);
            ps.setString(3, comments);
            ps.executeUpdate();
        } catch (Exception e) { e.printStackTrace(); }

        response.sendRedirect(request.getContextPath() + "/user/feedback.jsp?sent=true");
    }
}