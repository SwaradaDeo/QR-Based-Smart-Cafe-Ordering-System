package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/UpdateOrderStatus")
public class UpdateOrderStatus extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminUser") == null) {
            response.sendRedirect(request.getContextPath() + "/admin/admin-login.jsp");
            return;
        }

        int    orderId = Integer.parseInt(request.getParameter("orderId"));
        String status  = request.getParameter("status");

        try (Connection conn = DBConnection.getConnection()) {
            PreparedStatement ps = conn.prepareStatement(
                "UPDATE orders SET order_status=? WHERE order_id=?");
            ps.setString(1, status);
            ps.setInt(2, orderId);
            ps.executeUpdate();

            if ("Completed".equals(status)) {
                PreparedStatement payPs = conn.prepareStatement(
                    "UPDATE payments SET payment_status='Paid' WHERE order_id=?");
                payPs.setInt(1, orderId);
                payPs.executeUpdate();
            }
        } catch (Exception e) { e.printStackTrace(); }

        response.sendRedirect(request.getContextPath() + "/admin/admin-orders.jsp");
    }
}