package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/ManageMenu")
public class MenuServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("adminUser") == null) {
            response.sendRedirect(request.getContextPath() + "/admin/admin-login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        String msg    = "done";

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();

            if ("addCategory".equals(action)) {
                String catName       = request.getParameter("categoryName");
                String firstItemName = request.getParameter("firstItemName");
                String firstItemPrice= request.getParameter("firstItemPrice");

                if (catName == null || catName.trim().isEmpty()) {
                    msg = "error_empty";
                } else {
                    // Insert category
                    PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO categories(category_name, description) VALUES(?,'')",
                        Statement.RETURN_GENERATED_KEYS);
                    ps.setString(1, catName.trim());
                    ps.executeUpdate();
                    msg = "cat_added";

                    // Insert first item if provided
                    if (firstItemName != null && !firstItemName.trim().isEmpty()
                            && firstItemPrice != null && !firstItemPrice.trim().isEmpty()) {
                        ResultSet keys = ps.getGeneratedKeys();
                        if (keys.next()) {
                            int newCatId = keys.getInt(1);
                            PreparedStatement ips = conn.prepareStatement(
                                "INSERT INTO menu_items(category_id,item_name,description,price,status) VALUES(?,?,'',?,'available')");
                            ips.setInt(1, newCatId);
                            ips.setString(2, firstItemName.trim());
                            ips.setDouble(3, Double.parseDouble(firstItemPrice.trim()));
                            ips.executeUpdate();
                        }
                    }
                }

            } else if ("addItem".equals(action)) {
                String catIdStr = request.getParameter("categoryId");
                String name     = request.getParameter("itemName");
                String priceStr = request.getParameter("price");

                if (catIdStr == null || name == null || name.trim().isEmpty() || priceStr == null) {
                    msg = "error_empty";
                } else {
                    PreparedStatement ps = conn.prepareStatement(
                        "INSERT INTO menu_items(category_id,item_name,description,price,status) VALUES(?,?,'',?,'available')");
                    ps.setInt(1, Integer.parseInt(catIdStr));
                    ps.setString(2, name.trim());
                    ps.setDouble(3, Double.parseDouble(priceStr.trim()));
                    ps.executeUpdate();
                    msg = "item_added";
                }

            } else if ("updateItem".equals(action)) {
                int    itemId = Integer.parseInt(request.getParameter("itemId"));
                String name   = request.getParameter("itemName");
                double price  = Double.parseDouble(request.getParameter("price"));
                PreparedStatement ps = conn.prepareStatement(
                    "UPDATE menu_items SET item_name=?, price=? WHERE item_id=?");
                ps.setString(1, name.trim());
                ps.setDouble(2, price);
                ps.setInt(3, itemId);
                ps.executeUpdate();
                msg = "item_updated";

            } else if ("deleteItem".equals(action)) {
                int itemId = Integer.parseInt(request.getParameter("itemId"));
                PreparedStatement ps = conn.prepareStatement(
                    "DELETE FROM menu_items WHERE item_id=?");
                ps.setInt(1, itemId);
                ps.executeUpdate();
                msg = "item_deleted";

            } else if ("deleteCategory".equals(action)) {
                int catId = Integer.parseInt(request.getParameter("categoryId"));
                conn.prepareStatement(
                    "DELETE FROM menu_items WHERE category_id=" + catId).executeUpdate();
                conn.prepareStatement(
                    "DELETE FROM categories WHERE category_id=" + catId).executeUpdate();
                msg = "cat_deleted";
            }

        } catch (Exception e) {
            e.printStackTrace();
            msg = "error";
        } finally {
            if (conn != null) try { conn.close(); } catch (Exception ignored) {}
        }

        response.sendRedirect(request.getContextPath() + "/admin/admin-manage-menu.jsp?msg=" + msg);
    }
}
