package controller;

import dao.UserDAO;
import model.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String email    = request.getParameter("username").trim();
        String password = request.getParameter("password");

        UserDAO dao  = new UserDAO();
        User   user  = dao.loginUser(email, password);

        if (user != null && "admin".equals(user.getRole())) {
            HttpSession session = request.getSession();
            session.setAttribute("adminUser", user.getName());
            session.setAttribute("userRole",  "admin");
            response.sendRedirect(request.getContextPath() + "/admin/admin-dashboard.jsp");
        } else {
            request.setAttribute("error", "Invalid admin credentials.");
            request.getRequestDispatcher("/admin/admin-login.jsp").forward(request, response);
        }
    }
}