package controller;

import util.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/UpdateProfile")
public class ProfileServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userId") == null) {
            response.sendRedirect(request.getContextPath() + "/user/login.jsp");
            return;
        }

        request.setCharacterEncoding("UTF-8");
        int    userId  = (int) session.getAttribute("userId");
        String name    = request.getParameter("name");
        String phone   = request.getParameter("phone");
        String address = request.getParameter("address");
        String newPass = request.getParameter("newPassword");
        String curPass = request.getParameter("currentPassword");

        Connection conn = null;
        try {
            conn = DBConnection.getConnection();

            // Verify current password first
            PreparedStatement check = conn.prepareStatement(
                "SELECT password FROM users WHERE user_id=?");
            check.setInt(1, userId);
            ResultSet rs = check.executeQuery();
            if (!rs.next()) {
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?msg=error");
                return;
            }

            String dbPass = rs.getString("password");
            if (!dbPass.equals(curPass)) {
                response.sendRedirect(request.getContextPath() + "/user/profile.jsp?msg=wrongpass");
                return;
            }

            // Update profile
            String sql;
            PreparedStatement ps;
            if (newPass != null && !newPass.trim().isEmpty()) {
                sql = "UPDATE users SET name=?, phone=?, address=?, password=? WHERE user_id=?";
                ps  = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, phone);
                ps.setString(3, address);
                ps.setString(4, newPass);
                ps.setInt(5, userId);
            } else {
                sql = "UPDATE users SET name=?, phone=?, address=? WHERE user_id=?";
                ps  = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, phone);
                ps.setString(3, address);
                ps.setInt(4, userId);
            }
            ps.executeUpdate();

            // Update session name
            session.setAttribute("userName", name);
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?msg=success");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect(request.getContextPath() + "/user/profile.jsp?msg=error");
        } finally {
            if (conn != null) try { conn.close(); } catch (Exception ignored) {}
        }
    }
}